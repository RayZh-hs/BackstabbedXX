execute as @a[tag=CubeBlockHook] run function cube_block:cleanup_player
schedule clear cube_block:activate
kill @e[tag=CubeBlockRuntime]
