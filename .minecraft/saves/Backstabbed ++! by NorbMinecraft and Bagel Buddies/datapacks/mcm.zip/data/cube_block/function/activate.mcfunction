execute unless score $selectedMap CmdData matches 23 run return 0
execute unless score $gamestate CmdData matches 0..1 run return 0
execute as @a[tag=CubeBlockHook] run function cube_block:cleanup_player
kill @e[tag=MapEntity]
gamerule doFireTick false
summon marker 49196.5 88 49202.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49217.5 86 49235.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49193.5 87 49227.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49219.5 92 49210.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49182.5 87 49213.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49217.5 90 49193.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49208.5 87 49222.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49181.5 86 49198.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49204.5 87 49235.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49196.5 86 49215.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49209.5 90 49203.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49219.5 87 49224.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49203.5 86 49195.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49205.5 90 49212.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49194.5 86 49193.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49186.5 87 49221.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49187.5 87 49206.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49219.5 92 49201.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49200.5 87 49223.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49215.5 91 49217.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49210.5 89 49230.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49189.5 86 49214.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49210.5 88 49196.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49188.5 87 49196.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49198.5 87 49232.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49199.5 87 49208.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49204.5 88 49228.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49213.5 91 49208.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49181.5 86 49207.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49192.5 87 49220.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49193.5 86 49209.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49202.5 87 49201.5 {Tags:["PlayerSpawn","ScrapSpawn","MapEntity","CubeBlockRuntime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 49200.5 119 49204.5 {Tags:["SpectatorSpawn","MapEntity","CubeBlockRuntime"]}
tellraw @a {"translate":"cube_block.ready","fallback":"Cube Block ready","color":"aqua"}
