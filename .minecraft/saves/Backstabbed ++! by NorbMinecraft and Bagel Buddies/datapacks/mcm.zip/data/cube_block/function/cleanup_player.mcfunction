execute unless entity @s[tag=CubeBlockHook] run return 0
tag @s add CubeBlockHookCleaning
scoreboard players set @e[type=gravity_changer:grappling_hook] cube_owner 0
execute as @e[type=gravity_changer:grappling_hook] store success score @s cube_owner on origin if entity @s[type=player,tag=CubeBlockHookCleaning]
kill @e[type=gravity_changer:grappling_hook,scores={cube_owner=1}]
tag @s remove CubeBlockHookCleaning
tag @s remove CubeBlockHook
clear @s gravity_changer:grappling_hook[custom_data~{cube_block_hook:1b}]
