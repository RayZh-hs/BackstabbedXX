execute unless score $selectedMap CmdData matches 23 run return 0
execute unless score $gamestate CmdData matches 1 run return 0
execute unless entity @s[tag=queued,tag=!spectating,gamemode=!spectator] run return 0
execute if score @s dead matches 1.. run return 0
execute if score $graceperiod CmdData matches 1.. run return run function cube_block:return_to_arena
function cube_block:cleanup_player
function mcm:game/playerdeath
