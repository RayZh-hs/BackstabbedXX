execute unless entity @e[type=marker,tag=MapVote,tag=CubeBlock] run summon marker 0 -50 70 {Tags:["MapVote","CubeBlock"]}
scoreboard players set @e[type=marker,tag=MapVote,tag=CubeBlock] MapValues 23
function mcm:lobby/options/map_toggle/init
