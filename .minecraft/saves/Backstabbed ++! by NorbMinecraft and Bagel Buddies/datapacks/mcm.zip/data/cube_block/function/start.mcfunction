execute unless score $selectedMap CmdData matches 23 run return 0
execute unless score $gamestate CmdData matches 1 run return 0
time set 6000
execute as @a[tag=queued,tag=!spectating,gamemode=!spectator] unless score @s dead matches 1.. run function cube_block:give_hook
