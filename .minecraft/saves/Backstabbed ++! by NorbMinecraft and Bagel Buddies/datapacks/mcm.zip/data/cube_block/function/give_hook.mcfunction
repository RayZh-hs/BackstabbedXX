execute unless score $selectedMap CmdData matches 23 run return 0
execute unless score $gamestate CmdData matches 1 run return 0
execute unless entity @s[tag=queued,tag=!spectating,gamemode=!spectator] run return 0
execute if score @s dead matches 1.. run return 0
function cube_block:cleanup_player
tag @s add CubeBlockHook
item replace entity @s hotbar.0 with gravity_changer:grappling_hook[custom_data={cube_block_hook:1b,NoDrop:1b,no_drop_on_death:1b}]
