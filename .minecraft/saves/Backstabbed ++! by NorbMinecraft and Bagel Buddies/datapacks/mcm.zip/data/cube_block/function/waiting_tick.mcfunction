execute unless score $selectedMap CmdData matches 23 run return 0
execute unless score $gamestate CmdData matches 0 run return 0
execute as @a[tag=CubeBlockHook] run function cube_block:cleanup_player
