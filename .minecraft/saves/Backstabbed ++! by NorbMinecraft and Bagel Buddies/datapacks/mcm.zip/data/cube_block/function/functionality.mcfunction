execute unless score $selectedMap CmdData matches 23 run return 0
execute unless score $gamestate CmdData matches 1 run return 0
execute as @a[tag=CubeBlockHook,tag=!queued] run function cube_block:cleanup_player
execute as @a[tag=CubeBlockHook,tag=spectating] run function cube_block:cleanup_player
execute as @a[tag=CubeBlockHook,gamemode=spectator] run function cube_block:cleanup_player
execute as @a[tag=CubeBlockHook,scores={dead=1..}] run function cube_block:cleanup_player
execute as @a[tag=queued,tag=!spectating,gamemode=!spectator] at @s unless score @s dead matches 1.. unless predicate cube_block:arena run function cube_block:fall
