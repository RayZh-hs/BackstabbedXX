gravity bridge reset @s
tp @s 49196.5 88 49202.5 0 0
