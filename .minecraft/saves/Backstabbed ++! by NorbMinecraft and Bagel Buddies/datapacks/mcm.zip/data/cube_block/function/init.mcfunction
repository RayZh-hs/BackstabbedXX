scoreboard objectives add cube_owner dummy
