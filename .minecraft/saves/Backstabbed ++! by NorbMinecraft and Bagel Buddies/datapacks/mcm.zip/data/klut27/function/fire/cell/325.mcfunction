execute unless block 36873 21 36885 minecraft:cherry_wood run return run function klut27:fire/skip
scoreboard players set @s kf_age -1
execute store result score $tile kf run gamerule doTileDrops
execute store result score $entity kf run gamerule doEntityDrops
execute store result score $mob kf run gamerule doMobLoot
gamerule doTileDrops false
gamerule doEntityDrops false
gamerule doMobLoot false
setblock 36873 21 36885 air
scoreboard players set @e[tag=Klut27Fire325] kf_age -1
execute if score $tile kf matches 1 run gamerule doTileDrops true
execute if score $entity kf matches 1 run gamerule doEntityDrops true
execute if score $mob kf matches 1 run gamerule doMobLoot true
execute if block 36873 20 36885 minecraft:mangrove_wood run scoreboard players set @e[tag=Klut27Fire317,scores={kf_age=0}] kf_age 1
execute if block 36873 21 36884 minecraft:cherry_wood run scoreboard players set @e[tag=Klut27Fire324,scores={kf_age=0}] kf_age 1
execute if block 36873 21 36886 minecraft:cherry_wood run scoreboard players set @e[tag=Klut27Fire326,scores={kf_age=0}] kf_age 1
