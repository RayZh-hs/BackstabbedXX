execute unless block 36869 13 36888 minecraft:stripped_jungle_wood run return run function klut27:fire/skip
scoreboard players set @s kf_age -1
execute store result score $tile kf run gamerule doTileDrops
execute store result score $entity kf run gamerule doEntityDrops
execute store result score $mob kf run gamerule doMobLoot
gamerule doTileDrops false
gamerule doEntityDrops false
gamerule doMobLoot false
setblock 36869 13 36888 air
scoreboard players set @e[tag=Klut27Fire117] kf_age -1
execute if score $tile kf matches 1 run gamerule doTileDrops true
execute if score $entity kf matches 1 run gamerule doEntityDrops true
execute if score $mob kf matches 1 run gamerule doMobLoot true
execute if block 36869 12 36888 minecraft:stripped_jungle_wood run scoreboard players set @e[tag=Klut27Fire111,scores={kf_age=0}] kf_age 1
execute if block 36869 13 36887 minecraft:stripped_jungle_wood run scoreboard players set @e[tag=Klut27Fire116,scores={kf_age=0}] kf_age 1
execute if block 36869 13 36889 minecraft:stripped_jungle_wood run scoreboard players set @e[tag=Klut27Fire118,scores={kf_age=0}] kf_age 1
execute if block 36869 14 36888 minecraft:dark_oak_slab run scoreboard players set @e[tag=Klut27Fire122,scores={kf_age=0}] kf_age 1
