execute unless block 36874 27 36874 minecraft:stripped_oak_wood run return run function klut27:fire/skip
scoreboard players set @s kf_age -1
execute store result score $tile kf run gamerule doTileDrops
execute store result score $entity kf run gamerule doEntityDrops
execute store result score $mob kf run gamerule doMobLoot
gamerule doTileDrops false
gamerule doEntityDrops false
gamerule doMobLoot false
setblock 36874 27 36874 air
scoreboard players set @e[tag=Klut27Fire448] kf_age -1
execute if score $tile kf matches 1 run gamerule doTileDrops true
execute if score $entity kf matches 1 run gamerule doEntityDrops true
execute if score $mob kf matches 1 run gamerule doMobLoot true
execute if block 36873 27 36874 minecraft:stripped_oak_wood run scoreboard players set @e[tag=Klut27Fire365,scores={kf_age=0}] kf_age 1
execute if block 36874 26 36874 minecraft:stripped_oak_wood run scoreboard players set @e[tag=Klut27Fire439,scores={kf_age=0}] kf_age 1
execute if block 36874 27 36873 minecraft:stripped_oak_wood run scoreboard players set @e[tag=Klut27Fire447,scores={kf_age=0}] kf_age 1
execute if block 36874 27 36875 minecraft:stripped_oak_wood run scoreboard players set @e[tag=Klut27Fire449,scores={kf_age=0}] kf_age 1
