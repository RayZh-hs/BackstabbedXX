execute unless block 36873 25 36876 minecraft:stripped_birch_wood run return run function klut27:fire/skip
scoreboard players set @s kf_age -1
execute store result score $tile kf run gamerule doTileDrops
execute store result score $entity kf run gamerule doEntityDrops
execute store result score $mob kf run gamerule doMobLoot
gamerule doTileDrops false
gamerule doEntityDrops false
gamerule doMobLoot false
setblock 36873 25 36876 air
scoreboard players set @e[tag=Klut27Fire344] kf_age -1
execute if score $tile kf matches 1 run gamerule doTileDrops true
execute if score $entity kf matches 1 run gamerule doEntityDrops true
execute if score $mob kf matches 1 run gamerule doMobLoot true
execute if block 36872 25 36876 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire278,scores={kf_age=0}] kf_age 1
execute if block 36873 25 36877 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire345,scores={kf_age=0}] kf_age 1
execute if block 36873 26 36876 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire355,scores={kf_age=0}] kf_age 1
