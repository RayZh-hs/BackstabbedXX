execute unless block 36873 23 36880 minecraft:mangrove_wood run return run function klut27:fire/skip
scoreboard players set @s kf_age -1
execute store result score $tile kf run gamerule doTileDrops
execute store result score $entity kf run gamerule doEntityDrops
execute store result score $mob kf run gamerule doMobLoot
gamerule doTileDrops false
gamerule doEntityDrops false
gamerule doMobLoot false
setblock 36873 23 36880 air
scoreboard players set @e[tag=Klut27Fire333] kf_age -1
execute if score $tile kf matches 1 run gamerule doTileDrops true
execute if score $entity kf matches 1 run gamerule doEntityDrops true
execute if score $mob kf matches 1 run gamerule doMobLoot true
execute if block 36873 22 36880 minecraft:cherry_wood run scoreboard players set @e[tag=Klut27Fire328,scores={kf_age=0}] kf_age 1
execute if block 36873 23 36881 minecraft:cherry_wood run scoreboard players set @e[tag=Klut27Fire334,scores={kf_age=0}] kf_age 1
execute if block 36873 24 36880 minecraft:cherry_wood run scoreboard players set @e[tag=Klut27Fire337,scores={kf_age=0}] kf_age 1
