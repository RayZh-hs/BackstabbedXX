execute unless block 36866 16 36881 minecraft:purple_carpet run return run function klut27:fire/skip
scoreboard players set @s kf_age -1
execute store result score $tile kf run gamerule doTileDrops
execute store result score $entity kf run gamerule doEntityDrops
execute store result score $mob kf run gamerule doMobLoot
gamerule doTileDrops false
gamerule doEntityDrops false
gamerule doMobLoot false
setblock 36866 16 36881 air
scoreboard players set @e[tag=Klut27Fire16] kf_age -1
execute if score $tile kf matches 1 run gamerule doTileDrops true
execute if score $entity kf matches 1 run gamerule doEntityDrops true
execute if score $mob kf matches 1 run gamerule doMobLoot true
execute if block 36865 16 36881 minecraft:mangrove_slab run scoreboard players set @e[tag=Klut27Fire0,scores={kf_age=0}] kf_age 1
execute if block 36867 16 36881 minecraft:purple_carpet run scoreboard players set @e[tag=Klut27Fire36,scores={kf_age=0}] kf_age 1
