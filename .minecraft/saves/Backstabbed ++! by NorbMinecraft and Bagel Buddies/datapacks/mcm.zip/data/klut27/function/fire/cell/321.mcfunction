execute unless block 36873 21 36881 minecraft:cherry_wood run return run function klut27:fire/skip
scoreboard players set @s kf_age -1
execute store result score $tile kf run gamerule doTileDrops
execute store result score $entity kf run gamerule doEntityDrops
execute store result score $mob kf run gamerule doMobLoot
gamerule doTileDrops false
gamerule doEntityDrops false
gamerule doMobLoot false
setblock 36873 21 36881 air
scoreboard players set @e[tag=Klut27Fire321] kf_age -1
execute if score $tile kf matches 1 run gamerule doTileDrops true
execute if score $entity kf matches 1 run gamerule doEntityDrops true
execute if score $mob kf matches 1 run gamerule doMobLoot true
execute if block 36873 20 36881 minecraft:mangrove_wood run scoreboard players set @e[tag=Klut27Fire313,scores={kf_age=0}] kf_age 1
execute if block 36873 21 36882 minecraft:cherry_wood run scoreboard players set @e[tag=Klut27Fire322,scores={kf_age=0}] kf_age 1
execute if block 36873 22 36881 minecraft:mangrove_wood run scoreboard players set @e[tag=Klut27Fire329,scores={kf_age=0}] kf_age 1
execute if block 36874 21 36881 minecraft:cherry_planks run scoreboard players set @e[tag=Klut27Fire419,scores={kf_age=0}] kf_age 1
