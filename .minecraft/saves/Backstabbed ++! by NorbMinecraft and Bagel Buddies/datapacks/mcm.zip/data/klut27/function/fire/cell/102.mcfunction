execute unless block 36869 11 36886 minecraft:black_banner run return run function klut27:fire/skip
scoreboard players set @s kf_age -1
execute store result score $tile kf run gamerule doTileDrops
execute store result score $entity kf run gamerule doEntityDrops
execute store result score $mob kf run gamerule doMobLoot
gamerule doTileDrops false
gamerule doEntityDrops false
gamerule doMobLoot false
data remove block 36869 11 36886 Items
setblock 36869 11 36886 air
scoreboard players set @e[tag=Klut27Fire102] kf_age -1
execute if score $tile kf matches 1 run gamerule doTileDrops true
execute if score $entity kf matches 1 run gamerule doEntityDrops true
execute if score $mob kf matches 1 run gamerule doMobLoot true
setblock 36869 11 36886 black_carpet
execute if block 36869 11 36885 minecraft:black_banner run scoreboard players set @e[tag=Klut27Fire101,scores={kf_age=0}] kf_age 1
execute if block 36869 11 36887 minecraft:black_banner run scoreboard players set @e[tag=Klut27Fire103,scores={kf_age=0}] kf_age 1
execute if block 36869 12 36886 minecraft:spruce_hanging_sign run scoreboard players set @e[tag=Klut27Fire109,scores={kf_age=0}] kf_age 1
