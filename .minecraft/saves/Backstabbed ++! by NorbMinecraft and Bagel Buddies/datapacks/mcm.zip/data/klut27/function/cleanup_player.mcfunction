execute unless entity @s[tag=Klut27Hook] run return 0
function klut27:hook_cancel
tag @s remove gravity_hook_no_cooldown
tag @s remove Klut27Hook
scoreboard players set @s klut_air 0
clear @s gravity_changer:grappling_hook[custom_data~{klut27_hook:1b}]
clear @s minecraft:stick[custom_data~{klut27_hook:1b}]
