execute unless block 36871 15 36886 minecraft:dark_oak_planks run return run function klut27:fire/skip
scoreboard players set @s kf_age -1
execute store result score $tile kf run gamerule doTileDrops
execute store result score $entity kf run gamerule doEntityDrops
execute store result score $mob kf run gamerule doMobLoot
gamerule doTileDrops false
gamerule doEntityDrops false
gamerule doMobLoot false
setblock 36871 15 36886 air
scoreboard players set @e[tag=Klut27Fire221] kf_age -1
execute if score $tile kf matches 1 run gamerule doTileDrops true
execute if score $entity kf matches 1 run gamerule doEntityDrops true
execute if score $mob kf matches 1 run gamerule doMobLoot true
execute if block 36870 15 36886 minecraft:dark_oak_planks run scoreboard players set @e[tag=Klut27Fire169,scores={kf_age=0}] kf_age 1
execute if block 36871 14 36886 minecraft:dark_oak_planks run scoreboard players set @e[tag=Klut27Fire219,scores={kf_age=0}] kf_age 1
execute if block 36872 15 36886 minecraft:dark_oak_planks run scoreboard players set @e[tag=Klut27Fire270,scores={kf_age=0}] kf_age 1
