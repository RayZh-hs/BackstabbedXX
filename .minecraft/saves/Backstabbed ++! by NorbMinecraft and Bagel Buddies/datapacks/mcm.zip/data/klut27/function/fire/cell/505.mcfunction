execute unless block 36876 18 36885 minecraft:cherry_planks run return run function klut27:fire/skip
scoreboard players set @s kf_age -1
execute store result score $tile kf run gamerule doTileDrops
execute store result score $entity kf run gamerule doEntityDrops
execute store result score $mob kf run gamerule doMobLoot
gamerule doTileDrops false
gamerule doEntityDrops false
gamerule doMobLoot false
setblock 36876 18 36885 air
scoreboard players set @e[tag=Klut27Fire505] kf_age -1
execute if score $tile kf matches 1 run gamerule doTileDrops true
execute if score $entity kf matches 1 run gamerule doEntityDrops true
execute if score $mob kf matches 1 run gamerule doMobLoot true
execute if block 36875 18 36885 minecraft:stripped_oak_wood run scoreboard players set @e[tag=Klut27Fire461,scores={kf_age=0}] kf_age 1
execute if block 36876 18 36884 minecraft:stripped_oak_wood run scoreboard players set @e[tag=Klut27Fire504,scores={kf_age=0}] kf_age 1
execute if block 36876 18 36886 minecraft:stripped_oak_wood run scoreboard players set @e[tag=Klut27Fire506,scores={kf_age=0}] kf_age 1
execute if block 36877 18 36885 minecraft:stripped_oak_wood run scoreboard players set @e[tag=Klut27Fire550,scores={kf_age=0}] kf_age 1
