scoreboard players add @e[tag=Klut27Fire,scores={kf_age=1..60}] kf_age 1
execute as @e[tag=Klut27Fire,scores={kf_age=1..60}] at @s run particle flame ~ ~0.3 ~ 0.3 0.35 0.3 0.01 2 force
execute as @e[tag=Klut27Fire,scores={kf_age=1..60}] at @s run particle smoke ~ ~0.5 ~ 0.2 0.3 0.2 0.01 1 force
execute as @e[tag=Klut27Fire,scores={kf_age=61}] at @s run function klut27:fire/dispatch with entity @s data
function klut27:fire/check_elevators
execute unless entity @e[tag=Klut27Fire,scores={kf_age=1..60}] run function klut27:fire/finish
