execute unless block 36874 18 36891 minecraft:white_wall_banner run return run function klut27:fire/skip
scoreboard players set @s kf_age -1
execute store result score $tile kf run gamerule doTileDrops
execute store result score $entity kf run gamerule doEntityDrops
execute store result score $mob kf run gamerule doMobLoot
gamerule doTileDrops false
gamerule doEntityDrops false
gamerule doMobLoot false
data remove block 36874 18 36891 Items
setblock 36874 18 36891 air
scoreboard players set @e[tag=Klut27Fire395] kf_age -1
execute if score $tile kf matches 1 run gamerule doTileDrops true
execute if score $entity kf matches 1 run gamerule doEntityDrops true
execute if score $mob kf matches 1 run gamerule doMobLoot true
execute if block 36874 18 36890 minecraft:white_wall_banner run scoreboard players set @e[tag=Klut27Fire394,scores={kf_age=0}] kf_age 1
execute if block 36874 18 36892 minecraft:white_wall_banner run scoreboard players set @e[tag=Klut27Fire396,scores={kf_age=0}] kf_age 1
execute if block 36874 19 36891 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire407,scores={kf_age=0}] kf_age 1
