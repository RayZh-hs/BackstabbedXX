execute unless block 36875 25 36888 minecraft:stripped_birch_wood run return run function klut27:fire/skip
scoreboard players set @s kf_age -1
execute store result score $tile kf run gamerule doTileDrops
execute store result score $entity kf run gamerule doEntityDrops
execute store result score $mob kf run gamerule doMobLoot
gamerule doTileDrops false
gamerule doEntityDrops false
gamerule doMobLoot false
setblock 36875 25 36888 air
scoreboard players set @e[tag=Klut27Fire488] kf_age -1
execute if score $tile kf matches 1 run gamerule doTileDrops true
execute if score $entity kf matches 1 run gamerule doEntityDrops true
execute if score $mob kf matches 1 run gamerule doMobLoot true
execute if block 36874 25 36888 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire434,scores={kf_age=0}] kf_age 1
execute if block 36875 25 36887 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire487,scores={kf_age=0}] kf_age 1
execute if block 36875 25 36889 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire489,scores={kf_age=0}] kf_age 1
execute if block 36875 26 36888 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire493,scores={kf_age=0}] kf_age 1
execute if block 36876 25 36888 minecraft:birch_planks run scoreboard players set @e[tag=Klut27Fire533,scores={kf_age=0}] kf_age 1
