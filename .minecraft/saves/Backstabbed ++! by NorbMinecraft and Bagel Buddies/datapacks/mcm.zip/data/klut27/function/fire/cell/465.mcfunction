execute unless block 36875 19 36889 minecraft:stripped_birch_wood run return run function klut27:fire/skip
scoreboard players set @s kf_age -1
execute store result score $tile kf run gamerule doTileDrops
execute store result score $entity kf run gamerule doEntityDrops
execute store result score $mob kf run gamerule doMobLoot
gamerule doTileDrops false
gamerule doEntityDrops false
gamerule doMobLoot false
setblock 36875 19 36889 air
scoreboard players set @e[tag=Klut27Fire465] kf_age -1
execute if score $tile kf matches 1 run gamerule doTileDrops true
execute if score $entity kf matches 1 run gamerule doEntityDrops true
execute if score $mob kf matches 1 run gamerule doMobLoot true
execute if block 36874 19 36889 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire405,scores={kf_age=0}] kf_age 1
execute if block 36875 19 36888 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire464,scores={kf_age=0}] kf_age 1
execute if block 36875 19 36890 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire466,scores={kf_age=0}] kf_age 1
execute if block 36875 20 36889 minecraft:cherry_planks run scoreboard players set @e[tag=Klut27Fire470,scores={kf_age=0}] kf_age 1
execute if block 36876 19 36889 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire509,scores={kf_age=0}] kf_age 1
