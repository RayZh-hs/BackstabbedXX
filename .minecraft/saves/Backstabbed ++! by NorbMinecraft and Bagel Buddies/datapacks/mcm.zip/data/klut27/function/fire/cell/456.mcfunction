execute unless block 36875 16 36882 minecraft:cherry_wood run return run function klut27:fire/skip
scoreboard players set @s kf_age -1
execute store result score $tile kf run gamerule doTileDrops
execute store result score $entity kf run gamerule doEntityDrops
execute store result score $mob kf run gamerule doMobLoot
gamerule doTileDrops false
gamerule doEntityDrops false
gamerule doMobLoot false
setblock 36875 16 36882 air
scoreboard players set @e[tag=Klut27Fire456] kf_age -1
execute if score $tile kf matches 1 run gamerule doTileDrops true
execute if score $entity kf matches 1 run gamerule doEntityDrops true
execute if score $mob kf matches 1 run gamerule doMobLoot true
execute if block 36874 16 36882 minecraft:orange_banner run scoreboard players set @e[tag=Klut27Fire377,scores={kf_age=0}] kf_age 1
execute if block 36875 17 36882 minecraft:mangrove_wood run scoreboard players set @e[tag=Klut27Fire457,scores={kf_age=0}] kf_age 1
