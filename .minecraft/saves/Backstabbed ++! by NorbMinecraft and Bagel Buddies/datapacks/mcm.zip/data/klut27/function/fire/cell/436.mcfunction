execute unless block 36874 25 36890 minecraft:stripped_birch_wood run return run function klut27:fire/skip
scoreboard players set @s kf_age -1
execute store result score $tile kf run gamerule doTileDrops
execute store result score $entity kf run gamerule doEntityDrops
execute store result score $mob kf run gamerule doMobLoot
gamerule doTileDrops false
gamerule doEntityDrops false
gamerule doMobLoot false
setblock 36874 25 36890 air
scoreboard players set @e[tag=Klut27Fire436] kf_age -1
execute if score $tile kf matches 1 run gamerule doTileDrops true
execute if score $entity kf matches 1 run gamerule doEntityDrops true
execute if score $mob kf matches 1 run gamerule doMobLoot true
execute if block 36874 24 36890 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire431,scores={kf_age=0}] kf_age 1
execute if block 36874 25 36889 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire435,scores={kf_age=0}] kf_age 1
execute if block 36874 25 36891 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire437,scores={kf_age=0}] kf_age 1
execute if block 36875 25 36890 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire490,scores={kf_age=0}] kf_age 1
