execute unless block 36873 26 36875 minecraft:stripped_oak_wood run return run function klut27:fire/skip
scoreboard players set @s kf_age -1
execute store result score $tile kf run gamerule doTileDrops
execute store result score $entity kf run gamerule doEntityDrops
execute store result score $mob kf run gamerule doMobLoot
gamerule doTileDrops false
gamerule doEntityDrops false
gamerule doMobLoot false
setblock 36873 26 36875 air
scoreboard players set @e[tag=Klut27Fire354] kf_age -1
execute if score $tile kf matches 1 run gamerule doTileDrops true
execute if score $entity kf matches 1 run gamerule doEntityDrops true
execute if score $mob kf matches 1 run gamerule doMobLoot true
execute if block 36872 26 36875 minecraft:stripped_oak_wood run scoreboard players set @e[tag=Klut27Fire287,scores={kf_age=0}] kf_age 1
execute if block 36873 26 36874 minecraft:stripped_oak_wood run scoreboard players set @e[tag=Klut27Fire353,scores={kf_age=0}] kf_age 1
execute if block 36873 26 36876 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire355,scores={kf_age=0}] kf_age 1
execute if block 36873 27 36875 minecraft:stripped_oak_wood run scoreboard players set @e[tag=Klut27Fire366,scores={kf_age=0}] kf_age 1
execute if block 36874 26 36875 minecraft:stripped_oak_wood run scoreboard players set @e[tag=Klut27Fire440,scores={kf_age=0}] kf_age 1
