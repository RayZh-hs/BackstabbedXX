execute unless block 36870 18 36885 minecraft:stripped_cherry_wood run return run function klut27:fire/skip
scoreboard players set @s kf_age -1
execute store result score $tile kf run gamerule doTileDrops
execute store result score $entity kf run gamerule doEntityDrops
execute store result score $mob kf run gamerule doMobLoot
gamerule doTileDrops false
gamerule doEntityDrops false
gamerule doMobLoot false
data remove block 36871 18 36885 Items
setblock 36871 18 36885 air
scoreboard players set @e[tag=Klut27Fire226] kf_age -1
setblock 36870 18 36885 air
scoreboard players set @e[tag=Klut27Fire173] kf_age -1
execute if score $tile kf matches 1 run gamerule doTileDrops true
execute if score $entity kf matches 1 run gamerule doEntityDrops true
execute if score $mob kf matches 1 run gamerule doMobLoot true
execute if block 36869 18 36885 minecraft:stripped_cherry_wood run scoreboard players set @e[tag=Klut27Fire133,scores={kf_age=0}] kf_age 1
execute if block 36870 18 36884 minecraft:stripped_mangrove_wood run scoreboard players set @e[tag=Klut27Fire172,scores={kf_age=0}] kf_age 1
execute if block 36871 18 36885 minecraft:black_wall_banner run scoreboard players set @e[tag=Klut27Fire226,scores={kf_age=0}] kf_age 1
