execute unless block 36874 22 36886 minecraft:spruce_planks run return run function klut27:fire/skip
scoreboard players set @s kf_age -1
execute store result score $tile kf run gamerule doTileDrops
execute store result score $entity kf run gamerule doEntityDrops
execute store result score $mob kf run gamerule doMobLoot
gamerule doTileDrops false
gamerule doEntityDrops false
gamerule doMobLoot false
setblock 36874 22 36886 air
scoreboard players set @e[tag=Klut27Fire425] kf_age -1
setblock 36874 21 36886 air
execute if score $tile kf matches 1 run gamerule doTileDrops true
execute if score $entity kf matches 1 run gamerule doEntityDrops true
execute if score $mob kf matches 1 run gamerule doMobLoot true
execute if block 36873 22 36886 minecraft:mangrove_wood run scoreboard players set @e[tag=Klut27Fire330,scores={kf_age=0}] kf_age 1
execute if block 36874 22 36885 minecraft:spruce_planks run scoreboard players set @e[tag=Klut27Fire424,scores={kf_age=0}] kf_age 1
execute if block 36874 22 36887 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire426,scores={kf_age=0}] kf_age 1
execute if block 36875 22 36886 minecraft:spruce_planks run scoreboard players set @e[tag=Klut27Fire480,scores={kf_age=0}] kf_age 1
