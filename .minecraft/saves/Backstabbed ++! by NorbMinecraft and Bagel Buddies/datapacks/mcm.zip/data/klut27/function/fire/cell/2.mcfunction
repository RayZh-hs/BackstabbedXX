execute unless block 36865 16 36884 minecraft:mangrove_slab run return run function klut27:fire/skip
scoreboard players set @s kf_age -1
execute store result score $tile kf run gamerule doTileDrops
execute store result score $entity kf run gamerule doEntityDrops
execute store result score $mob kf run gamerule doMobLoot
gamerule doTileDrops false
gamerule doEntityDrops false
gamerule doMobLoot false
setblock 36865 16 36884 air
scoreboard players set @e[tag=Klut27Fire2] kf_age -1
execute if score $tile kf matches 1 run gamerule doTileDrops true
execute if score $entity kf matches 1 run gamerule doEntityDrops true
execute if score $mob kf matches 1 run gamerule doMobLoot true
execute if block 36865 16 36883 minecraft:mangrove_slab run scoreboard players set @e[tag=Klut27Fire1,scores={kf_age=0}] kf_age 1
execute if block 36865 17 36884 minecraft:mangrove_slab run scoreboard players set @e[tag=Klut27Fire6,scores={kf_age=0}] kf_age 1
