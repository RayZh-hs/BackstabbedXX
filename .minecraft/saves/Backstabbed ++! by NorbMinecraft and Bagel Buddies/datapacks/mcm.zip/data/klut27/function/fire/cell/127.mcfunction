execute unless block 36869 16 36885 minecraft:stripped_cherry_wood run return run function klut27:fire/skip
scoreboard players set @s kf_age -1
execute store result score $tile kf run gamerule doTileDrops
execute store result score $entity kf run gamerule doEntityDrops
execute store result score $mob kf run gamerule doMobLoot
gamerule doTileDrops false
gamerule doEntityDrops false
gamerule doMobLoot false
setblock 36869 16 36885 air
scoreboard players set @e[tag=Klut27Fire127] kf_age -1
execute if score $tile kf matches 1 run gamerule doTileDrops true
execute if score $entity kf matches 1 run gamerule doEntityDrops true
execute if score $mob kf matches 1 run gamerule doMobLoot true
execute if block 36868 16 36885 minecraft:purple_carpet run scoreboard players set @e[tag=Klut27Fire75,scores={kf_age=0}] kf_age 1
execute if block 36869 15 36885 minecraft:dark_oak_planks run scoreboard players set @e[tag=Klut27Fire124,scores={kf_age=0}] kf_age 1
execute if block 36869 16 36884 minecraft:stripped_mangrove_wood run scoreboard players set @e[tag=Klut27Fire126,scores={kf_age=0}] kf_age 1
execute if block 36869 17 36885 minecraft:stripped_mangrove_wood run scoreboard players set @e[tag=Klut27Fire129,scores={kf_age=0}] kf_age 1
