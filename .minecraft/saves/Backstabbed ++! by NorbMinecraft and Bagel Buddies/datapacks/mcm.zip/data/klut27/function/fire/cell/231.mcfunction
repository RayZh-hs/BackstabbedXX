execute unless block 36871 23 36878 minecraft:stripped_birch_wood run return run function klut27:fire/skip
scoreboard players set @s kf_age -1
execute store result score $tile kf run gamerule doTileDrops
execute store result score $entity kf run gamerule doEntityDrops
execute store result score $mob kf run gamerule doMobLoot
gamerule doTileDrops false
gamerule doEntityDrops false
gamerule doMobLoot false
setblock 36871 23 36878 air
scoreboard players set @e[tag=Klut27Fire231] kf_age -1
execute if score $tile kf matches 1 run gamerule doTileDrops true
execute if score $entity kf matches 1 run gamerule doEntityDrops true
execute if score $mob kf matches 1 run gamerule doMobLoot true
execute if block 36871 22 36878 minecraft:stripped_cherry_wood run scoreboard players set @e[tag=Klut27Fire228,scores={kf_age=0}] kf_age 1
execute if block 36871 23 36877 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire230,scores={kf_age=0}] kf_age 1
execute if block 36871 23 36879 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire232,scores={kf_age=0}] kf_age 1
execute if block 36871 24 36878 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire234,scores={kf_age=0}] kf_age 1
execute if block 36872 23 36878 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire273,scores={kf_age=0}] kf_age 1
