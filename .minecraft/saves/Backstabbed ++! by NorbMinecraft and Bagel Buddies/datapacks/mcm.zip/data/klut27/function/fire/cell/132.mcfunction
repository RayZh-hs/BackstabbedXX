execute unless block 36869 18 36884 minecraft:stripped_mangrove_wood run return run function klut27:fire/skip
scoreboard players set @s kf_age -1
execute store result score $tile kf run gamerule doTileDrops
execute store result score $entity kf run gamerule doEntityDrops
execute store result score $mob kf run gamerule doMobLoot
gamerule doTileDrops false
gamerule doEntityDrops false
gamerule doMobLoot false
setblock 36869 18 36884 air
scoreboard players set @e[tag=Klut27Fire132] kf_age -1
execute if score $tile kf matches 1 run gamerule doTileDrops true
execute if score $entity kf matches 1 run gamerule doEntityDrops true
execute if score $mob kf matches 1 run gamerule doMobLoot true
execute if block 36868 18 36884 minecraft:stripped_cherry_wood run scoreboard players set @e[tag=Klut27Fire79,scores={kf_age=0}] kf_age 1
execute if block 36869 17 36884 minecraft:stripped_cherry_wood run scoreboard players set @e[tag=Klut27Fire128,scores={kf_age=0}] kf_age 1
execute if block 36869 18 36883 minecraft:stripped_cherry_wood run scoreboard players set @e[tag=Klut27Fire131,scores={kf_age=0}] kf_age 1
execute if block 36869 18 36885 minecraft:stripped_cherry_wood run scoreboard players set @e[tag=Klut27Fire133,scores={kf_age=0}] kf_age 1
execute if block 36869 19 36884 minecraft:stripped_cherry_wood run scoreboard players set @e[tag=Klut27Fire136,scores={kf_age=0}] kf_age 1
execute if block 36870 18 36884 minecraft:stripped_mangrove_wood run scoreboard players set @e[tag=Klut27Fire172,scores={kf_age=0}] kf_age 1
