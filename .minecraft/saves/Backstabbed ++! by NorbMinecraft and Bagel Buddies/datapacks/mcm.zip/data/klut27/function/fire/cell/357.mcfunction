execute unless block 36873 26 36878 minecraft:stripped_birch_wood run return run function klut27:fire/skip
scoreboard players set @s kf_age -1
execute store result score $tile kf run gamerule doTileDrops
execute store result score $entity kf run gamerule doEntityDrops
execute store result score $mob kf run gamerule doMobLoot
gamerule doTileDrops false
gamerule doEntityDrops false
gamerule doMobLoot false
setblock 36873 26 36878 air
scoreboard players set @e[tag=Klut27Fire357] kf_age -1
execute if score $tile kf matches 1 run gamerule doTileDrops true
execute if score $entity kf matches 1 run gamerule doEntityDrops true
execute if score $mob kf matches 1 run gamerule doMobLoot true
execute if block 36872 26 36878 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire290,scores={kf_age=0}] kf_age 1
execute if block 36873 25 36878 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire346,scores={kf_age=0}] kf_age 1
execute if block 36873 26 36877 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire356,scores={kf_age=0}] kf_age 1
execute if block 36873 26 36879 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire358,scores={kf_age=0}] kf_age 1
execute if block 36873 27 36878 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire369,scores={kf_age=0}] kf_age 1
