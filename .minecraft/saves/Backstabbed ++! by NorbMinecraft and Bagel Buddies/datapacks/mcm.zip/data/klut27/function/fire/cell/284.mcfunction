execute unless block 36872 25 36885 minecraft:cherry_planks run return run function klut27:fire/skip
scoreboard players set @s kf_age -1
execute store result score $tile kf run gamerule doTileDrops
execute store result score $entity kf run gamerule doEntityDrops
execute store result score $mob kf run gamerule doMobLoot
gamerule doTileDrops false
gamerule doEntityDrops false
gamerule doMobLoot false
setblock 36872 25 36885 air
scoreboard players set @e[tag=Klut27Fire284] kf_age -1
execute if score $tile kf matches 1 run gamerule doTileDrops true
execute if score $entity kf matches 1 run gamerule doEntityDrops true
execute if score $mob kf matches 1 run gamerule doMobLoot true
execute if block 36871 25 36885 minecraft:cherry_planks run scoreboard players set @e[tag=Klut27Fire243,scores={kf_age=0}] kf_age 1
execute if block 36872 25 36884 minecraft:cherry_planks run scoreboard players set @e[tag=Klut27Fire283,scores={kf_age=0}] kf_age 1
execute if block 36872 25 36886 minecraft:cherry_planks run scoreboard players set @e[tag=Klut27Fire285,scores={kf_age=0}] kf_age 1
execute if block 36873 25 36885 minecraft:cherry_planks run scoreboard players set @e[tag=Klut27Fire351,scores={kf_age=0}] kf_age 1
