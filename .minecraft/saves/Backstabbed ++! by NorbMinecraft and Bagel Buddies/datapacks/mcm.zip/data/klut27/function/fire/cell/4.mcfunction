execute unless block 36865 17 36882 minecraft:mangrove_slab run return run function klut27:fire/skip
scoreboard players set @s kf_age -1
execute store result score $tile kf run gamerule doTileDrops
execute store result score $entity kf run gamerule doEntityDrops
execute store result score $mob kf run gamerule doMobLoot
gamerule doTileDrops false
gamerule doEntityDrops false
gamerule doMobLoot false
setblock 36865 17 36882 air
scoreboard players set @e[tag=Klut27Fire4] kf_age -1
execute if score $tile kf matches 1 run gamerule doTileDrops true
execute if score $entity kf matches 1 run gamerule doEntityDrops true
execute if score $mob kf matches 1 run gamerule doMobLoot true
execute if block 36865 17 36881 minecraft:mangrove_slab run scoreboard players set @e[tag=Klut27Fire3,scores={kf_age=0}] kf_age 1
execute if block 36865 17 36883 minecraft:mangrove_slab run scoreboard players set @e[tag=Klut27Fire5,scores={kf_age=0}] kf_age 1
execute if block 36865 18 36882 minecraft:stripped_mangrove_wood run scoreboard players set @e[tag=Klut27Fire8,scores={kf_age=0}] kf_age 1
