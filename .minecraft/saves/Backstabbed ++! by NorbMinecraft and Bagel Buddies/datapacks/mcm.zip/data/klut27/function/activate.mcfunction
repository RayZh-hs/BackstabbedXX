execute unless score $selectedMap CmdData matches 20 run return 0
execute unless score $gamestate CmdData matches 0..1 run return 0
kill @e[tag=MapEntity]
tag @a remove Klut27Participant
function klut27:fire/reset
function klut27:restore_blocks
gamerule doFireTick false
summon marker 36873.5 16 36879.5 {Tags:["PlayerSpawn","MapEntity","Klut27Runtime"],Rotation:[90.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36871.5 -35 36871.5 {Tags:["PlayerSpawn","MapEntity","Klut27Runtime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36868.5 15 36908.5 {Tags:["PlayerSpawn","MapEntity","Klut27Runtime"],Rotation:[-90.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36876.5 -12 36878.5 {Tags:["PlayerSpawn","MapEntity","Klut27Runtime"],Rotation:[-180.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36870.5 33 36865.5 {Tags:["PlayerSpawn","MapEntity","Klut27Runtime"],Rotation:[-90.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36874.5 15 36897.5 {Tags:["PlayerSpawn","MapEntity","Klut27Runtime"],Rotation:[90.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36868.5 -12 36868.5 {Tags:["PlayerSpawn","MapEntity","Klut27Runtime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36879.5 15 36909.5 {Tags:["PlayerSpawn","MapEntity","Klut27Runtime"],Rotation:[90.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36873.5 28 36876.5 {Tags:["PlayerSpawn","MapEntity","Klut27Runtime"],Rotation:[-180.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36870.5 15 36888.5 {Tags:["PlayerSpawn","MapEntity","Klut27Runtime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36870.5 15 36905.5 {Tags:["PlayerSpawn","MapEntity","Klut27Runtime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36868.5 -12 36877.5 {Tags:["PlayerSpawn","MapEntity","Klut27Runtime"],Rotation:[-180.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36873.5 -15 36872.5 {Tags:["PlayerSpawn","MapEntity","Klut27Runtime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36876.5 15 36911.5 {Tags:["PlayerSpawn","MapEntity","Klut27Runtime"],Rotation:[90.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36871.5 28 36870.5 {Tags:["PlayerSpawn","MapEntity","Klut27Runtime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36869.5 15 36894.5 {Tags:["PlayerSpawn","MapEntity","Klut27Runtime"],Rotation:[-90.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36869.5 15 36900.5 {Tags:["PlayerSpawn","MapEntity","Klut27Runtime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36874.5 -12 36868.5 {Tags:["PlayerSpawn","MapEntity","Klut27Runtime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36873.5 16 36884.5 {Tags:["PlayerSpawn","MapEntity","Klut27Runtime"],Rotation:[90.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36874.5 15 36908.5 {Tags:["PlayerSpawn","MapEntity","Klut27Runtime"],Rotation:[90.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36871.5 28 36880.5 {Tags:["PlayerSpawn","MapEntity","Klut27Runtime"],Rotation:[-180.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36872.5 33 36869.5 {Tags:["PlayerSpawn","MapEntity","Klut27Runtime"],Rotation:[-180.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36870.5 -12 36873.5 {Tags:["PlayerSpawn","MapEntity","Klut27Runtime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36870.5 15 36910.5 {Tags:["PlayerSpawn","MapEntity","Klut27Runtime"],Rotation:[-90.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36877.5 15 36905.5 {Tags:["PlayerSpawn","MapEntity","Klut27Runtime"],Rotation:[0.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36874.5 33 36865.5 {Tags:["PlayerSpawn","MapEntity","Klut27Runtime"],Rotation:[90.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36874.5 -12 36874.5 {Tags:["PlayerSpawn","MapEntity","Klut27Runtime"],Rotation:[90.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36865.5 15 36910.5 {Tags:["PlayerSpawn","MapEntity","Klut27Runtime"],Rotation:[-90.0f,0.0f],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36873.5 18 36879.5 {Tags:["SpectatorSpawn","MapEntity","Klut27Runtime"]}
tellraw @a {"translate":"klut27.ready","fallback":"KLUT-27 ready","color":"aqua"}
scoreboard players set @a klut_air 0
function klut27:npc_reset
function klut27:residents/reset
summon marker 36878.5 16 36884.5 {Tags:["ScrapSpawn","MapEntity","Klut27Runtime"],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36871.5 15 36902.5 {Tags:["ScrapSpawn","MapEntity","Klut27Runtime"],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36868.5 15 36908.5 {Tags:["ScrapSpawn","MapEntity","Klut27Runtime"],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36872.5 15 36909.5 {Tags:["ScrapSpawn","MapEntity","Klut27Runtime"],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36871.5 15 36907.5 {Tags:["ScrapSpawn","MapEntity","Klut27Runtime"],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36874.5 15 36897.5 {Tags:["ScrapSpawn","MapEntity","Klut27Runtime"],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36876.5 15 36907.5 {Tags:["ScrapSpawn","MapEntity","Klut27Runtime"],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36879.5 15 36909.5 {Tags:["ScrapSpawn","MapEntity","Klut27Runtime"],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36868.5 15 36911.5 {Tags:["ScrapSpawn","MapEntity","Klut27Runtime"],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36870.5 15 36888.5 {Tags:["ScrapSpawn","MapEntity","Klut27Runtime"],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36870.5 15 36905.5 {Tags:["ScrapSpawn","MapEntity","Klut27Runtime"],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36871.5 15 36899.5 {Tags:["ScrapSpawn","MapEntity","Klut27Runtime"],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36875.5 15 36913.5 {Tags:["ScrapSpawn","MapEntity","Klut27Runtime"],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36876.5 15 36911.5 {Tags:["ScrapSpawn","MapEntity","Klut27Runtime"],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36873.5 15 36906.5 {Tags:["ScrapSpawn","MapEntity","Klut27Runtime"],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36869.5 15 36894.5 {Tags:["ScrapSpawn","MapEntity","Klut27Runtime"],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36869.5 15 36900.5 {Tags:["ScrapSpawn","MapEntity","Klut27Runtime"],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36874.5 15 36910.5 {Tags:["ScrapSpawn","MapEntity","Klut27Runtime"],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36876.5 15 36909.5 {Tags:["ScrapSpawn","MapEntity","Klut27Runtime"],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36874.5 15 36908.5 {Tags:["ScrapSpawn","MapEntity","Klut27Runtime"],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36878.5 15 36907.5 {Tags:["ScrapSpawn","MapEntity","Klut27Runtime"],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36872.5 15 36895.5 {Tags:["ScrapSpawn","MapEntity","Klut27Runtime"],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36876.5 16 36882.5 {Tags:["ScrapSpawn","MapEntity","Klut27Runtime"],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36870.5 15 36910.5 {Tags:["ScrapSpawn","MapEntity","Klut27Runtime"],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36877.5 15 36905.5 {Tags:["ScrapSpawn","MapEntity","Klut27Runtime"],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36872.5 15 36889.5 {Tags:["ScrapSpawn","MapEntity","Klut27Runtime"],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36875.5 15 36895.5 {Tags:["ScrapSpawn","MapEntity","Klut27Runtime"],data:{gravity_direction:"down",gravity_strength:1.0d}}
summon marker 36865.5 15 36910.5 {Tags:["ScrapSpawn","MapEntity","Klut27Runtime"],data:{gravity_direction:"down",gravity_strength:1.0d}}
