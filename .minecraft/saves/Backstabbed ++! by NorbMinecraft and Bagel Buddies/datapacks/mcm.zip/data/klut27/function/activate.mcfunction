execute unless score $selectedMap CmdData matches 20 run return 0
execute unless score $gamestate CmdData matches 0..1 run return 0
kill @e[tag=MapEntity]
tag @a remove Klut27Participant
function klut27:fire/reset
function klut27:restore_blocks
gamerule doFireTick false
tellraw @a {"translate":"klut27.ready","fallback":"KLUT-27 ready","color":"aqua"}
scoreboard players set @a klut_air 0
function klut27:npc_reset
function klut27:residents/reset
function bbe_arena:klut27/spawns
