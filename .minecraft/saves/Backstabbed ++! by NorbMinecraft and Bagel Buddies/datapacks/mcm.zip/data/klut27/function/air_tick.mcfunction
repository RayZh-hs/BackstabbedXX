execute unless score $selectedMap CmdData matches 20 run return 0
execute unless score $gamestate CmdData matches 1 run return 0
execute if score $graceperiod CmdData matches 1.. run scoreboard players set @a klut_air 0
execute if score $graceperiod CmdData matches 1.. run return 0
execute unless score $pickedroles CmdData matches 1 run return 0
scoreboard players set @a[tag=!queued] klut_air 0
scoreboard players set @a[tag=spectating] klut_air 0
scoreboard players set @a[gamemode=spectator] klut_air 0
scoreboard players set @a[scores={dead=1..}] klut_air 0
execute as @a[tag=queued,tag=!spectating,gamemode=!spectator] at @s unless score @s dead matches 1.. unless predicate klut27:airless run scoreboard players set @s klut_air 0
execute as @a[tag=queued,tag=!spectating,gamemode=!spectator] at @s unless score @s dead matches 1.. if predicate klut27:airless run scoreboard players add @s klut_air 1
execute as @a[tag=queued,tag=!spectating,gamemode=!spectator] if score @s klut_air matches 40 run tellraw @s {"text":"警告：舱室缺氧！请在8秒内离开，否则将窒息死亡。","color":"red"}
execute as @a[tag=queued,tag=!spectating,gamemode=!spectator] at @s if score @s klut_air matches 200.. run function klut27:suffocate
