execute unless block 36872 26 36882 minecraft:cherry_wood run return run function klut27:fire/skip
scoreboard players set @s kf_age -1
execute store result score $tile kf run gamerule doTileDrops
execute store result score $entity kf run gamerule doEntityDrops
execute store result score $mob kf run gamerule doMobLoot
gamerule doTileDrops false
gamerule doEntityDrops false
gamerule doMobLoot false
setblock 36872 26 36882 air
scoreboard players set @e[tag=Klut27Fire294] kf_age -1
execute if score $tile kf matches 1 run gamerule doTileDrops true
execute if score $entity kf matches 1 run gamerule doEntityDrops true
execute if score $mob kf matches 1 run gamerule doMobLoot true
execute if block 36872 26 36881 minecraft:stripped_oak_wood run scoreboard players set @e[tag=Klut27Fire293,scores={kf_age=0}] kf_age 1
execute if block 36872 27 36882 minecraft:cherry_planks run scoreboard players set @e[tag=Klut27Fire304,scores={kf_age=0}] kf_age 1
