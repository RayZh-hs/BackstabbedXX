execute unless block 36870 23 36881 minecraft:cherry_wood run return run function klut27:fire/skip
scoreboard players set @s kf_age -1
execute store result score $tile kf run gamerule doTileDrops
execute store result score $entity kf run gamerule doEntityDrops
execute store result score $mob kf run gamerule doMobLoot
gamerule doTileDrops false
gamerule doEntityDrops false
gamerule doMobLoot false
setblock 36870 23 36881 air
scoreboard players set @e[tag=Klut27Fire188] kf_age -1
execute if score $tile kf matches 1 run gamerule doTileDrops true
execute if score $entity kf matches 1 run gamerule doEntityDrops true
execute if score $mob kf matches 1 run gamerule doMobLoot true
execute if block 36870 22 36881 minecraft:cherry_wood run scoreboard players set @e[tag=Klut27Fire186,scores={kf_age=0}] kf_age 1
execute if block 36870 24 36881 minecraft:cherry_wood run scoreboard players set @e[tag=Klut27Fire190,scores={kf_age=0}] kf_age 1
