execute unless block 36874 21 36887 minecraft:birch_planks run return run function klut27:fire/skip
scoreboard players set @s kf_age -1
execute store result score $tile kf run gamerule doTileDrops
execute store result score $entity kf run gamerule doEntityDrops
execute store result score $mob kf run gamerule doMobLoot
gamerule doTileDrops false
gamerule doEntityDrops false
gamerule doMobLoot false
setblock 36874 21 36887 air
scoreboard players set @e[tag=Klut27Fire423] kf_age -1
execute if score $tile kf matches 1 run gamerule doTileDrops true
execute if score $entity kf matches 1 run gamerule doEntityDrops true
execute if score $mob kf matches 1 run gamerule doMobLoot true
execute if block 36874 20 36887 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire414,scores={kf_age=0}] kf_age 1
execute if block 36874 22 36887 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire426,scores={kf_age=0}] kf_age 1
execute if block 36875 21 36887 minecraft:birch_planks run scoreboard players set @e[tag=Klut27Fire478,scores={kf_age=0}] kf_age 1
