execute unless block 36871 27 36879 minecraft:stripped_birch_wood run return run function klut27:fire/skip
scoreboard players set @s kf_age -1
execute store result score $tile kf run gamerule doTileDrops
execute store result score $entity kf run gamerule doEntityDrops
execute store result score $mob kf run gamerule doMobLoot
gamerule doTileDrops false
gamerule doEntityDrops false
gamerule doMobLoot false
setblock 36871 27 36879 air
scoreboard players set @e[tag=Klut27Fire262] kf_age -1
execute if score $tile kf matches 1 run gamerule doTileDrops true
execute if score $entity kf matches 1 run gamerule doEntityDrops true
execute if score $mob kf matches 1 run gamerule doMobLoot true
execute if block 36871 26 36879 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire250,scores={kf_age=0}] kf_age 1
execute if block 36871 27 36878 minecraft:stripped_birch_wood run scoreboard players set @e[tag=Klut27Fire261,scores={kf_age=0}] kf_age 1
execute if block 36871 27 36880 minecraft:stripped_oak_wood run scoreboard players set @e[tag=Klut27Fire263,scores={kf_age=0}] kf_age 1
