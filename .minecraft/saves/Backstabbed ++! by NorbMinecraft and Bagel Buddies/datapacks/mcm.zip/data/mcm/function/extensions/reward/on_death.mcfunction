execute store result score $victim_scrap temp run clear @s netherite_scrap 0
execute on attacker if entity @s[type=player,tag=murderer,tag=queued,tag=!spectating] run function mcm:extensions/reward/give
