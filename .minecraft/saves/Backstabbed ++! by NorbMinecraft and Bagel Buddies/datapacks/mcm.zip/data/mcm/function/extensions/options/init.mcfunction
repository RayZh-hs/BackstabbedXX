execute unless data storage mcm:options options.ext.shield run data modify storage mcm:options options.ext.shield set value 0
execute unless data storage mcm:options options.ext.gunner_scrap run data modify storage mcm:options options.ext.gunner_scrap set value 0
execute unless data storage mcm:options options.ext.craft_keep run data modify storage mcm:options options.ext.craft_keep set value 0
execute unless data storage mcm:options options.ext.ammo run data modify storage mcm:options options.ext.ammo set value 0
execute unless data storage mcm:options options.ext.knife_timeout run data modify storage mcm:options options.ext.knife_timeout set value 0
execute unless data storage mcm:options options.ext.knife_seconds run data modify storage mcm:options options.ext.knife_seconds set value 15
execute unless data storage mcm:options options.ext.kill_reward run data modify storage mcm:options options.ext.kill_reward set value 0
execute unless data storage mcm:options options.ext.global_glow run data modify storage mcm:options options.ext.global_glow set value 0
execute unless data storage mcm:options options.ext.team_sight run data modify storage mcm:options options.ext.team_sight set value 0
execute unless data storage mcm:options options.ext.gun_glow run data modify storage mcm:options options.ext.gun_glow set value 0
function mcm:extensions/options/sync
