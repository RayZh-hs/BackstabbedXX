execute if score @s mcm_options matches 1 run return run function mcm:extensions/options/menu
execute if score $gamestate CmdData matches 1.. run return run tellraw @s {"text":"对局中不能更改设置。","color":"red"}
execute if data storage mcm:options options{locked:1} run return run tellraw @s {"text":"大厅设置已锁定。","color":"red"}
execute if score @s mcm_options matches 2 run function mcm:extensions/options/toggle {option:"shield"}
execute if score @s mcm_options matches 3 run function mcm:extensions/options/toggle {option:"gunner_scrap"}
execute if score @s mcm_options matches 4..5 unless score $gunner_scrap GameRules matches 1 run return run tellraw @s {"text":"请先开启「持枪玩家保留废料」。","color":"red"}
execute if score @s mcm_options matches 4 run function mcm:extensions/options/toggle {option:"craft_keep"}
execute if score @s mcm_options matches 5 run function mcm:extensions/options/toggle {option:"ammo"}
execute if score @s mcm_options matches 6 run function mcm:extensions/options/toggle {option:"knife_timeout"}
execute if score @s mcm_options matches 7 run scoreboard players remove $knife_seconds GameRules 1
execute if score @s mcm_options matches 8 run scoreboard players add $knife_seconds GameRules 1
execute if score @s mcm_options matches 7..8 store result storage mcm:options options.ext.knife_seconds int 1 run scoreboard players get $knife_seconds GameRules
execute if score @s mcm_options matches 9 run function mcm:extensions/options/reward_cycle
execute if score @s mcm_options matches 10 run function mcm:extensions/options/toggle {option:"global_glow"}
execute if score @s mcm_options matches 11 run function mcm:extensions/options/toggle {option:"team_sight"}
execute if score @s mcm_options matches 12 run function mcm:extensions/options/toggle {option:"gun_glow"}
function mcm:extensions/options/sync
function mcm:extensions/options/menu
