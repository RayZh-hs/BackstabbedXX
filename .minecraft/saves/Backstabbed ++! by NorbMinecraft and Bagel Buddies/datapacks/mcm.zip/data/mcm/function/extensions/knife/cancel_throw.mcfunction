# Restore the selected knife variant when a throw was cancelled by cooldown.
function mcm:items/give_item_cleanup
execute store result storage mcm:args id int 1 run scoreboard players get @s loadout_knife
function mcm:items/id with storage mcm:args
function mcm:items/give_mainhand with storage mcm:args
scoreboard players reset @s droppedKnife
scoreboard players reset @s throwKnife
