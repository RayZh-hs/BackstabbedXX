execute if score $gamestate CmdData matches 1 unless entity @s[tag=queued,tag=!spectating] run return 0
execute store result score $ammo_count temp run clear @s netherite_scrap 0
execute if score $ammo GameRules matches 1 unless score $ammo_count temp matches 1.. run return run tellraw @s {"text":"没有废料，无法开枪。","color":"red"}
execute if score $ammo GameRules matches 1 run clear @s netherite_scrap 1
data modify storage mcm:shot owner set from entity @s UUID
data modify storage mcm:shot rotation set from entity @s Rotation
execute facing ^ ^ ^14 positioned 0.0 0 0.0 run summon arrow ^ ^ ^7 {NoGravity:1b,Tags:["GunShot","NewGunShot"],Passengers:[{id:"minecraft:item_display",Tags:["BulletDeco","NewBullet"],item:{id:"minecraft:diamond_hoe",count:1,components:{"minecraft:item_model":"minecraft:misc/bullet"}},transformation:[1.6,0.0,0.0,0.0,0.0,0.0,1.6,0.0,0.0,1.6,0.0,0.0,0.0,0.0,0.0,1.0],interpolation_duration:8}]}
data modify entity @e[type=arrow,tag=NewGunShot,limit=1] Owner set from storage mcm:shot owner
execute positioned ~ ~1.5 ~ as @e[type=arrow,tag=NewGunShot,limit=1] run function mcm:extensions/gun/setspeed
playsound gun_shoot master @a ~ ~ ~ 2 1
execute on vehicle on passengers run tag @s add no_recoil
execute unless entity @s[tag=no_recoil] run tp @s ~ ~ ~ ~ ~-3
tag @s remove no_recoil
tag @s add shotGun
