function mcm:extensions/knife/stamp_dropped with storage mcm:knife_throw
function mcm:items/retrieve/knife_use
scoreboard players set @s retrieval_delay 5
tag @s remove has_knife
scoreboard players reset @s droppedKnife
