$data modify storage mcm:knife_restore id set from storage mcm:items $(item).id
$data modify storage mcm:knife_restore components set from storage mcm:items $(item).components
