# Position, world velocity, owner and display orientation are initialized by the mod.
tag @s remove NewGunShot
tag @s add Fired
execute on passengers run tag @s remove NewBullet
