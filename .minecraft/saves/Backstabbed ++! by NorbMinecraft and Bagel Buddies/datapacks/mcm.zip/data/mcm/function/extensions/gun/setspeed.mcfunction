tag @s remove NewGunShot
data modify storage mcm:shot motion set from entity @s Pos
tp ^ ^ ^
data modify entity @s Motion set from storage mcm:shot motion
tag @s add Fired
execute on passengers run data modify entity @s Rotation set from storage mcm:shot rotation
execute on passengers run tag @s remove NewBullet
