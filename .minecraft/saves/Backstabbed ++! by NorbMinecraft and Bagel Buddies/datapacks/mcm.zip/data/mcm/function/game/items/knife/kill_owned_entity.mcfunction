# Only the recalling player's complete UUID may match. Unowned entities are left alone.
$execute if data entity @s {Owner:$(owner)} run return run kill @s
# A manually dropped knife may not have received Owner from the game loop yet.
$execute if data entity @s {Thrower:$(owner)} run kill @s
