execute unless data entity @s Owner run return 0
data modify storage mcm:knife_entity owner set from entity @s Owner
function mcm:extensions/knife/check_owner with storage mcm:knife_entity
