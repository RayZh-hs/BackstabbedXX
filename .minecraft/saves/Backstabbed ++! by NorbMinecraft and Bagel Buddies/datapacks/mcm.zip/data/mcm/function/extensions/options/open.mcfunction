execute as @a[distance=..8] run function mcm:extensions/options/menu
