$execute as @e[type=item,nbt={Thrower:$(owner)}] if items entity @s contents snowball[custom_data~{knife:1b}] run data modify entity @s Owner set from entity @s Thrower
$execute as @e[type=item,nbt={Thrower:$(owner)}] if items entity @s contents snowball[custom_data~{knife:1b}] run function mcm:extensions/knife/track_entity
