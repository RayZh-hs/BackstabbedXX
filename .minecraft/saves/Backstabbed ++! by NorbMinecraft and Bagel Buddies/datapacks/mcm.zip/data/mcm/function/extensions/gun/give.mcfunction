# Preserve the granted gun if every inventory slot is occupied: /give drops overflow.
data modify storage mcm:gun_grant id set from storage mcm:items gun.id
data modify storage mcm:gun_grant components set from storage mcm:items gun.components
function mcm:extensions/gun/deliver with storage mcm:gun_grant
