scoreboard objectives add mcm_options trigger
scoreboard objectives add mcm_missing dummy
scoreboard objectives add mcm_epoch dummy
scoreboard objectives add mcm_elapsed dummy
function mcm:extensions/options/init
