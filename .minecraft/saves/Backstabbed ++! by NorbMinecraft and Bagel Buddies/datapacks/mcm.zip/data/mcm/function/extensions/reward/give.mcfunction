execute if score @s dead matches 1.. run return 0
scoreboard players operation $reward temp = $kill_reward GameRules
execute if score $kill_reward GameRules matches -1 run scoreboard players operation $reward temp = $victim_scrap temp
execute unless score $reward temp matches 1.. run return 0
execute store result storage mcm:reward count int 1 run scoreboard players get $reward temp
function mcm:extensions/reward/give_scrap with storage mcm:reward
function mcm:extensions/shield/check
function mcm:items/retrieve/all_loadout_retrieves
