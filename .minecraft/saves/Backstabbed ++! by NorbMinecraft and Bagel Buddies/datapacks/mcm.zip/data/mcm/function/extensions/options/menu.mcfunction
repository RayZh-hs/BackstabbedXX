tellraw @s {"text": "━━ 新机制设置（点击切换；0=关闭，1=开启）━━", "color": "gold"}
tellraw @s [{"text": "杀手首次持有10废料获一次性盾牌：", "color": "aqua", "clickEvent": {"action": "run_command", "value": "/trigger mcm_options set 2"}}, {"score": {"name": "$shield", "objective": "GameRules"}, "color": "yellow"}]
tellraw @s [{"text": "持枪玩家保留/拾取废料：", "color": "aqua", "clickEvent": {"action": "run_command", "value": "/trigger mcm_options set 3"}}, {"score": {"name": "$gunner_scrap", "objective": "GameRules"}, "color": "yellow"}]
tellraw @s [{"text": "达到10废料获枪时只扣8：", "color": "aqua", "clickEvent": {"action": "run_command", "value": "/trigger mcm_options set 4"}}, {"score": {"name": "$craft_keep", "objective": "GameRules"}, "color": "yellow"}]
tellraw @s [{"text": "开枪消耗1废料：", "color": "aqua", "clickEvent": {"action": "run_command", "value": "/trigger mcm_options set 5"}}, {"score": {"name": "$ammo", "objective": "GameRules"}, "color": "yellow"}]
tellraw @s [{"text": "丢刀超时保底：", "color": "aqua", "clickEvent": {"action": "run_command", "value": "/trigger mcm_options set 6"}}, {"score": {"name": "$knife_timeout", "objective": "GameRules"}, "color": "yellow"}]
tellraw @s [{"text": "每2分钟高亮5秒／最后20秒高亮：", "color": "aqua", "clickEvent": {"action": "run_command", "value": "/trigger mcm_options set 10"}}, {"score": {"name": "$global_glow", "objective": "GameRules"}, "color": "yellow"}]
tellraw @s [{"text": "杀手32格内互相透视：", "color": "aqua", "clickEvent": {"action": "run_command", "value": "/trigger mcm_options set 11"}}, {"score": {"name": "$team_sight", "objective": "GameRules"}, "color": "yellow"}]
tellraw @s [{"text": "超时：", "color": "aqua"}, {"score": {"name": "$knife_seconds", "objective": "GameRules"}}, {"text": "秒  [−1]", "color": "green", "clickEvent": {"action": "run_command", "value": "/trigger mcm_options set 7"}}, {"text": "  [+1]", "color": "green", "clickEvent": {"action": "run_command", "value": "/trigger mcm_options set 8"}}]
tellraw @s [{"text": "击杀废料奖励（点击循环，−1=获得受害者全部废料）：", "color": "aqua", "clickEvent": {"action": "run_command", "value": "/trigger mcm_options set 9"}}, {"score": {"name": "$kill_reward", "objective": "GameRules"}, "color": "yellow"}]
tellraw @s {"text": "保留余料、弹药需要先开启持枪存废料；高亮需要主机和全体客户端安装新版模组。", "color": "gray"}

tellraw @s [{"text": "掉落真枪全图透视：", "color": "aqua", "clickEvent": {"action": "run_command", "value": "/trigger mcm_options set 12"}}, {"score": {"name": "$gun_glow", "objective": "GameRules"}, "color": "yellow"}]

execute if score $scrap_rate GameRules matches 50 run tellraw @s {"text": "碎片刷新倍率：0.5×（点击切换，仅开局前可改）", "color": "aqua", "clickEvent": {"action": "run_command", "value": "/trigger mcm_options set 13"}}

execute if score $scrap_rate GameRules matches 80 run tellraw @s {"text": "碎片刷新倍率：0.8×（点击切换，仅开局前可改）", "color": "aqua", "clickEvent": {"action": "run_command", "value": "/trigger mcm_options set 13"}}

execute if score $scrap_rate GameRules matches 100 run tellraw @s {"text": "碎片刷新倍率：1×（点击切换，仅开局前可改）", "color": "aqua", "clickEvent": {"action": "run_command", "value": "/trigger mcm_options set 13"}}

execute if score $scrap_rate GameRules matches 150 run tellraw @s {"text": "碎片刷新倍率：1.5×（点击切换，仅开局前可改）", "color": "aqua", "clickEvent": {"action": "run_command", "value": "/trigger mcm_options set 13"}}

execute if score $scrap_rate GameRules matches 200 run tellraw @s {"text": "碎片刷新倍率：2×（点击切换，仅开局前可改）", "color": "aqua", "clickEvent": {"action": "run_command", "value": "/trigger mcm_options set 13"}}

tellraw @s {"text": "开启加速时，正式开局后的前30秒碎片刷新额外翻倍，与所选倍率相乘；准备期不计入。", "color": "gray"}

tellraw @s {"text": "开局30秒碎片刷新额外翻倍：", "color": "aqua", "clickEvent": {"action": "run_command", "value": "/trigger mcm_options set 14"}, "extra": [{"score": {"name": "$scrap_boost", "objective": "GameRules"}, "color": "yellow"}]}
