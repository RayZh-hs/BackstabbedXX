$execute if score @s throw_delay matches 1.. as @e[type=snowball,nbt={Owner:$(owner)}] run kill @s
$execute unless entity @e[type=snowball,nbt={Owner:$(owner)}] run function mcm:extensions/knife/cancel_throw
$execute unless entity @e[type=snowball,nbt={Owner:$(owner)}] run return 0
execute store result storage mcm:args id int 1 run scoreboard players get @s loadout_knife
function mcm:items/id with storage mcm:args
function mcm:items/mc_id with storage mcm:args
function mcm:items/get_item_nbt with storage mcm:args
scoreboard players add @s mcm_epoch 1
$gravity bridge inherit @s @e[type=snowball,nbt={Owner:$(owner)},sort=nearest,limit=1]
$execute as @e[type=snowball,nbt={Owner:$(owner)},sort=nearest,limit=1] at @s run function mcm:game/items/knife/throw_inner with storage mcm:args
scoreboard players reset @s throwKnife
function mcm:items/give_item_cleanup
function mcm:items/retrieve/knife_use
scoreboard players set @s retrieval_delay 5
scoreboard players reset @s droppedKnife
tag @s remove has_knife
