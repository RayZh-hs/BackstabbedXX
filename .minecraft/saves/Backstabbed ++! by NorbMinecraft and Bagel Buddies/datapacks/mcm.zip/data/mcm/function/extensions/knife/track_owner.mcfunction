$execute unless entity @a[nbt={UUID:$(owner)}] run return 0
$scoreboard players operation @s mcm_epoch = @a[nbt={UUID:$(owner)},limit=1] mcm_epoch
tag @s add mcm_knife_tracked
