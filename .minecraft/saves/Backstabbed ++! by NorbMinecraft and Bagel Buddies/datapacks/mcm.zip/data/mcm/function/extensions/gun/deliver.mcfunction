$give @s $(id)$(components)
