execute as @a[scores={mcm_options=1..}] run function mcm:extensions/options/change
scoreboard players set @a[scores={mcm_options=1..}] mcm_options 0
scoreboard players enable @a mcm_options
execute if score $gamestate CmdData matches 1 if score $graceperiod CmdData matches ..0 run scoreboard players add $round mcm_elapsed 1
execute unless score $gamestate CmdData matches 1 run scoreboard players set $round mcm_elapsed 0
execute if score $gamestate CmdData matches 1 if score $graceperiod CmdData matches ..0 run function mcm:extensions/knife/tick
