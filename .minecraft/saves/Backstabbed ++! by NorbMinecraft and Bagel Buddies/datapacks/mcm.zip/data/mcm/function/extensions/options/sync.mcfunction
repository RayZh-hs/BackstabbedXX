execute store result score $shield GameRules run data get storage mcm:options options.ext.shield
execute store result score $gunner_scrap GameRules run data get storage mcm:options options.ext.gunner_scrap
execute store result score $craft_keep GameRules run data get storage mcm:options options.ext.craft_keep
execute store result score $ammo GameRules run data get storage mcm:options options.ext.ammo
execute store result score $knife_timeout GameRules run data get storage mcm:options options.ext.knife_timeout
execute store result score $knife_seconds GameRules run data get storage mcm:options options.ext.knife_seconds
execute store result score $kill_reward GameRules run data get storage mcm:options options.ext.kill_reward
execute store result score $global_glow GameRules run data get storage mcm:options options.ext.global_glow
execute store result score $team_sight GameRules run data get storage mcm:options options.ext.team_sight
# Persist dependency normalization, so UI and execution show the same state.
execute unless score $gunner_scrap GameRules matches 1 run scoreboard players set $craft_keep GameRules 0
execute unless score $gunner_scrap GameRules matches 1 run scoreboard players set $ammo GameRules 0
execute unless score $gunner_scrap GameRules matches 1 run data modify storage mcm:options options.ext.craft_keep set value 0
execute unless score $gunner_scrap GameRules matches 1 run data modify storage mcm:options options.ext.ammo set value 0
execute if score $knife_seconds GameRules matches ..4 run scoreboard players set $knife_seconds GameRules 5
execute if score $knife_seconds GameRules matches 31.. run scoreboard players set $knife_seconds GameRules 30
execute store result storage mcm:options options.ext.knife_seconds int 1 run scoreboard players get $knife_seconds GameRules
scoreboard players operation $knife_ticks GameRules = $knife_seconds GameRules
scoreboard players operation $knife_ticks GameRules *= $twenty math

execute store result score $gun_glow GameRules run data get storage mcm:options options.ext.gun_glow
