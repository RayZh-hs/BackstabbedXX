tag @a remove mcm_shield_received
scoreboard players set @a mcm_missing 0
scoreboard players add @a mcm_epoch 1
scoreboard players set $round mcm_elapsed 0
