# Offline owners are not silently reassigned to another murderer.
$execute unless entity @a[nbt={UUID:$(owner)}] run return 0
$execute unless score @s mcm_epoch = @a[nbt={UUID:$(owner)},limit=1] mcm_epoch run kill @s
