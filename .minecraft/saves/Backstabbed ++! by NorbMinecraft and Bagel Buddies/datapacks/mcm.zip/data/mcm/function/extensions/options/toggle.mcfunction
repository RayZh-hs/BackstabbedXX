$execute store result score $ext_toggle temp run data get storage mcm:options options.ext.$(option)
execute store success score $ext_toggle temp unless score $ext_toggle temp matches 1
$execute store result storage mcm:options options.ext.$(option) int 1 run scoreboard players get $ext_toggle temp
