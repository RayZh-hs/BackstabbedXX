# /give preserves an overflow item instead of deleting it if the inventory is full.
$give @s $(id)$(components)
