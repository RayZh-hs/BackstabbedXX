scoreboard players operation $next_reward temp = $kill_reward GameRules
execute if score $kill_reward GameRules matches -1 run scoreboard players set $next_reward temp 0
execute if score $kill_reward GameRules matches 0 run scoreboard players set $next_reward temp 2
execute if score $kill_reward GameRules matches 2 run scoreboard players set $next_reward temp 3
execute if score $kill_reward GameRules matches 3 run scoreboard players set $next_reward temp 5
execute if score $kill_reward GameRules matches 5 run scoreboard players set $next_reward temp -1
execute store result storage mcm:options options.ext.kill_reward int 1 run scoreboard players get $next_reward temp
