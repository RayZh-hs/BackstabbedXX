# Only a directly lethal weapon hit earns scrap; hazards do not reuse an old attacker.
execute if score @s dead matches 1.. run return 0
execute unless entity @s[tag=queued,tag=!spectating] run return 0
function mcm:extensions/reward/on_death
function mcm:game/playerdeath
