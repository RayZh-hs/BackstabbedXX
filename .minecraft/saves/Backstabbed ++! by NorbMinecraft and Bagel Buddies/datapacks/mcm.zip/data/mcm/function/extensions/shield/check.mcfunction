execute unless score $shield GameRules matches 1 run return 0
execute unless entity @s[tag=queued,tag=murderer,tag=!spectating,tag=!mcm_shield_received] run return 0
execute store result score $shield_scrap temp run clear @s netherite_scrap 0
execute unless score $shield_scrap temp matches 10.. run return 0
tag @s add mcm_shield_received
give @s shield[max_damage=1,damage=0,custom_data={mcm_shield:1b,NoDrop:1b,no_drop_on_death:1b},custom_name='{"text":"一次性盾牌","italic":false,"color":"aqua"}',lore=['{"text":"按原版规则格挡；剩余耐久1。","italic":false}']]
