execute if entity @s[advancements={mcm:secrets/library/library=true}] unless items entity @s armor.head diamond_hoe[item_model="minecraft:hats/dark3dglasses"] at @s run playsound minecraft:item.armor.equip_leather block @s ~ ~ ~ 3 0
execute if entity @s[advancements={mcm:secrets/library/library=true}] unless items entity @s armor.head diamond_hoe[item_model="minecraft:hats/dark3dglasses"] run item replace entity @s armor.head with diamond_hoe[custom_data={no_drop_on_death:1b},item_model="minecraft:hats/dark3dglasses",enchantments={levels:{binding_curse:1},show_in_tooltip:false},unbreakable={show_in_tooltip:false},custom_name='{"translate":"mcm.item.dark3dglasses","color":"gray","italic":false}']

execute if entity @s[advancements={mcm:secrets/library/library=false}] run tellraw @s {"translate":"mcm.cosmetic.cannot.equip","color":"red"}
execute if entity @s[advancements={mcm:secrets/library/library=false}] at @s run playsound minecraft:entity.villager.no neutral @s ~ ~ ~ 1 1 0

execute if entity @s[advancements={mcm:secrets/library/library=true}] run scoreboard players set @s selected_hat 4
execute unless entity @s[advancements={mcm:secrets/library/library=true}] run scoreboard players set @s selected_hat 0