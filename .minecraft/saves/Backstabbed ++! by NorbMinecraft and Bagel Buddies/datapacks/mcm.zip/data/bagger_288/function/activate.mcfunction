execute unless score $selectedMap CmdData matches 18 run return 0
execute unless score $gamestate CmdData matches 0..1 run return 0
kill @e[tag=MapEntity]
tag @a remove Bagger288Participant
function bagger_288:restore_blocks
tellraw @a {"translate":"bagger_288.ready","fallback":"Bagger 288 ready","color":"aqua"}
function bbe_arena:bagger_288/spawns
