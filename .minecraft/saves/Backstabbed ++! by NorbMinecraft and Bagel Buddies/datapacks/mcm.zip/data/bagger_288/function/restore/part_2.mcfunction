data merge block 28679 -42 28739 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28672 -50 28738 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28673 -50 28738 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28679 -42 28740 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28675 -50 28736 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28679 -42 28741 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28674 -50 28738 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28675 -50 28738 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
