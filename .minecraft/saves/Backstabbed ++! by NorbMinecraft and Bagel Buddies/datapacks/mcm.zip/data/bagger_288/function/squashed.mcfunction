execute unless score $selectedMap CmdData matches 18 run return 0
execute unless score $gamestate CmdData matches 0..1 run return 0
execute unless entity @s[tag=queued,tag=!spectating,gamemode=!spectator] run return 0
execute if score @s dead matches 1.. run return 0
tellraw @a {"translate":"bagger_288.death.squashed","fallback":"\"%s\" got squashed by giant wheels","color":"gold","with":[{"selector":"@s"}]}
function mcm:game/playerdeath
