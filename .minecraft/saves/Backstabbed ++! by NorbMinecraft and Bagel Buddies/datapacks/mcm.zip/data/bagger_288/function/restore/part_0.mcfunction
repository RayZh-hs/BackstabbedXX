# Original imported interactive states and inventories; architecture is unchanged.
setblock 28655 -50 28689 minecraft:iron_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28655 -50 28696 minecraft:iron_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28655 -50 28702 minecraft:iron_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28655 -50 28693 minecraft:iron_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28655 -50 28700 minecraft:iron_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
data merge block 28655 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28655 -50 28690 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28655 -50 28692 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28655 -50 28697 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28655 -50 28699 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
setblock 28656 -49 28688 minecraft:lever[face=wall,facing=north,powered=true]
setblock 28658 -49 28688 minecraft:lever[face=wall,facing=north,powered=true]
setblock 28656 -49 28695 minecraft:lever[face=wall,facing=north,powered=true]
setblock 28658 -49 28695 minecraft:lever[face=wall,facing=north,powered=true]
setblock 28656 -49 28701 minecraft:lever[face=wall,facing=north,powered=true]
setblock 28658 -49 28701 minecraft:lever[face=wall,facing=north,powered=true]
setblock 28656 -49 28694 minecraft:lever[face=wall,facing=south,powered=true]
setblock 28658 -49 28694 minecraft:lever[face=wall,facing=south,powered=true]
setblock 28661 -48 28689 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28662 -48 28689 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28663 -48 28689 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28665 -48 28689 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28667 -48 28689 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28661 -48 28696 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28662 -48 28696 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28663 -48 28696 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28665 -48 28696 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28667 -48 28696 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28661 -48 28702 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28662 -48 28702 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28663 -48 28702 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28665 -48 28702 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28667 -48 28702 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28661 -48 28693 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28662 -48 28693 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28663 -48 28693 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28665 -48 28693 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28667 -48 28693 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28661 -48 28700 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28662 -48 28700 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28663 -48 28700 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28665 -48 28700 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28667 -48 28700 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28670 -35 28698 minecraft:warped_fence_gate[facing=north,in_wall=false,open=true,powered=false]
setblock 28670 -34 28699 minecraft:warped_fence_gate[facing=north,in_wall=false,open=true,powered=false]
setblock 28670 -33 28700 minecraft:warped_fence_gate[facing=north,in_wall=false,open=true,powered=false]
setblock 28666 -34 28698 minecraft:warped_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28667 -34 28698 minecraft:warped_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28668 -34 28698 minecraft:warped_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28666 -34 28699 minecraft:warped_trapdoor[facing=west,half=top,open=false,powered=false,waterlogged=false]
setblock 28668 -34 28699 minecraft:warped_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28668 -34 28700 minecraft:warped_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28666 -34 28700 minecraft:warped_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28667 -34 28700 minecraft:warped_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
data merge block 28659 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28667 -50 28692 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28660 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28668 -50 28692 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28661 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28662 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28669 -50 28692 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28670 -50 28692 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28663 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28664 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28671 -50 28692 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28665 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28666 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28667 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28668 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28669 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28670 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28671 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28668 -27 28703 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:bricks", color: "orange"}, {pattern: "minecraft:bricks", color: "yellow"}]}
data merge block 28666 -33 28700 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28667 -31 28701 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:bricks", color: "orange"}]}
data merge block 28667 -33 28700 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28668 -33 28700 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28664 -35 28703 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:small_stripes", color: "green"}, {pattern: "minecraft:small_stripes", color: "lime"}]}
data merge block 28656 -48 28688 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28657 -48 28688 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28658 -48 28688 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28659 -48 28688 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28660 -48 28688 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28661 -48 28688 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28662 -48 28688 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28663 -48 28688 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28660 -40 28700 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28664 -48 28688 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28664 -34 28703 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:small_stripes", color: "green"}, {pattern: "minecraft:small_stripes", color: "lime"}]}
data merge block 28656 -50 28695 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28665 -48 28688 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28666 -48 28688 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28657 -50 28695 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28667 -48 28688 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28658 -50 28695 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28668 -48 28688 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28669 -48 28688 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28656 -50 28699 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28670 -48 28688 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28657 -50 28699 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28671 -48 28688 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28658 -50 28699 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28659 -50 28699 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28660 -50 28699 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28661 -50 28699 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28662 -50 28699 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28663 -50 28699 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28659 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28664 -50 28699 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28660 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28661 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28665 -50 28699 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28662 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28663 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28667 -50 28699 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28664 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28668 -50 28699 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28669 -50 28699 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28665 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28670 -50 28699 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28671 -50 28699 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28667 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28668 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28669 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28670 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28671 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28667 -27 28702 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:bricks", color: "orange"}, {pattern: "minecraft:bricks", color: "yellow"}]}
data merge block 28666 -33 28699 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28669 -27 28702 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:bricks", color: "orange"}, {pattern: "minecraft:bricks", color: "yellow"}]}
data merge block 28660 -39 28700 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28668 -31 28700 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:bricks", color: "orange"}]}
data merge block 28668 -33 28699 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28662 -45 28697 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28663 -45 28697 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28664 -45 28697 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28665 -45 28697 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28666 -45 28697 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28667 -45 28697 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28660 -38 28700 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28659 -50 28690 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28656 -48 28695 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28660 -50 28690 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28657 -48 28695 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28656 -50 28694 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28661 -50 28690 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28658 -48 28695 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28657 -50 28694 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28658 -50 28694 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28662 -50 28690 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28663 -50 28690 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28664 -50 28690 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28665 -50 28690 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28667 -50 28690 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28668 -50 28690 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28669 -50 28690 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28670 -50 28690 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28671 -50 28690 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28670 -48 28695 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28671 -48 28695 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28668 -27 28701 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:bricks", color: "orange"}, {pattern: "minecraft:bricks", color: "yellow"}]}
data merge block 28666 -33 28698 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28667 -33 28698 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28668 -33 28698 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28664 -35 28701 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:small_stripes", color: "green"}, {pattern: "minecraft:small_stripes", color: "lime"}]}
data merge block 28666 -35 28701 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:small_stripes", color: "green"}, {pattern: "minecraft:small_stripes", color: "lime"}]}
data merge block 28670 -39 28695 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:stripe_left", color: "light_gray"}]}
data merge block 28671 -39 28695 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:stripe_left", color: "light_gray"}, {pattern: "minecraft:stripe_right", color: "light_gray"}, {pattern: "minecraft:stripe_bottom", color: "light_gray"}]}
data merge block 28656 -48 28694 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28657 -48 28694 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28664 -34 28701 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:small_stripes", color: "green"}, {pattern: "minecraft:small_stripes", color: "lime"}]}
data merge block 28658 -48 28694 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28659 -48 28694 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28666 -34 28701 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:small_stripes", color: "green"}, {pattern: "minecraft:small_stripes", color: "lime"}]}
data merge block 28660 -48 28694 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28661 -48 28694 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28670 -38 28695 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:stripe_left", color: "light_gray"}, {pattern: "minecraft:diagonal_left", color: "gray"}, {pattern: "minecraft:stripe_downleft", color: "light_gray"}, {pattern: "minecraft:stripe_top", color: "light_gray"}]}
data merge block 28671 -38 28695 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:stripe_top", color: "light_gray"}, {pattern: "minecraft:stripe_right", color: "light_gray"}, {pattern: "minecraft:stripe_left", color: "light_gray"}, {pattern: "minecraft:stripe_bottom", color: "light_gray"}]}
data merge block 28662 -48 28694 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28663 -48 28694 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28659 -50 28697 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28664 -48 28694 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28656 -50 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28660 -50 28697 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28665 -48 28694 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28657 -50 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28666 -48 28694 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28661 -50 28697 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28667 -48 28694 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28662 -50 28697 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28658 -50 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28663 -50 28697 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28668 -48 28694 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28669 -48 28694 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28664 -50 28697 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28665 -50 28697 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28670 -48 28694 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28671 -48 28694 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28667 -50 28697 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28668 -50 28697 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28669 -50 28697 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28670 -50 28697 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28671 -50 28697 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28666 -31 28702 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:bricks", color: "orange"}]}
data merge block 28656 -50 28688 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28657 -50 28688 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28658 -50 28688 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28656 -50 28692 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28657 -50 28692 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28658 -50 28692 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28659 -50 28692 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28660 -50 28692 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28661 -50 28692 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28662 -50 28692 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28663 -50 28692 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28656 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28664 -50 28692 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28657 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28665 -50 28692 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28658 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
setblock 28589 -22 28715 minecraft:dark_oak_trapdoor[facing=north,half=top,open=true,powered=false,waterlogged=false]
setblock 28590 -22 28715 minecraft:dark_oak_trapdoor[facing=north,half=top,open=true,powered=false,waterlogged=false]
setblock 28591 -23 28718 minecraft:dark_oak_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28591 -22 28719 minecraft:dark_oak_trapdoor[facing=south,half=top,open=true,powered=false,waterlogged=false]
setblock 28591 -21 28718 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28597 -30 28715 minecraft:dark_oak_trapdoor[facing=north,half=top,open=true,powered=false,waterlogged=false]
setblock 28606 -23 28715 minecraft:dark_oak_trapdoor[facing=north,half=top,open=true,powered=false,waterlogged=false]
setblock 28598 -30 28719 minecraft:dark_oak_trapdoor[facing=south,half=top,open=true,powered=false,waterlogged=false]
setblock 28598 -27 28719 minecraft:dark_oak_trapdoor[facing=south,half=top,open=true,powered=false,waterlogged=false]
setblock 28593 -22 28719 minecraft:dark_oak_trapdoor[facing=south,half=top,open=true,powered=false,waterlogged=false]
setblock 28594 -27 28718 minecraft:lever[face=wall,facing=east,powered=false]
setblock 28602 -27 28718 minecraft:lever[face=wall,facing=west,powered=false]
setblock 28596 -25 28719 minecraft:lever[face=wall,facing=west,powered=false]
setblock 28595 -24 28719 minecraft:lever[face=wall,facing=west,powered=false]
setblock 28593 -18 28718 minecraft:lever[face=wall,facing=west,powered=false]
setblock 28598 -26 28708 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28602 -26 28708 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28598 -25 28708 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28601 -21 28708 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28593 -26 28718 minecraft:lever[face=floor,facing=west,powered=false]
setblock 28595 -20 28719 minecraft:lever[face=floor,facing=west,powered=false]
setblock 28596 -19 28719 minecraft:lever[face=floor,facing=west,powered=false]
setblock 28603 -26 28718 minecraft:lever[face=floor,facing=east,powered=false]
setblock 28594 -17 28718 minecraft:lever[face=floor,facing=east,powered=false]
setblock 28602 -25 28708 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28598 -24 28708 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28602 -24 28708 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28600 -25 28719 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28601 -24 28719 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28596 -18 28713 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28600 -18 28713 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28604 -18 28713 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28596 -16 28716 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28599 -15 28716 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28595 -13 28716 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28600 -13 28716 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28596 -12 28717 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28597 -15 28716 minecraft:dark_oak_trapdoor[facing=east,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28600 -16 28716 minecraft:dark_oak_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28597 -14 28716 minecraft:dark_oak_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28601 -14 28716 minecraft:dark_oak_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28605 -15 28717 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=true,powered=false,waterlogged=false]
data merge block 28601 -19 28714 {components: {}}
data merge block 28592 -11 28717 {components: {}}
setblock 28614 -24 28708 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28615 -22 28708 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28616 -20 28708 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28617 -18 28708 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28612 -21 28712 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28615 -21 28712 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28618 -21 28712 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28621 -21 28712 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28612 -21 28716 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28615 -21 28716 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28618 -21 28716 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28621 -21 28716 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28608 -18 28713 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28612 -18 28713 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28623 -22 28708 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28622 -21 28708 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28621 -20 28708 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28620 -19 28708 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28619 -18 28708 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28611 -18 28705 minecraft:lever[face=floor,facing=west,powered=false]
setblock 28615 -14 28709 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28615 -14 28719 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28616 -13 28709 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28616 -13 28719 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28617 -12 28709 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28617 -12 28719 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28618 -11 28709 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28618 -11 28719 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28619 -10 28709 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28619 -10 28719 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28620 -9 28709 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28620 -9 28719 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28621 -8 28708 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28622 -7 28708 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28623 -6 28708 minecraft:lever[face=ceiling,facing=east,powered=false]
data merge block 28613 -15 28718 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28614 -15 28718 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28615 -15 28719 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28611 -19 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28611 -19 28706 {components: {}}
data merge block 28613 -15 28708 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28614 -15 28708 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28613 -15 28710 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28615 -15 28709 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28614 -15 28710 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28610 -19 28714 {components: {}}
setblock 28624 -23 28708 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28639 -19 28708 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28638 -18 28708 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28637 -17 28708 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28630 -23 28708 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28631 -22 28708 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28632 -21 28708 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28633 -20 28708 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28634 -19 28708 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28635 -18 28708 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28624 -21 28712 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28627 -21 28712 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28630 -21 28712 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28633 -21 28712 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28636 -21 28712 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28639 -21 28712 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28624 -21 28716 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28627 -21 28716 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28630 -21 28716 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28633 -21 28716 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28636 -21 28716 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28639 -21 28716 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28624 -5 28708 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28625 -4 28708 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28626 -3 28708 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28627 -2 28708 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28628 -1 28708 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28629 0 28708 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28630 1 28707 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28631 2 28707 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28632 3 28707 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28633 4 28707 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28634 5 28707 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28635 6 28707 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28636 7 28707 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28637 8 28707 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28638 9 28707 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28639 10 28707 minecraft:lever[face=ceiling,facing=east,powered=false]
data merge block 28630 -19 28714 {components: {}}
data merge block 28631 -19 28714 {components: {}}
setblock 28655 -50 28706 minecraft:iron_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28655 -50 28713 minecraft:iron_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28655 -50 28719 minecraft:iron_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28655 -50 28709 minecraft:iron_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28655 -50 28715 minecraft:iron_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28649 -32 28711 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28649 -32 28712 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28649 -32 28713 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28649 -32 28714 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28649 -32 28715 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28649 -32 28716 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28649 -32 28717 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28643 -23 28708 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28642 -22 28708 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28641 -21 28708 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28640 -20 28708 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28647 -23 28708 minecraft:jungle_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28648 -22 28708 minecraft:jungle_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28649 -21 28708 minecraft:jungle_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28650 -20 28708 minecraft:jungle_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28642 -21 28712 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28645 -21 28712 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28648 -21 28712 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28651 -21 28712 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28654 -21 28712 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28642 -21 28716 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28645 -21 28716 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28648 -21 28716 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28651 -21 28716 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28654 -21 28716 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28651 -19 28708 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28652 -18 28708 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28653 -17 28708 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28654 -16 28708 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28655 4 28710 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28655 5 28709 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28654 6 28708 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28653 8 28712 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28653 9 28711 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28652 10 28710 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28652 11 28709 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28651 12 28708 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28640 11 28707 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28641 12 28706 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28642 13 28706 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28643 14 28706 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28644 15 28706 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28655 4 28718 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28655 5 28719 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28653 8 28716 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28653 9 28717 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28652 10 28718 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28652 11 28719 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28654 8 28708 minecraft:waxed_exposed_copper_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28654 8 28709 minecraft:waxed_exposed_copper_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28654 8 28710 minecraft:waxed_exposed_copper_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28654 8 28711 minecraft:waxed_exposed_copper_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28654 8 28712 minecraft:waxed_exposed_copper_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28654 8 28716 minecraft:waxed_exposed_copper_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28654 8 28717 minecraft:waxed_exposed_copper_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28654 8 28718 minecraft:waxed_exposed_copper_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28654 8 28719 minecraft:waxed_exposed_copper_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28645 16 28706 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28651 18 28707 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28651 18 28708 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28651 18 28709 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28651 18 28710 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28653 19 28707 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28654 19 28707 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28653 19 28708 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28654 19 28708 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28653 19 28709 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28654 19 28709 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28653 19 28710 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28654 19 28710 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28651 18 28718 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28651 18 28719 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28653 19 28718 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28654 19 28718 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28653 19 28719 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28654 19 28719 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28652 18 28707 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28652 18 28708 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28652 18 28709 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28652 18 28710 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28652 18 28718 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28652 18 28719 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28655 19 28707 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28655 19 28708 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28655 19 28709 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28655 19 28710 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28655 19 28718 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28655 19 28719 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28652 19 28707 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28652 19 28708 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28652 19 28709 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28652 19 28710 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28655 20 28707 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28655 20 28708 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28655 20 28709 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28655 20 28710 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28652 19 28718 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28652 19 28719 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28655 20 28718 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28655 20 28719 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
data merge block 28655 -39 28714 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:stripe_left", color: "light_gray"}, {pattern: "minecraft:stripe_right", color: "light_gray"}, {pattern: "minecraft:stripe_bottom", color: "light_gray"}]}
data merge block 28655 -38 28715 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:stripe_left", color: "light_gray"}, {pattern: "minecraft:diagonal_left", color: "gray"}, {pattern: "minecraft:stripe_downleft", color: "light_gray"}, {pattern: "minecraft:stripe_top", color: "light_gray"}]}
data merge block 28655 -39 28715 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:stripe_left", color: "light_gray"}]}
data merge block 28655 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28655 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28655 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28655 -19 28713 {components: {}}
data merge block 28654 -19 28715 {components: {}}
data merge block 28655 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28655 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28646 17 28705 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28646 17 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28655 -38 28713 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:stripe_right", color: "light_gray"}, {pattern: "minecraft:diagonal_right", color: "gray"}, {pattern: "minecraft:stripe_left", color: "light_gray"}, {pattern: "minecraft:stripe_downleft", color: "light_gray"}, {pattern: "minecraft:stripe_downright", color: "light_gray"}]}
data merge block 28655 -39 28713 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:stripe_right", color: "light_gray"}, {pattern: "minecraft:stripe_left", color: "light_gray"}]}
data merge block 28655 -38 28714 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:stripe_top", color: "light_gray"}, {pattern: "minecraft:stripe_right", color: "light_gray"}, {pattern: "minecraft:stripe_left", color: "light_gray"}, {pattern: "minecraft:stripe_bottom", color: "light_gray"}]}
setblock 28656 -49 28707 minecraft:lever[face=wall,facing=south,powered=true]
setblock 28658 -49 28707 minecraft:lever[face=wall,facing=south,powered=true]
setblock 28656 -49 28714 minecraft:lever[face=wall,facing=south,powered=true]
setblock 28658 -49 28714 minecraft:lever[face=wall,facing=south,powered=true]
setblock 28656 -49 28708 minecraft:lever[face=wall,facing=north,powered=true]
setblock 28661 -48 28706 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28662 -48 28706 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28663 -48 28706 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28665 -48 28706 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28667 -48 28706 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28661 -48 28713 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28662 -48 28713 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28663 -48 28713 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28665 -48 28713 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28667 -48 28713 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28661 -48 28719 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28662 -48 28719 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28663 -48 28719 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28665 -48 28719 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28667 -48 28719 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28661 -48 28709 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28662 -48 28709 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28663 -48 28709 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28665 -48 28709 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28667 -48 28709 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28661 -48 28715 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28662 -48 28715 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28663 -48 28715 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28665 -48 28715 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28667 -48 28715 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28666 -40 28710 minecraft:waxed_oxidized_copper_trapdoor[facing=north,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28666 -40 28714 minecraft:waxed_oxidized_copper_trapdoor[facing=north,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28666 -39 28710 minecraft:waxed_oxidized_copper_trapdoor[facing=north,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28666 -39 28714 minecraft:waxed_oxidized_copper_trapdoor[facing=north,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28666 -38 28710 minecraft:waxed_oxidized_copper_trapdoor[facing=north,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28666 -38 28714 minecraft:waxed_oxidized_copper_trapdoor[facing=north,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28667 -40 28711 minecraft:lever[face=wall,facing=east,powered=false]
setblock 28667 -40 28712 minecraft:lever[face=wall,facing=east,powered=false]
setblock 28667 -40 28715 minecraft:lever[face=wall,facing=east,powered=false]
setblock 28667 -40 28716 minecraft:lever[face=wall,facing=east,powered=false]
setblock 28666 -40 28713 minecraft:waxed_oxidized_copper_trapdoor[facing=south,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28666 -40 28717 minecraft:waxed_oxidized_copper_trapdoor[facing=south,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28666 -39 28713 minecraft:waxed_oxidized_copper_trapdoor[facing=south,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28666 -39 28717 minecraft:waxed_oxidized_copper_trapdoor[facing=south,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28666 -38 28713 minecraft:waxed_oxidized_copper_trapdoor[facing=south,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28666 -38 28717 minecraft:waxed_oxidized_copper_trapdoor[facing=south,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28665 -40 28718 minecraft:oak_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28668 -40 28718 minecraft:oak_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28669 -40 28718 minecraft:bamboo_trapdoor[facing=west,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28669 -39 28718 minecraft:bamboo_trapdoor[facing=west,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28669 -38 28718 minecraft:bamboo_trapdoor[facing=west,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28669 -37 28718 minecraft:bamboo_trapdoor[facing=west,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28670 -40 28718 minecraft:bamboo_trapdoor[facing=east,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28670 -39 28718 minecraft:bamboo_trapdoor[facing=east,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28670 -38 28718 minecraft:bamboo_trapdoor[facing=east,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28670 -37 28718 minecraft:bamboo_trapdoor[facing=east,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28664 -38 28709 minecraft:spruce_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28664 -38 28710 minecraft:spruce_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28667 -38 28711 minecraft:lever[face=wall,facing=east,powered=true]
setblock 28667 -38 28712 minecraft:lever[face=wall,facing=east,powered=true]
setblock 28667 -38 28715 minecraft:lever[face=wall,facing=east,powered=true]
setblock 28667 -38 28716 minecraft:lever[face=wall,facing=east,powered=true]
setblock 28665 -37 28709 minecraft:waxed_exposed_copper_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28664 -37 28711 minecraft:spruce_trapdoor[facing=south,half=top,open=true,powered=false,waterlogged=false]
setblock 28666 -37 28711 minecraft:waxed_oxidized_copper_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28666 -37 28712 minecraft:waxed_oxidized_copper_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28666 -37 28715 minecraft:waxed_oxidized_copper_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28666 -37 28716 minecraft:waxed_oxidized_copper_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28664 -37 28713 minecraft:weathered_copper_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28670 -35 28712 minecraft:spruce_trapdoor[facing=west,half=top,open=false,powered=false,waterlogged=false]
setblock 28669 -35 28713 minecraft:spruce_trapdoor[facing=west,half=top,open=false,powered=false,waterlogged=false]
setblock 28670 -35 28713 minecraft:spruce_trapdoor[facing=west,half=top,open=false,powered=false,waterlogged=false]
setblock 28671 -35 28713 minecraft:spruce_trapdoor[facing=west,half=top,open=false,powered=false,waterlogged=false]
setblock 28669 -35 28714 minecraft:spruce_trapdoor[facing=west,half=top,open=false,powered=false,waterlogged=false]
setblock 28670 -35 28714 minecraft:spruce_trapdoor[facing=west,half=top,open=false,powered=false,waterlogged=false]
setblock 28671 -35 28714 minecraft:spruce_trapdoor[facing=west,half=top,open=false,powered=false,waterlogged=false]
setblock 28670 -35 28715 minecraft:spruce_trapdoor[facing=west,half=top,open=false,powered=false,waterlogged=false]
setblock 28662 -35 28713 minecraft:exposed_copper_door[facing=west,half=lower,hinge=right,open=false,powered=false]
setblock 28662 -35 28714 minecraft:exposed_copper_door[facing=west,half=lower,hinge=left,open=false,powered=false]
setblock 28664 -35 28715 minecraft:weathered_copper_door[facing=north,half=lower,hinge=right,open=false,powered=false]
setblock 28664 -35 28716 minecraft:weathered_copper_door[facing=north,half=lower,hinge=right,open=false,powered=false]
setblock 28664 -35 28717 minecraft:weathered_copper_door[facing=north,half=lower,hinge=right,open=false,powered=false]
setblock 28667 -35 28719 minecraft:warped_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28668 -35 28719 minecraft:warped_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28669 -35 28719 minecraft:warped_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28662 -34 28713 minecraft:exposed_copper_door[facing=west,half=upper,hinge=right,open=false,powered=false]
setblock 28662 -34 28714 minecraft:exposed_copper_door[facing=west,half=upper,hinge=left,open=false,powered=false]
setblock 28669 -34 28714 minecraft:dark_oak_pressure_plate[powered=false]
setblock 28664 -34 28715 minecraft:weathered_copper_door[facing=north,half=upper,hinge=right,open=false,powered=false]
setblock 28664 -34 28716 minecraft:weathered_copper_door[facing=north,half=upper,hinge=right,open=false,powered=false]
setblock 28664 -34 28717 minecraft:weathered_copper_door[facing=north,half=upper,hinge=right,open=false,powered=false]
setblock 28671 -33 28704 minecraft:pale_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28664 -33 28711 minecraft:tripwire_hook[attached=false,facing=east,powered=false]
setblock 28664 -33 28712 minecraft:tripwire_hook[attached=false,facing=east,powered=false]
setblock 28668 -31 28706 minecraft:jungle_fence_gate[facing=west,in_wall=true,open=false,powered=false]
setblock 28667 -31 28707 minecraft:jungle_fence_gate[facing=west,in_wall=true,open=false,powered=false]
setblock 28664 -31 28714 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=true,powered=false]
setblock 28665 -29 28712 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28666 -29 28712 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28667 -29 28712 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28668 -29 28712 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28665 -29 28713 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28666 -29 28713 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28667 -29 28713 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28665 -29 28714 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28666 -29 28714 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28669 -29 28713 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28668 -29 28714 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28669 -29 28714 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28667 -29 28715 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28668 -29 28715 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28669 -29 28715 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28667 -29 28716 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28668 -29 28716 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28669 -29 28716 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28667 -29 28717 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28668 -29 28717 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28669 -29 28717 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28667 -29 28718 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28668 -29 28718 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28669 -29 28718 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28667 -29 28719 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28668 -29 28719 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28669 -29 28719 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28662 -22 28708 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28661 -21 28708 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28660 -20 28708 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28659 -19 28708 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28658 -18 28708 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28657 -17 28708 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28657 -21 28712 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28660 -21 28712 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28663 -21 28712 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28666 -21 28712 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28669 -21 28712 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28657 -21 28716 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28660 -21 28716 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28663 -21 28716 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28666 -21 28716 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28669 -21 28716 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28656 -16 28708 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28666 -12 28708 minecraft:waxed_exposed_copper_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28667 -12 28708 minecraft:waxed_exposed_copper_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28667 -12 28709 minecraft:waxed_exposed_copper_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28667 -12 28710 minecraft:waxed_exposed_copper_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28665 -12 28709 minecraft:waxed_exposed_copper_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28665 -12 28710 minecraft:waxed_exposed_copper_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28666 -12 28710 minecraft:waxed_exposed_copper_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28663 -11 28708 minecraft:waxed_exposed_copper_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28663 -11 28709 minecraft:waxed_exposed_copper_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28663 -11 28710 minecraft:waxed_exposed_copper_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28663 -11 28711 minecraft:waxed_exposed_copper_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28663 -11 28712 minecraft:waxed_exposed_copper_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28660 -4 28708 minecraft:waxed_exposed_copper_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28660 -4 28709 minecraft:waxed_exposed_copper_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28660 -4 28710 minecraft:waxed_exposed_copper_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28660 -4 28711 minecraft:waxed_exposed_copper_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28660 -4 28712 minecraft:waxed_exposed_copper_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28662 -11 28712 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28662 -10 28711 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28661 -9 28710 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28661 -8 28709 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28660 -7 28708 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28659 -4 28712 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28659 -3 28711 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28658 -2 28710 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28658 -1 28709 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28662 -11 28716 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28662 -10 28717 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28661 -9 28718 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28661 -8 28719 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28659 -4 28716 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28659 -3 28717 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28658 -2 28718 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28658 -1 28719 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28663 -11 28716 minecraft:waxed_exposed_copper_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28663 -11 28717 minecraft:waxed_exposed_copper_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28663 -11 28718 minecraft:waxed_exposed_copper_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28663 -11 28719 minecraft:waxed_exposed_copper_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28660 -4 28716 minecraft:waxed_exposed_copper_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28660 -4 28717 minecraft:waxed_exposed_copper_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28660 -4 28718 minecraft:waxed_exposed_copper_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28660 -4 28719 minecraft:waxed_exposed_copper_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28657 0 28708 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28656 2 28712 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28656 3 28711 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28657 2 28708 minecraft:waxed_exposed_copper_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28657 2 28709 minecraft:waxed_exposed_copper_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28657 2 28710 minecraft:waxed_exposed_copper_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28657 2 28711 minecraft:waxed_exposed_copper_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28657 2 28712 minecraft:waxed_exposed_copper_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28656 2 28716 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28656 3 28717 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28657 2 28716 minecraft:waxed_exposed_copper_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28657 2 28717 minecraft:waxed_exposed_copper_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28657 2 28718 minecraft:waxed_exposed_copper_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28657 2 28719 minecraft:waxed_exposed_copper_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28656 20 28707 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28657 20 28707 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28656 20 28708 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28657 20 28708 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28656 20 28709 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28657 20 28709 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28656 20 28710 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28657 20 28710 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28659 21 28707 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28660 21 28707 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28659 21 28708 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28660 21 28708 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28659 21 28709 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28660 21 28709 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28659 21 28710 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28660 21 28710 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28663 22 28707 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28664 22 28707 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28663 22 28708 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28664 22 28708 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28663 22 28709 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28664 22 28709 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28663 22 28710 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28664 22 28710 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28666 23 28707 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28667 23 28707 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28666 23 28708 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28667 23 28708 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28666 23 28709 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28667 23 28709 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28666 23 28710 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28667 23 28710 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28670 24 28707 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28671 24 28707 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28670 24 28708 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28671 24 28708 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28670 24 28709 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28671 24 28709 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28670 24 28710 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28671 24 28710 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28658 20 28707 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28658 20 28708 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28658 20 28709 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28658 20 28710 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28658 20 28718 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28658 20 28719 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28661 21 28707 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28662 21 28707 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28661 21 28708 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28662 21 28708 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28661 21 28709 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28662 21 28709 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28661 21 28710 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28662 21 28710 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28661 21 28718 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28662 21 28718 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28661 21 28719 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28662 21 28719 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28665 22 28707 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28665 22 28708 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28665 22 28709 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28665 22 28710 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28665 22 28718 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28665 22 28719 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28668 23 28707 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28669 23 28707 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28668 23 28708 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28669 23 28708 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28668 23 28709 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28669 23 28709 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28668 23 28710 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28669 23 28710 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28668 23 28718 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28669 23 28718 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28668 23 28719 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28669 23 28719 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28656 20 28718 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28657 20 28718 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28656 20 28719 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28657 20 28719 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28659 21 28718 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28660 21 28718 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28659 21 28719 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28660 21 28719 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28663 22 28718 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28664 22 28718 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28663 22 28719 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28664 22 28719 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28666 23 28718 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28667 23 28718 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28666 23 28719 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28667 23 28719 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28670 24 28718 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28671 24 28718 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28670 24 28719 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28671 24 28719 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28658 21 28707 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28658 21 28708 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28658 21 28709 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28658 21 28710 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28661 22 28707 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28662 22 28707 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28661 22 28708 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28662 22 28708 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28661 22 28709 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28662 22 28709 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28661 22 28710 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28662 22 28710 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28669 24 28707 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28669 24 28708 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28669 24 28709 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28669 24 28710 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28658 21 28718 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28658 21 28719 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28661 22 28718 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28662 22 28718 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28661 22 28719 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28662 22 28719 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28669 24 28718 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28669 24 28719 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28665 23 28707 minecraft:dark_oak_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28665 23 28708 minecraft:dark_oak_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28665 23 28709 minecraft:dark_oak_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28665 23 28710 minecraft:dark_oak_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28665 23 28718 minecraft:dark_oak_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28665 23 28719 minecraft:dark_oak_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28668 24 28707 minecraft:dark_oak_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28668 24 28708 minecraft:dark_oak_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28668 24 28709 minecraft:dark_oak_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28668 24 28710 minecraft:dark_oak_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28668 24 28718 minecraft:dark_oak_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28668 24 28719 minecraft:dark_oak_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
data merge block 28656 -50 28708 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28657 -50 28708 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28658 -50 28708 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28671 -42 28708 {CookingTotalTimes: [I; 0, 0, 0, 0], CookingTimes: [I; 0, 0, 0, 0], Items: [], components: {}}
data merge block 28659 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28656 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28660 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28661 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28657 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28658 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28662 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28663 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28659 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28660 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28664 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28665 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28661 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28662 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28667 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28663 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28668 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28664 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28670 -23 28705 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28669 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28671 -23 28705 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28665 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28670 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28671 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28659 -27 28715 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28667 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28668 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28669 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28661 -27 28715 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28670 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28662 -35 28707 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:small_stripes", color: "green"}, {pattern: "minecraft:small_stripes", color: "lime"}]}
data merge block 28671 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28665 -37 28710 {is_waxed: 0b, front_text: {color: "black", messages: ['"                    "', '"                    "', '"                    "', '"                    "'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28669 -35 28715 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28671 -35 28715 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28662 -34 28707 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:small_stripes", color: "green"}, {pattern: "minecraft:small_stripes", color: "lime"}]}
data merge block 28656 -48 28708 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28656 -50 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28657 -48 28708 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28657 -50 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28659 -48 28708 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28658 -50 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28660 -48 28708 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28661 -48 28708 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28662 -48 28708 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28663 -48 28708 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28671 -42 28707 {CookingTotalTimes: [I; 0, 0, 0, 0], CookingTimes: [I; 0, 0, 0, 0], Items: [], components: {}}
data merge block 28664 -48 28708 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28665 -48 28708 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28666 -48 28708 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28667 -48 28708 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28670 -42 28711 {CookingTotalTimes: [I; 0, 0, 0, 0], CookingTimes: [I; 0, 0, 0, 0], Items: [], components: {}}
data merge block 28668 -48 28708 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28669 -48 28708 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28670 -48 28708 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28671 -48 28708 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28659 -27 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28661 -27 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28662 -45 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28663 -45 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28664 -45 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28665 -45 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28666 -45 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28667 -45 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28656 -48 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28657 -48 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28658 -48 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28656 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28657 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28658 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28659 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28660 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28656 -50 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28661 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28657 -50 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28662 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28658 -50 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28663 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28664 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28665 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28670 -48 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28671 -48 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28659 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28667 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28660 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28668 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28661 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28669 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28670 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28662 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28663 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28671 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28659 -27 28713 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28664 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28661 -27 28713 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28665 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28662 -35 28705 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:small_stripes", color: "green"}, {pattern: "minecraft:small_stripes", color: "lime"}]}
data merge block 28667 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28664 -35 28705 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:small_stripes", color: "green"}, {pattern: "minecraft:small_stripes", color: "lime"}]}
data merge block 28668 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28669 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28670 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28671 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28664 -37 28708 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28664 -33 28714 {is_waxed: 0b, front_text: {color: "red", messages: ['"       ███ █  █"', '"       █▄   \'▜▏▙▟▏▛\'"', '"       █▀   ,▟▏▛▜▏▙,"', '"       ███ █  █"'], has_glowing_text: 1b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28662 -34 28705 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:small_stripes", color: "green"}, {pattern: "minecraft:small_stripes", color: "lime"}]}
data merge block 28664 -34 28705 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:small_stripes", color: "green"}, {pattern: "minecraft:small_stripes", color: "lime"}]}
data merge block 28656 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28657 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28658 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28659 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28660 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28661 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28662 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28663 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28656 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28657 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28664 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28665 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28658 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28659 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28660 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28667 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28668 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28661 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28669 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28662 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28666 -40 28718 {bees: [], components: {}}
data merge block 28670 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28667 -40 28718 {bees: [], components: {}}
data merge block 28663 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28671 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28664 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28665 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28666 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28667 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28668 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28660 -27 28712 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28669 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28670 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28671 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28660 -27 28716 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28665 -37 28707 {Items: [], components: {}}
data merge block 28664 -33 28713 {is_waxed: 0b, front_text: {color: "red", messages: ['"███ ███       "', '"  █     █         "', '"  █     █         "', '"███   █         "'], has_glowing_text: 1b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28669 -35 28712 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28671 -35 28712 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
setblock 28597 -25 28720 minecraft:stone_button[face=wall,facing=south,powered=false]
setblock 28599 -25 28720 minecraft:stone_button[face=wall,facing=south,powered=false]
setblock 28595 -23 28720 minecraft:stone_button[face=wall,facing=south,powered=false]
setblock 28595 -21 28720 minecraft:stone_button[face=wall,facing=south,powered=false]
setblock 28597 -19 28720 minecraft:stone_button[face=wall,facing=south,powered=false]
setblock 28599 -19 28720 minecraft:stone_button[face=wall,facing=south,powered=false]
setblock 28611 -18 28723 minecraft:lever[face=floor,facing=west,powered=false]
setblock 28614 -24 28720 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28615 -22 28720 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28616 -20 28720 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28617 -18 28720 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28623 -22 28720 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28622 -21 28720 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28621 -20 28720 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28620 -19 28720 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28619 -18 28720 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28621 -8 28720 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28622 -7 28720 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28623 -6 28720 minecraft:lever[face=ceiling,facing=east,powered=false]
data merge block 28613 -15 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28614 -15 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28611 -19 28722 {components: {}}
data merge block 28611 -19 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
setblock 28624 -23 28720 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28639 -19 28720 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28638 -18 28720 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28637 -17 28720 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28630 -23 28720 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28631 -22 28720 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28632 -21 28720 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28633 -20 28720 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28634 -19 28720 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28635 -18 28720 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28624 -5 28720 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28625 -4 28720 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28626 -3 28720 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28627 -2 28720 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28628 -1 28720 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28629 0 28720 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28630 1 28721 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28631 2 28721 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28632 3 28721 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28633 4 28721 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28634 5 28721 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28635 6 28721 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28636 7 28721 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28637 8 28721 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28638 9 28721 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28639 10 28721 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28655 -50 28722 minecraft:iron_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28655 -50 28728 minecraft:iron_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28655 -50 28735 minecraft:iron_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28655 -50 28726 minecraft:iron_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28655 -50 28732 minecraft:iron_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28643 -23 28720 minecraft:jungle_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28642 -22 28720 minecraft:jungle_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28647 -23 28720 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28648 -22 28720 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28649 -21 28720 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28650 -20 28720 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28651 -19 28720 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28652 -18 28720 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28653 -17 28720 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28641 -21 28720 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28640 -20 28720 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28654 -16 28720 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28640 11 28721 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28641 12 28722 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28642 13 28722 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28643 14 28722 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28644 15 28722 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28654 6 28720 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28651 12 28720 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28654 8 28720 minecraft:waxed_exposed_copper_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28645 16 28722 minecraft:lever[face=ceiling,facing=east,powered=false]
setblock 28651 18 28720 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28651 18 28721 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28653 19 28720 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28654 19 28720 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28653 19 28721 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28654 19 28721 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28652 18 28720 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28652 18 28721 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28655 19 28720 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28655 19 28721 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28652 19 28720 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28652 19 28721 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28655 20 28720 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28655 20 28721 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
data merge block 28655 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28646 17 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28655 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28646 17 28723 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28655 -50 28729 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28655 -50 28731 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
setblock 28656 -49 28720 minecraft:lever[face=wall,facing=south,powered=true]
setblock 28656 -49 28727 minecraft:lever[face=wall,facing=south,powered=true]
setblock 28658 -49 28727 minecraft:lever[face=wall,facing=south,powered=true]
setblock 28656 -49 28733 minecraft:lever[face=wall,facing=south,powered=true]
setblock 28658 -49 28733 minecraft:lever[face=wall,facing=south,powered=true]
setblock 28656 -49 28721 minecraft:lever[face=wall,facing=north,powered=true]
setblock 28658 -49 28721 minecraft:lever[face=wall,facing=north,powered=true]
setblock 28656 -49 28734 minecraft:lever[face=wall,facing=north,powered=true]
setblock 28658 -49 28734 minecraft:lever[face=wall,facing=north,powered=true]
setblock 28661 -48 28722 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28662 -48 28722 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28663 -48 28722 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28665 -48 28722 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28667 -48 28722 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28661 -48 28728 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28662 -48 28728 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28663 -48 28728 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28665 -48 28728 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28667 -48 28728 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28661 -48 28735 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28662 -48 28735 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28663 -48 28735 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28665 -48 28735 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28667 -48 28735 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28661 -48 28726 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28662 -48 28726 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28663 -48 28726 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28665 -48 28726 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28667 -48 28726 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28661 -48 28732 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28662 -48 28732 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28663 -48 28732 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28665 -48 28732 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28667 -48 28732 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28666 -34 28727 minecraft:warped_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28667 -34 28727 minecraft:warped_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28668 -34 28727 minecraft:warped_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28666 -34 28728 minecraft:warped_trapdoor[facing=west,half=top,open=false,powered=false,waterlogged=false]
setblock 28666 -34 28729 minecraft:warped_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28667 -34 28729 minecraft:warped_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28667 -35 28720 minecraft:warped_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28668 -35 28720 minecraft:warped_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28669 -35 28720 minecraft:warped_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28667 -35 28721 minecraft:warped_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28668 -35 28721 minecraft:warped_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28669 -35 28721 minecraft:warped_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28667 -35 28722 minecraft:warped_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28668 -35 28722 minecraft:warped_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28669 -35 28722 minecraft:warped_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28668 -35 28723 minecraft:warped_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28669 -35 28723 minecraft:warped_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28669 -35 28724 minecraft:warped_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28668 -34 28728 minecraft:warped_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28668 -34 28729 minecraft:warped_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28669 -31 28722 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28667 -29 28720 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28668 -29 28720 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28669 -29 28720 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28667 -29 28721 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28668 -29 28721 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28669 -29 28721 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28667 -29 28722 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28668 -29 28722 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28669 -29 28722 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28668 -29 28723 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28669 -29 28723 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28669 -29 28724 minecraft:dark_oak_fence_gate[facing=west,in_wall=false,open=false,powered=false]
setblock 28668 -27 28723 minecraft:lever[face=floor,facing=west,powered=false]
setblock 28668 -27 28724 minecraft:lever[face=floor,facing=west,powered=false]
setblock 28662 -22 28720 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28661 -21 28720 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28660 -20 28720 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28659 -19 28720 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28658 -18 28720 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28657 -17 28720 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28656 -16 28720 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28663 -11 28720 minecraft:waxed_exposed_copper_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28660 -4 28720 minecraft:waxed_exposed_copper_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28660 -7 28720 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28657 0 28720 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28657 2 28720 minecraft:waxed_exposed_copper_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28656 20 28720 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28657 20 28720 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28656 20 28721 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28657 20 28721 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28659 21 28720 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28660 21 28720 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28659 21 28721 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28660 21 28721 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28663 22 28720 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28664 22 28720 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28663 22 28721 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28664 22 28721 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28666 23 28720 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28667 23 28720 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28666 23 28721 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28667 23 28721 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28670 24 28720 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28671 24 28720 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28670 24 28721 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28671 24 28721 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28658 20 28720 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28658 20 28721 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28661 21 28720 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28662 21 28720 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28661 21 28721 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28662 21 28721 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28665 22 28720 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28665 22 28721 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28668 23 28720 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28669 23 28720 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28668 23 28721 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28669 23 28721 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28658 21 28720 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28658 21 28721 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28661 22 28720 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28662 22 28720 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28661 22 28721 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28662 22 28721 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28669 24 28720 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28669 24 28721 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28665 23 28720 minecraft:dark_oak_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28665 23 28721 minecraft:dark_oak_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28668 24 28720 minecraft:dark_oak_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28668 24 28721 minecraft:dark_oak_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
data merge block 28664 -45 28731 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28665 -45 28731 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28666 -45 28731 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28667 -45 28731 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28656 -48 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28656 -50 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28657 -48 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28658 -48 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28657 -50 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28658 -50 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28656 -48 28733 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28657 -48 28733 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28658 -48 28733 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28670 -48 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28671 -48 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28670 -48 28733 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28671 -48 28733 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28668 -27 28727 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:bricks", color: "orange"}, {pattern: "minecraft:bricks", color: "yellow"}]}
data merge block 28666 -33 28728 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28671 -35 28723 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28668 -33 28728 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28656 -48 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28657 -48 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28659 -48 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28671 -34 28723 {is_waxed: 0b, front_text: {color: "black", messages: ['">                    <"', '"Build by Kaizen87"', '"Search on Google"', '">                    <"'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28660 -48 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28661 -48 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28656 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28657 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28662 -48 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28663 -48 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28658 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28659 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28664 -48 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28665 -48 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28656 -50 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28660 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28657 -50 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28661 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28666 -48 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28667 -48 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28662 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28658 -50 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28668 -48 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28663 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28669 -48 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28664 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28670 -48 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28665 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28671 -48 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28667 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28659 -50 28731 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28668 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28660 -50 28731 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28669 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28661 -50 28731 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28670 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28662 -50 28731 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28671 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28663 -50 28731 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28664 -50 28731 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28665 -50 28731 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28667 -50 28731 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28668 -50 28731 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28669 -50 28731 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28670 -50 28731 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28671 -50 28731 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28667 -27 28726 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:bricks", color: "orange"}, {pattern: "minecraft:bricks", color: "yellow"}]}
data merge block 28669 -27 28726 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:bricks", color: "orange"}, {pattern: "minecraft:bricks", color: "yellow"}]}
data merge block 28666 -33 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28667 -33 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28668 -31 28728 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:bricks", color: "orange"}]}
data merge block 28668 -33 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28656 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28657 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28658 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28659 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28660 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28661 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28662 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28663 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28664 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28656 -50 28734 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28665 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28666 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28657 -50 28734 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28658 -50 28734 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28667 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28668 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28669 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28670 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28671 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28670 -23 28723 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28671 -23 28723 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28668 -27 28725 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:bricks", color: "orange"}, {pattern: "minecraft:bricks", color: "yellow"}]}
data merge block 28667 -31 28727 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:bricks", color: "orange"}]}
data merge block 28656 -50 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28657 -50 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28658 -50 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28659 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28660 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28656 -50 28729 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28657 -50 28729 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28661 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28658 -50 28729 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28662 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28656 -48 28734 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28659 -50 28729 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28663 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28657 -48 28734 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28656 -50 28733 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28664 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28660 -50 28729 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28657 -50 28733 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28665 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28658 -48 28734 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28661 -50 28729 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28658 -50 28733 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28662 -50 28729 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28659 -48 28734 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28660 -48 28734 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28663 -50 28729 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28667 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28661 -48 28734 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28664 -50 28729 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28668 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28669 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28662 -48 28734 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28665 -50 28729 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28670 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28663 -48 28734 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28664 -48 28734 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28667 -50 28729 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28671 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28668 -50 28729 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28665 -48 28734 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28669 -50 28729 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28666 -48 28734 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28667 -48 28734 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28670 -50 28729 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28671 -50 28729 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28668 -48 28734 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28669 -48 28734 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28670 -48 28734 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28671 -48 28734 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28666 -31 28726 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:bricks", color: "orange"}]}
data merge block 28666 -33 28729 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28667 -33 28729 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28662 -45 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28668 -33 28729 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28662 -39 28730 {is_waxed: 0b, front_text: {color: "black", messages: ['">                    <"', '"Build by Kaizen87"', '"Search on Google"', '">                    <"'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28663 -45 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28664 -45 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28664 -39 28730 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28665 -45 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28666 -45 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28666 -39 28730 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28667 -45 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28662 -45 28731 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28663 -45 28731 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
setblock 28655 -50 28739 minecraft:iron_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
data merge block 28655 -50 28736 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28655 -50 28738 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
setblock 28656 -49 28740 minecraft:lever[face=wall,facing=south,powered=true]
setblock 28658 -49 28740 minecraft:lever[face=wall,facing=south,powered=true]
setblock 28661 -48 28739 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28662 -48 28739 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28663 -48 28739 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28665 -48 28739 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28667 -48 28739 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
data merge block 28656 -50 28736 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28657 -50 28736 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28656 -48 28740 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28658 -50 28736 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28657 -48 28740 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28659 -50 28736 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28656 -50 28740 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28658 -48 28740 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28660 -50 28736 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28657 -50 28740 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28659 -50 28738 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28659 -48 28740 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28661 -50 28736 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28658 -50 28740 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28660 -50 28738 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28660 -48 28740 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28662 -50 28736 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28661 -50 28738 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28661 -48 28740 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28663 -50 28736 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28662 -50 28738 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28662 -48 28740 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28664 -50 28736 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28663 -50 28738 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28663 -48 28740 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28665 -50 28736 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28664 -50 28738 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28664 -48 28740 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28665 -48 28740 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28665 -50 28738 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28667 -50 28736 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28666 -48 28740 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28668 -50 28736 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28667 -50 28738 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28667 -48 28740 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28669 -50 28736 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28668 -48 28740 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28670 -50 28736 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28668 -50 28738 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28669 -48 28740 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28669 -50 28738 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28671 -50 28736 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28670 -48 28740 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28670 -50 28738 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28671 -50 28738 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28671 -48 28740 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
setblock 28680 -51 28691 minecraft:waxed_exposed_copper_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28675 -49 28689 minecraft:jungle_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28675 -49 28693 minecraft:jungle_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28675 -49 28696 minecraft:jungle_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28675 -49 28700 minecraft:jungle_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28675 -49 28702 minecraft:jungle_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28682 -49 28702 minecraft:jungle_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28675 -40 28696 minecraft:waxed_exposed_copper_door[facing=north,half=lower,hinge=left,open=false,powered=false]
setblock 28676 -40 28696 minecraft:waxed_exposed_copper_door[facing=north,half=lower,hinge=right,open=false,powered=false]
setblock 28673 -40 28702 minecraft:dark_oak_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28675 -39 28696 minecraft:waxed_exposed_copper_door[facing=north,half=upper,hinge=left,open=false,powered=false]
setblock 28676 -39 28696 minecraft:waxed_exposed_copper_door[facing=north,half=upper,hinge=right,open=false,powered=false]
setblock 28680 -38 28703 minecraft:iron_trapdoor[facing=west,half=top,open=false,powered=false,waterlogged=false]
setblock 28674 -36 28696 minecraft:warped_fence_gate[facing=north,in_wall=false,open=true,powered=false]
setblock 28678 -36 28696 minecraft:warped_fence_gate[facing=north,in_wall=false,open=true,powered=false]
setblock 28674 -35 28697 minecraft:warped_fence_gate[facing=north,in_wall=false,open=true,powered=false]
setblock 28678 -35 28697 minecraft:warped_fence_gate[facing=north,in_wall=false,open=true,powered=false]
setblock 28674 -34 28698 minecraft:warped_fence_gate[facing=north,in_wall=false,open=true,powered=false]
setblock 28678 -34 28698 minecraft:warped_fence_gate[facing=north,in_wall=false,open=true,powered=false]
setblock 28674 -33 28699 minecraft:warped_fence_gate[facing=north,in_wall=false,open=true,powered=false]
setblock 28678 -33 28699 minecraft:warped_fence_gate[facing=north,in_wall=false,open=true,powered=false]
setblock 28683 -36 28697 minecraft:warped_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28686 -36 28698 minecraft:warped_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28682 -35 28698 minecraft:warped_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28685 -35 28699 minecraft:warped_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28681 -34 28699 minecraft:warped_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28684 -34 28700 minecraft:warped_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28680 -33 28700 minecraft:warped_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28683 -33 28701 minecraft:warped_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28679 -35 28703 minecraft:bamboo_trapdoor[facing=north,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28676 -27 28699 minecraft:lever[face=floor,facing=north,powered=false]
setblock 28677 -27 28699 minecraft:lever[face=floor,facing=north,powered=false]
setblock 28676 -27 28702 minecraft:lever[face=floor,facing=south,powered=false]
setblock 28677 -27 28702 minecraft:lever[face=floor,facing=south,powered=false]
setblock 28674 -26 28700 minecraft:stone_pressure_plate[powered=false]
setblock 28679 -26 28700 minecraft:stone_pressure_plate[powered=false]
setblock 28673 -26 28701 minecraft:stone_pressure_plate[powered=false]
setblock 28674 -26 28701 minecraft:stone_pressure_plate[powered=false]
setblock 28675 -26 28701 minecraft:stone_pressure_plate[powered=false]
setblock 28678 -26 28701 minecraft:stone_pressure_plate[powered=false]
setblock 28679 -26 28701 minecraft:stone_pressure_plate[powered=false]
setblock 28680 -26 28701 minecraft:stone_pressure_plate[powered=false]
setblock 28674 -26 28702 minecraft:stone_pressure_plate[powered=false]
setblock 28679 -26 28702 minecraft:stone_pressure_plate[powered=false]
data merge block 28680 -30 28698 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:stripe_top", color: "black"}, {pattern: "minecraft:stripe_bottom", color: "black"}, {pattern: "minecraft:half_vertical", color: "gray"}]}
data merge block 28672 -48 28688 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28675 -38 28697 {is_waxed: 0b, front_text: {color: "red", messages: ['"       ███ █  █"', '"       █▄   \'▜▏▙▟▏▛\'"', '"       █▀   ,▟▏▛▜▏▙,"', '"       ███ █  █"'], has_glowing_text: 1b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28676 -38 28697 {is_waxed: 0b, front_text: {color: "red", messages: ['"███ ███       "', '"  █     █         "', '"  █     █         "', '"███   █         "'], has_glowing_text: 1b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28672 -50 28690 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28673 -50 28690 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28672 -48 28694 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28674 -50 28690 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28672 -50 28692 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28673 -50 28692 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28675 -50 28690 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28672 -48 28695 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28674 -50 28692 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28675 -50 28692 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28672 -50 28697 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28673 -50 28697 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28672 -50 28699 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28672 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28674 -50 28697 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28675 -50 28697 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28673 -50 28699 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28674 -50 28699 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28675 -50 28699 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28672 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28673 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28674 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28675 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28672 -29 28698 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:stripe_top", color: "black"}, {pattern: "minecraft:stripe_bottom", color: "black"}, {pattern: "minecraft:half_vertical", color: "gray"}, {pattern: "minecraft:half_horizontal", color: "gray"}]}
data merge block 28685 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28686 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28676 -29 28698 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:stripe_top", color: "black"}, {pattern: "minecraft:stripe_bottom", color: "black"}, {pattern: "minecraft:half_vertical", color: "gray"}, {pattern: "minecraft:half_horizontal", color: "gray"}]}
data merge block 28682 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28687 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28683 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28684 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28672 -39 28695 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:stripe_right", color: "light_gray"}, {pattern: "minecraft:stripe_left", color: "light_gray"}]}
data merge block 28685 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28680 -29 28698 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:stripe_top", color: "black"}, {pattern: "minecraft:stripe_bottom", color: "black"}, {pattern: "minecraft:half_vertical", color: "gray"}, {pattern: "minecraft:half_horizontal", color: "gray"}]}
data merge block 28686 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28687 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28672 -28 28698 {components: {}}
data merge block 28672 -30 28698 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:stripe_top", color: "black"}, {pattern: "minecraft:stripe_bottom", color: "black"}, {pattern: "minecraft:half_vertical", color: "gray"}]}
data merge block 28676 -28 28698 {components: {}}
data merge block 28676 -30 28698 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:stripe_top", color: "black"}, {pattern: "minecraft:stripe_bottom", color: "black"}, {pattern: "minecraft:half_vertical", color: "gray"}]}
data merge block 28672 -38 28695 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:stripe_right", color: "light_gray"}, {pattern: "minecraft:diagonal_right", color: "gray"}, {pattern: "minecraft:stripe_left", color: "light_gray"}, {pattern: "minecraft:stripe_downleft", color: "light_gray"}, {pattern: "minecraft:stripe_downright", color: "light_gray"}]}
data merge block 28680 -28 28698 {components: {}}
setblock 28699 -49 28701 minecraft:lever[face=wall,facing=north,powered=true]
setblock 28701 -49 28701 minecraft:lever[face=wall,facing=north,powered=true]
setblock 28702 -50 28702 minecraft:iron_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28690 -48 28702 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28692 -48 28702 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28694 -48 28702 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28695 -48 28702 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28696 -48 28702 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
data merge block 28688 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28689 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28690 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28691 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28692 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28688 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28689 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28693 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28690 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28694 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28695 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28692 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28696 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28693 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28697 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28694 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28698 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
