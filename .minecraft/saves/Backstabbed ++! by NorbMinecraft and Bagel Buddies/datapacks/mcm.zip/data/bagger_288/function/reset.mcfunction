schedule clear bagger_288:activate
kill @e[tag=Bagger288Runtime]
tag @a remove Bagger288Participant
function bagger_288:restore_blocks
