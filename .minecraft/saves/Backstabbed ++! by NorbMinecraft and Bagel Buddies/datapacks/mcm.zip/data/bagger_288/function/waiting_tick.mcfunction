execute unless score $selectedMap CmdData matches 18 run return 0
execute unless score $gamestate CmdData matches 0 run return 0
execute as @a[tag=queued,tag=!spectating,gamemode=!spectator] at @s if predicate bagger_288:arena run tag @s add Bagger288Participant
execute as @a[tag=queued,tag=Bagger288Participant,tag=!spectating,gamemode=!spectator] at @s unless score @s dead matches 1.. run function bagger_288:check_player
