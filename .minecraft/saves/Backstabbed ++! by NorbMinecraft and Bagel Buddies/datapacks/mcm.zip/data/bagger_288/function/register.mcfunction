execute unless entity @e[type=marker,tag=MapVote,tag=Bagger288] run summon marker 0 -50 70 {Tags:["MapVote","Bagger288"]}
scoreboard players set @e[type=marker,tag=MapVote,tag=Bagger288] MapValues 18
function mcm:lobby/options/map_toggle/init
