execute if predicate bagger_288:wheels run return run function bagger_288:squashed
execute if predicate bagger_288:below_death_line run return run function bagger_288:fall
execute unless predicate bagger_288:arena run return run function bagger_288:fall
execute if block ~ ~ ~ #bagger_288:fluids run return run function bagger_288:fall
execute if block ~ ~ ~ #bagger_288:waterloggable[waterlogged=true] run return run function bagger_288:fall
execute if block ~ ~1 ~ #bagger_288:fluids run return run function bagger_288:fall
execute if block ~ ~1 ~ #bagger_288:waterloggable[waterlogged=true] run return run function bagger_288:fall
