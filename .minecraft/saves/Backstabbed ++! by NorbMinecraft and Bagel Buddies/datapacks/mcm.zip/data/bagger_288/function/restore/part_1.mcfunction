data merge block 28695 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28699 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28700 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28696 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28699 -50 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28697 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28701 -48 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28700 -50 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['">                    <"', '"Build by Kaizen87"', '"Search on Google"', '">                    <"'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28698 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28701 -50 28701 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28702 -50 28703 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
setblock 28675 -49 28706 minecraft:jungle_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28675 -49 28709 minecraft:jungle_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28675 -49 28713 minecraft:jungle_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28675 -49 28715 minecraft:jungle_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28675 -49 28719 minecraft:jungle_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28682 -49 28706 minecraft:jungle_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28682 -49 28709 minecraft:jungle_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28682 -49 28713 minecraft:jungle_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28682 -49 28715 minecraft:jungle_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28682 -49 28719 minecraft:jungle_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28684 -40 28706 minecraft:composter[level=0]
setblock 28676 -40 28710 minecraft:oak_trapdoor[facing=north,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28681 -40 28717 minecraft:weathered_copper_door[facing=east,half=lower,hinge=left,open=false,powered=false]
setblock 28682 -40 28717 minecraft:weathered_copper_door[facing=east,half=lower,hinge=left,open=false,powered=false]
setblock 28683 -40 28717 minecraft:weathered_copper_door[facing=east,half=lower,hinge=left,open=false,powered=false]
setblock 28684 -40 28717 minecraft:weathered_copper_door[facing=east,half=lower,hinge=left,open=false,powered=false]
setblock 28673 -40 28718 minecraft:bamboo_trapdoor[facing=west,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28678 -40 28718 minecraft:bamboo_trapdoor[facing=west,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28682 -40 28718 minecraft:bamboo_trapdoor[facing=west,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28673 -39 28718 minecraft:bamboo_trapdoor[facing=west,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28678 -39 28718 minecraft:bamboo_trapdoor[facing=west,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28682 -39 28718 minecraft:bamboo_trapdoor[facing=west,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28673 -38 28718 minecraft:bamboo_trapdoor[facing=west,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28678 -38 28718 minecraft:bamboo_trapdoor[facing=west,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28682 -38 28718 minecraft:bamboo_trapdoor[facing=west,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28673 -37 28718 minecraft:bamboo_trapdoor[facing=west,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28678 -37 28718 minecraft:bamboo_trapdoor[facing=west,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28682 -37 28718 minecraft:bamboo_trapdoor[facing=west,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28678 -35 28704 minecraft:bamboo_trapdoor[facing=west,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28674 -40 28718 minecraft:bamboo_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28683 -40 28718 minecraft:bamboo_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28679 -40 28718 minecraft:bamboo_trapdoor[facing=east,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28674 -39 28718 minecraft:bamboo_trapdoor[facing=east,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28679 -39 28718 minecraft:bamboo_trapdoor[facing=east,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28683 -39 28718 minecraft:bamboo_trapdoor[facing=east,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28674 -38 28718 minecraft:bamboo_trapdoor[facing=east,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28679 -38 28718 minecraft:bamboo_trapdoor[facing=east,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28683 -38 28718 minecraft:bamboo_trapdoor[facing=east,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28674 -37 28718 minecraft:bamboo_trapdoor[facing=east,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28679 -37 28718 minecraft:bamboo_trapdoor[facing=east,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28683 -37 28718 minecraft:bamboo_trapdoor[facing=east,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28680 -35 28704 minecraft:bamboo_trapdoor[facing=east,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28687 -40 28718 minecraft:birch_pressure_plate[powered=false]
setblock 28680 -35 28705 minecraft:birch_pressure_plate[powered=false]
setblock 28684 -39 28706 minecraft:dark_oak_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28677 -39 28713 minecraft:lever[face=floor,facing=south,powered=false]
setblock 28681 -39 28717 minecraft:weathered_copper_door[facing=east,half=upper,hinge=left,open=false,powered=false]
setblock 28682 -39 28717 minecraft:weathered_copper_door[facing=east,half=upper,hinge=left,open=false,powered=false]
setblock 28683 -39 28717 minecraft:weathered_copper_door[facing=east,half=upper,hinge=left,open=false,powered=false]
setblock 28684 -39 28717 minecraft:weathered_copper_door[facing=east,half=upper,hinge=left,open=false,powered=false]
setblock 28675 -37 28704 minecraft:lever[face=ceiling,facing=north,powered=false]
setblock 28676 -37 28704 minecraft:lever[face=ceiling,facing=north,powered=false]
setblock 28677 -37 28704 minecraft:lever[face=ceiling,facing=north,powered=false]
setblock 28681 -37 28705 minecraft:oxidized_copper_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28672 -37 28707 minecraft:oxidized_copper_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28686 -37 28706 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28686 -37 28707 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28686 -37 28708 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28686 -37 28709 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28686 -37 28711 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28675 -37 28709 minecraft:lever[face=ceiling,facing=south,powered=false]
setblock 28676 -37 28709 minecraft:lever[face=ceiling,facing=south,powered=false]
setblock 28677 -37 28709 minecraft:lever[face=ceiling,facing=south,powered=false]
setblock 28686 -37 28712 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28687 -37 28712 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28686 -37 28713 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28686 -37 28714 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28686 -37 28715 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28686 -37 28716 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28686 -37 28717 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28686 -37 28718 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28679 -35 28705 minecraft:bamboo_trapdoor[facing=south,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28685 -35 28707 minecraft:weathered_copper_door[facing=south,half=lower,hinge=left,open=false,powered=false]
setblock 28685 -35 28708 minecraft:weathered_copper_door[facing=south,half=lower,hinge=right,open=false,powered=false]
setblock 28685 -35 28709 minecraft:weathered_copper_door[facing=south,half=lower,hinge=right,open=false,powered=false]
setblock 28685 -35 28710 minecraft:weathered_copper_door[facing=south,half=lower,hinge=right,open=false,powered=false]
setblock 28685 -34 28707 minecraft:weathered_copper_door[facing=south,half=upper,hinge=left,open=false,powered=false]
setblock 28685 -34 28708 minecraft:weathered_copper_door[facing=south,half=upper,hinge=right,open=false,powered=false]
setblock 28685 -34 28709 minecraft:weathered_copper_door[facing=south,half=upper,hinge=right,open=false,powered=false]
setblock 28685 -34 28710 minecraft:weathered_copper_door[facing=south,half=upper,hinge=right,open=false,powered=false]
setblock 28679 -34 28714 minecraft:comparator[facing=east,mode=compare,powered=false]
setblock 28679 -34 28716 minecraft:daylight_detector[inverted=false,power=9]
setblock 28672 -33 28704 minecraft:pale_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28676 -30 28713 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28676 -30 28714 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28676 -30 28715 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28680 -29 28704 minecraft:bamboo_fence_gate[facing=east,in_wall=false,open=false,powered=false]
setblock 28681 -29 28704 minecraft:bamboo_fence_gate[facing=east,in_wall=false,open=false,powered=false]
setblock 28680 -29 28705 minecraft:bamboo_fence_gate[facing=east,in_wall=false,open=false,powered=false]
setblock 28681 -29 28705 minecraft:bamboo_fence_gate[facing=east,in_wall=false,open=false,powered=false]
setblock 28680 -29 28706 minecraft:bamboo_fence_gate[facing=east,in_wall=false,open=false,powered=false]
setblock 28681 -29 28706 minecraft:bamboo_fence_gate[facing=east,in_wall=false,open=false,powered=false]
setblock 28680 -29 28707 minecraft:bamboo_fence_gate[facing=east,in_wall=false,open=false,powered=false]
setblock 28681 -29 28707 minecraft:bamboo_fence_gate[facing=east,in_wall=false,open=false,powered=false]
setblock 28680 -29 28708 minecraft:bamboo_fence_gate[facing=east,in_wall=false,open=false,powered=false]
setblock 28681 -29 28708 minecraft:bamboo_fence_gate[facing=east,in_wall=false,open=false,powered=false]
setblock 28680 -29 28709 minecraft:bamboo_fence_gate[facing=east,in_wall=false,open=false,powered=false]
setblock 28680 -29 28710 minecraft:bamboo_fence_gate[facing=east,in_wall=false,open=false,powered=false]
setblock 28682 -29 28709 minecraft:bamboo_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28683 -29 28709 minecraft:bamboo_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28684 -29 28709 minecraft:bamboo_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28685 -29 28709 minecraft:bamboo_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28686 -29 28709 minecraft:bamboo_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28687 -29 28709 minecraft:bamboo_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28681 -29 28711 minecraft:bamboo_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28682 -29 28711 minecraft:bamboo_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28683 -29 28711 minecraft:bamboo_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28684 -29 28711 minecraft:bamboo_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28685 -29 28711 minecraft:bamboo_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28686 -29 28711 minecraft:bamboo_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28687 -29 28711 minecraft:bamboo_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28676 -29 28712 minecraft:lever[face=floor,facing=south,powered=false]
setblock 28675 -29 28713 minecraft:lever[face=floor,facing=east,powered=false]
setblock 28675 -29 28714 minecraft:lever[face=floor,facing=east,powered=false]
setblock 28675 -29 28715 minecraft:lever[face=floor,facing=east,powered=false]
setblock 28677 -29 28713 minecraft:lever[face=floor,facing=west,powered=false]
setblock 28677 -29 28714 minecraft:lever[face=floor,facing=west,powered=false]
setblock 28677 -29 28715 minecraft:lever[face=floor,facing=west,powered=false]
setblock 28676 -29 28716 minecraft:lever[face=floor,facing=north,powered=false]
setblock 28675 -28 28712 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28676 -28 28712 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28677 -28 28712 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28675 -28 28713 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28676 -28 28713 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28677 -28 28713 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28675 -28 28714 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28676 -28 28714 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28677 -28 28714 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28675 -28 28715 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28676 -28 28715 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28677 -28 28715 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28675 -28 28716 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28676 -28 28716 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28677 -28 28716 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28684 -13 28708 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28687 -7 28716 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28687 -6 28717 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28687 -5 28718 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28687 -4 28719 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28687 -7 28712 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28687 -6 28711 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28687 -5 28710 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28687 -4 28709 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28687 -3 28708 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28687 1 28712 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28687 2 28711 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28687 3 28710 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28687 4 28709 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28687 5 28708 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28687 9 28712 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28687 10 28711 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28687 11 28710 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28687 12 28709 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28687 13 28708 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28687 1 28716 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28687 2 28717 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28687 3 28718 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28687 4 28719 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28687 9 28716 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28687 10 28717 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28687 11 28718 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28687 12 28719 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28685 22 28706 minecraft:spruce_trapdoor[facing=south,half=top,open=true,powered=false,waterlogged=false]
setblock 28685 22 28707 minecraft:lever[face=wall,facing=west,powered=false]
setblock 28685 22 28711 minecraft:lever[face=wall,facing=west,powered=false]
setblock 28685 22 28717 minecraft:lever[face=wall,facing=west,powered=false]
setblock 28672 24 28707 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28673 24 28707 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28672 24 28708 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28673 24 28708 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28672 24 28709 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28673 24 28709 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28672 24 28710 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28673 24 28710 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28672 24 28718 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28673 24 28718 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28672 24 28719 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28673 24 28719 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28672 25 28707 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28673 25 28707 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28672 25 28708 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28673 25 28708 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28672 25 28709 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28673 25 28709 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28672 25 28710 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28673 25 28710 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28674 25 28707 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28675 25 28707 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28674 25 28708 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28675 25 28708 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28674 25 28709 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28675 25 28709 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28674 25 28710 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28675 25 28710 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28678 26 28707 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28679 26 28707 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28678 26 28708 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28679 26 28708 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28678 26 28709 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28679 26 28709 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28678 26 28710 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28679 26 28710 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28682 27 28707 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28683 27 28707 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28682 27 28708 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28683 27 28708 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28682 27 28709 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28683 27 28709 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28682 27 28710 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28683 27 28710 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28676 25 28707 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28677 25 28707 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28676 25 28708 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28677 25 28708 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28676 25 28709 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28677 25 28709 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28676 25 28710 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28677 25 28710 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28680 26 28707 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28681 26 28707 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28680 26 28708 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28681 26 28708 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28680 26 28709 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28681 26 28709 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28680 26 28710 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28681 26 28710 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28672 25 28718 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28673 25 28718 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28672 25 28719 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28673 25 28719 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28674 25 28718 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28675 25 28718 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28674 25 28719 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28675 25 28719 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28678 26 28718 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28679 26 28718 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28678 26 28719 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28679 26 28719 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28682 27 28718 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28683 27 28718 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28682 27 28719 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28683 27 28719 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28676 25 28718 minecraft:dark_oak_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28677 25 28718 minecraft:dark_oak_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28676 25 28719 minecraft:dark_oak_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28677 25 28719 minecraft:dark_oak_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28680 26 28718 minecraft:dark_oak_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28681 26 28718 minecraft:dark_oak_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28680 26 28719 minecraft:dark_oak_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28681 26 28719 minecraft:dark_oak_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28676 26 28707 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28677 26 28707 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28676 26 28708 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28677 26 28708 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28676 26 28709 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28677 26 28709 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28676 26 28710 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28677 26 28710 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28676 26 28718 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28677 26 28718 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28676 26 28719 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28677 26 28719 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28680 27 28707 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28681 27 28707 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28680 27 28708 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28681 27 28708 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28680 27 28709 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28681 27 28709 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28680 27 28710 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28681 27 28710 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28680 27 28718 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28681 27 28718 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28680 27 28719 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28681 27 28719 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28684 28 28707 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28685 28 28707 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28684 28 28708 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28685 28 28708 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28684 28 28709 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28685 28 28709 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28684 28 28710 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28685 28 28710 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28684 28 28718 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28685 28 28718 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28684 28 28719 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28685 28 28719 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28684 27 28707 minecraft:dark_oak_trapdoor[facing=west,half=top,open=false,powered=false,waterlogged=false]
setblock 28685 27 28707 minecraft:dark_oak_trapdoor[facing=west,half=top,open=false,powered=false,waterlogged=false]
setblock 28684 27 28708 minecraft:dark_oak_trapdoor[facing=west,half=top,open=false,powered=false,waterlogged=false]
setblock 28685 27 28708 minecraft:dark_oak_trapdoor[facing=west,half=top,open=false,powered=false,waterlogged=false]
setblock 28684 27 28709 minecraft:dark_oak_trapdoor[facing=west,half=top,open=false,powered=false,waterlogged=false]
setblock 28685 27 28709 minecraft:dark_oak_trapdoor[facing=west,half=top,open=false,powered=false,waterlogged=false]
setblock 28684 27 28710 minecraft:dark_oak_trapdoor[facing=west,half=top,open=false,powered=false,waterlogged=false]
setblock 28685 27 28710 minecraft:dark_oak_trapdoor[facing=west,half=top,open=false,powered=false,waterlogged=false]
setblock 28684 27 28718 minecraft:dark_oak_trapdoor[facing=west,half=top,open=false,powered=false,waterlogged=false]
setblock 28685 27 28718 minecraft:dark_oak_trapdoor[facing=west,half=top,open=false,powered=false,waterlogged=false]
setblock 28684 27 28719 minecraft:dark_oak_trapdoor[facing=west,half=top,open=false,powered=false,waterlogged=false]
setblock 28685 27 28719 minecraft:dark_oak_trapdoor[facing=west,half=top,open=false,powered=false,waterlogged=false]
setblock 28686 28 28705 minecraft:lever[face=wall,facing=north,powered=false]
data merge block 28676 -24 28713 {components: {}}
data merge block 28674 -30 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28678 -30 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28674 -40 28713 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28675 -40 28713 {components: {}}
data merge block 28676 -40 28713 {components: {}}
data merge block 28679 -34 28716 {components: {}}
data merge block 28677 -40 28713 {last_interacted_slot: -1, Items: [], components: {}}
data merge block 28678 -40 28713 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28672 -23 28705 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28673 -23 28705 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28674 -23 28705 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28672 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28675 -23 28705 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28673 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28674 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28676 -23 28705 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28675 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28677 -23 28705 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28686 -36 28715 {CookingTotalTimes: [I; 0, 0, 0, 0], CookingTimes: [I; 0, 0, 0, 0], Items: [], components: {}}
data merge block 28672 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28678 -23 28705 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28673 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28679 -23 28705 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28674 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28680 -23 28705 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28681 -23 28705 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28675 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28682 -23 28705 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28683 -23 28705 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28675 -25 28712 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28684 -23 28705 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28682 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28683 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28676 -25 28712 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28685 -23 28705 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28684 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28686 -23 28705 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28677 -25 28712 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28685 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28686 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28682 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28675 -25 28716 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28687 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28683 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28676 -25 28716 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28684 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28677 -25 28716 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28685 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28686 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28674 -35 28711 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28687 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28673 -35 28715 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28678 -35 28711 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28679 -35 28715 {components: {}}
data merge block 28680 -35 28715 {crafting_ticks_remaining: 0, Items: [], components: {}, disabled_slots: [I; ], triggered: 0}
data merge block 28674 -30 28713 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28677 -26 28715 {components: {}}
data merge block 28678 -30 28713 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28675 -30 28717 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28676 -30 28717 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28677 -30 28717 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28675 -40 28712 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28676 -40 28712 {is_waxed: 0b, front_text: {color: "black", messages: ['">                    <"', '"Build by Kaizen87"', '"Search on Google"', '">                    <"'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28675 -34 28719 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:small_stripes", color: "black"}, {pattern: "minecraft:small_stripes", color: "gray"}, {pattern: "minecraft:gradient_up", color: "black"}]}
data merge block 28672 -48 28708 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28676 -34 28719 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:small_stripes", color: "black"}, {pattern: "minecraft:small_stripes", color: "gray"}, {pattern: "minecraft:gradient_up", color: "black"}]}
data merge block 28677 -40 28712 {is_waxed: 0b, front_text: {color: "black", messages: ['"   "', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28677 -34 28719 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:small_stripes", color: "black"}, {pattern: "minecraft:small_stripes", color: "gray"}, {pattern: "minecraft:gradient_up", color: "black"}]}
data merge block 28682 -42 28707 {CookingTotalTimes: [I; 0, 0, 0, 0], CookingTimes: [I; 0, 0, 0, 0], Items: [], components: {}}
data merge block 28685 -48 28708 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28686 -48 28708 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28687 -48 28708 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28675 -25 28715 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28676 -25 28715 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28677 -25 28715 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28674 -35 28710 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28673 -35 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28678 -35 28710 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28674 -35 28718 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28675 -33 28719 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:small_stripes", color: "black"}, {pattern: "minecraft:small_stripes", color: "gray"}, {pattern: "minecraft:gradient_up", color: "black"}]}
data merge block 28676 -33 28719 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:small_stripes", color: "black"}, {pattern: "minecraft:small_stripes", color: "gray"}, {pattern: "minecraft:gradient_up", color: "black"}]}
data merge block 28677 -33 28719 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:small_stripes", color: "black"}, {pattern: "minecraft:small_stripes", color: "gray"}, {pattern: "minecraft:gradient_up", color: "black"}]}
data merge block 28680 -35 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28674 -24 28711 {components: {}}
data merge block 28677 -24 28711 {components: {}}
data merge block 28676 -26 28714 {components: {}}
data merge block 28674 -30 28712 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28678 -30 28712 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28674 -30 28716 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28678 -30 28716 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28673 -42 28710 {CookingTotalTimes: [I; 0, 0, 0, 0], CookingTimes: [I; 0, 0, 0, 0], Items: [], components: {}}
data merge block 28675 -40 28711 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28679 -34 28714 {OutputSignal: 0, components: {}}
data merge block 28672 -48 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28677 -40 28711 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28672 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28681 -42 28710 {CookingTotalTimes: [I; 0, 0, 0, 0], CookingTimes: [I; 0, 0, 0, 0], Items: [], components: {}}
data merge block 28673 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28674 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28675 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28685 -48 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28672 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28673 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28686 -48 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28682 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28687 -48 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28674 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28675 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28683 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28684 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28685 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28675 -25 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28686 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28676 -25 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28687 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28677 -25 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28674 -35 28709 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28682 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28683 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28684 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28685 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28673 -35 28713 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28678 -35 28709 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28686 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28687 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28674 -35 28717 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28680 -35 28713 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28675 -30 28711 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28676 -30 28711 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28677 -30 28711 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28674 -30 28715 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28678 -30 28715 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28672 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28673 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28675 -40 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28674 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28675 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28676 -40 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28677 -40 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28683 -42 28709 {CookingTotalTimes: [I; 0, 0, 0, 0], CookingTimes: [I; 0, 0, 0, 0], Items: [], components: {}}
data merge block 28672 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28687 -36 28712 {CookingTotalTimes: [I; 0, 0, 0, 0], CookingTimes: [I; 0, 0, 0, 0], Items: [], components: {}}
data merge block 28682 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28683 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28684 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28685 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28686 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28687 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28675 -25 28713 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28676 -25 28713 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28677 -25 28713 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28685 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28686 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28675 -23 28718 {components: {}}
data merge block 28687 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28673 -35 28712 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28673 -35 28716 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28680 -35 28716 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
setblock 28702 -50 28706 minecraft:iron_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28702 -50 28713 minecraft:iron_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28702 -50 28719 minecraft:iron_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28702 -50 28709 minecraft:iron_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28702 -50 28715 minecraft:iron_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28699 -49 28707 minecraft:lever[face=wall,facing=south,powered=true]
setblock 28701 -49 28707 minecraft:lever[face=wall,facing=south,powered=true]
setblock 28699 -49 28714 minecraft:lever[face=wall,facing=south,powered=true]
setblock 28701 -49 28714 minecraft:lever[face=wall,facing=south,powered=true]
setblock 28699 -49 28708 minecraft:lever[face=wall,facing=north,powered=true]
setblock 28701 -49 28708 minecraft:lever[face=wall,facing=north,powered=true]
setblock 28690 -48 28706 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28692 -48 28706 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28694 -48 28706 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28695 -48 28706 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28696 -48 28706 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28690 -48 28713 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28692 -48 28713 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28694 -48 28713 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28695 -48 28713 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28696 -48 28713 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28690 -48 28719 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28692 -48 28719 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28694 -48 28719 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28695 -48 28719 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28696 -48 28719 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28690 -48 28709 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28692 -48 28709 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28694 -48 28709 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28695 -48 28709 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28696 -48 28709 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28690 -48 28715 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28692 -48 28715 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28694 -48 28715 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28695 -48 28715 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28696 -48 28715 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28688 -40 28705 minecraft:waxed_weathered_copper_door[facing=north,half=lower,hinge=left,open=false,powered=false]
setblock 28689 -40 28705 minecraft:waxed_weathered_copper_door[facing=north,half=lower,hinge=right,open=false,powered=false]
setblock 28694 -40 28706 minecraft:polished_blackstone_button[face=wall,facing=west,powered=false]
setblock 28694 -38 28706 minecraft:polished_blackstone_button[face=wall,facing=west,powered=false]
setblock 28695 -40 28707 minecraft:acacia_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28695 -40 28708 minecraft:acacia_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28695 -39 28707 minecraft:acacia_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28694 -40 28715 minecraft:waxed_exposed_copper_door[facing=east,half=lower,hinge=left,open=false,powered=false]
setblock 28694 -40 28716 minecraft:waxed_exposed_copper_door[facing=east,half=lower,hinge=right,open=false,powered=false]
setblock 28689 -40 28717 minecraft:bamboo_trapdoor[facing=north,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28691 -40 28717 minecraft:bamboo_trapdoor[facing=north,half=top,open=true,powered=false,waterlogged=false]
setblock 28691 -39 28717 minecraft:bamboo_trapdoor[facing=north,half=top,open=true,powered=false,waterlogged=false]
setblock 28688 -40 28718 minecraft:bamboo_trapdoor[facing=west,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28690 -40 28718 minecraft:bamboo_trapdoor[facing=east,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28688 -39 28705 minecraft:waxed_weathered_copper_door[facing=north,half=upper,hinge=left,open=false,powered=false]
setblock 28689 -39 28705 minecraft:waxed_weathered_copper_door[facing=north,half=upper,hinge=right,open=false,powered=false]
setblock 28695 -39 28708 minecraft:acacia_trapdoor[facing=west,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28695 -38 28707 minecraft:acacia_trapdoor[facing=west,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28695 -38 28708 minecraft:acacia_trapdoor[facing=west,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28694 -39 28715 minecraft:waxed_exposed_copper_door[facing=east,half=upper,hinge=left,open=false,powered=false]
setblock 28694 -39 28716 minecraft:waxed_exposed_copper_door[facing=east,half=upper,hinge=right,open=false,powered=false]
setblock 28692 -39 28717 minecraft:bamboo_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28691 -38 28718 minecraft:birch_pressure_plate[powered=false]
setblock 28688 -37 28706 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28688 -37 28707 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28688 -37 28708 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28688 -37 28709 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28688 -37 28711 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28688 -37 28712 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28688 -37 28713 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28688 -37 28714 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28688 -37 28715 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28688 -37 28716 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28688 -37 28717 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28688 -37 28718 minecraft:dark_oak_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28693 -36 28710 minecraft:warped_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28692 -35 28710 minecraft:warped_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28691 -34 28710 minecraft:warped_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28690 -33 28710 minecraft:warped_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28694 -36 28718 minecraft:warped_fence_gate[facing=south,in_wall=false,open=true,powered=false]
setblock 28693 -35 28717 minecraft:warped_fence_gate[facing=south,in_wall=false,open=true,powered=false]
setblock 28692 -34 28716 minecraft:warped_fence_gate[facing=south,in_wall=false,open=true,powered=false]
setblock 28691 -33 28715 minecraft:warped_fence_gate[facing=south,in_wall=false,open=true,powered=false]
setblock 28692 -34 28713 minecraft:warped_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28693 -34 28713 minecraft:warped_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28694 -34 28713 minecraft:warped_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28692 -34 28714 minecraft:warped_trapdoor[facing=west,half=top,open=false,powered=false,waterlogged=false]
setblock 28694 -34 28714 minecraft:warped_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28694 -34 28715 minecraft:warped_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28692 -34 28715 minecraft:warped_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28693 -34 28715 minecraft:warped_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28688 -32 28713 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28688 -32 28714 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28688 -32 28715 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28688 -29 28711 minecraft:bamboo_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28689 -21 28707 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28702 -17 28707 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28691 -20 28707 minecraft:dark_oak_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28691 -18 28707 minecraft:jungle_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28692 -31 28713 minecraft:lever[face=wall,facing=east,powered=false]
setblock 28692 -30 28710 minecraft:crimson_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28692 -30 28711 minecraft:crimson_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28692 -29 28710 minecraft:crimson_trapdoor[facing=east,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28692 -29 28711 minecraft:crimson_trapdoor[facing=east,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28692 -29 28713 minecraft:lever[face=wall,facing=east,powered=true]
setblock 28692 -28 28710 minecraft:spruce_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28692 -28 28711 minecraft:spruce_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28692 -28 28712 minecraft:spruce_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28692 -28 28713 minecraft:spruce_trapdoor[facing=east,half=bottom,open=false,powered=true,waterlogged=false]
setblock 28692 -16 28707 minecraft:jungle_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28700 -14 28707 minecraft:jungle_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28694 -13 28707 minecraft:jungle_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28694 -15 28707 minecraft:jungle_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28702 -15 28707 minecraft:jungle_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28696 -12 28707 minecraft:jungle_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28700 -12 28707 minecraft:jungle_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28703 -14 28711 minecraft:lever[face=wall,facing=east,powered=true]
setblock 28703 -14 28712 minecraft:lever[face=wall,facing=east,powered=true]
setblock 28703 -14 28714 minecraft:lever[face=wall,facing=east,powered=true]
setblock 28703 -14 28715 minecraft:lever[face=wall,facing=east,powered=true]
setblock 28703 -14 28717 minecraft:lever[face=wall,facing=east,powered=true]
setblock 28703 -14 28718 minecraft:lever[face=wall,facing=east,powered=true]
setblock 28688 -10 28705 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28688 6 28705 minecraft:lever[face=wall,facing=north,powered=true]
setblock 28703 18 28706 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28701 19 28706 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28700 20 28706 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28702 20 28717 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28702 20 28718 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28702 20 28719 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28699 21 28706 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28700 21 28718 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28700 21 28719 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28697 22 28706 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28698 22 28718 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28698 22 28719 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28696 23 28706 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28696 23 28718 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28696 23 28719 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28695 24 28706 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28694 24 28718 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28694 24 28719 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28693 25 28706 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28692 25 28718 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28692 25 28719 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28690 26 28718 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28690 26 28719 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28702 20 28709 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28702 20 28710 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28702 20 28711 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28700 21 28708 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28700 21 28709 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28700 21 28710 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28698 22 28708 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28698 22 28709 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28698 22 28710 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28696 23 28708 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28696 23 28709 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28696 23 28710 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28694 24 28708 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28694 24 28709 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28694 24 28710 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28692 25 28708 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28692 25 28709 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28692 25 28710 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28690 26 28708 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28690 26 28709 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28690 26 28710 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28689 22 28706 minecraft:spruce_trapdoor[facing=south,half=top,open=true,powered=false,waterlogged=false]
setblock 28689 22 28707 minecraft:lever[face=wall,facing=east,powered=false]
setblock 28689 22 28711 minecraft:lever[face=wall,facing=east,powered=false]
setblock 28689 22 28717 minecraft:lever[face=wall,facing=east,powered=false]
setblock 28688 28 28705 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28690 36 28714 minecraft:lever[face=floor,facing=west,powered=false]
setblock 28691 37 28714 minecraft:lever[face=floor,facing=west,powered=false]
setblock 28692 38 28714 minecraft:lever[face=floor,facing=west,powered=false]
setblock 28693 39 28714 minecraft:lever[face=floor,facing=west,powered=false]
setblock 28694 40 28714 minecraft:pale_oak_fence_gate[facing=north,in_wall=true,open=true,powered=false]
data merge block 28694 -33 28713 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28688 -38 28706 {is_waxed: 0b, front_text: {color: "red", messages: ['"       ███ █  █"', '"       █▄   \'▜▏▙▟▏▛\'"', '"       █▀   ,▟▏▛▜▏▙,"', '"       ███ █  █"'], has_glowing_text: 1b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28689 -38 28706 {is_waxed: 0b, front_text: {color: "red", messages: ['"███ ███       "', '"  █     █         "', '"  █     █         "', '"███   █         "'], has_glowing_text: 1b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28691 26 28705 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28692 -40 28705 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28693 -40 28705 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28688 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28689 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28690 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28688 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28692 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28693 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28689 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28690 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28694 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28699 -50 28708 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28695 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28696 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28692 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28700 -50 28708 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28701 -50 28708 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28693 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28697 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28694 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28698 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28695 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28696 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28697 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28702 -50 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28698 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28699 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28700 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28701 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28702 -50 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28691 -39 28709 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28692 -29 28718 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:stripe_right", color: "light_gray"}, {pattern: "minecraft:stripe_left", color: "light_gray"}]}
data merge block 28692 -39 28709 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28693 -39 28709 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28690 -45 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28691 -45 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28692 -45 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28693 -45 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28694 -45 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28695 -45 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28690 -45 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28691 -45 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28692 -45 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28693 -45 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28694 -45 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28695 -45 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28692 -38 28705 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28693 -38 28705 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28692 -28 28718 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:stripe_right", color: "light_gray"}, {pattern: "minecraft:diagonal_right", color: "gray"}, {pattern: "minecraft:stripe_left", color: "light_gray"}, {pattern: "minecraft:stripe_downleft", color: "light_gray"}, {pattern: "minecraft:stripe_downright", color: "light_gray"}]}
data merge block 28699 -48 28708 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28700 -48 28708 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28699 -50 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28701 -48 28708 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28700 -50 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28701 -50 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28692 -31 28712 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28692 -29 28717 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:stripe_left", color: "light_gray"}, {pattern: "minecraft:stripe_right", color: "light_gray"}, {pattern: "minecraft:stripe_bottom", color: "light_gray"}]}
data merge block 28692 -33 28715 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28693 -33 28715 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28694 -33 28715 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28690 -30 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28692 -38 28704 {crafting_ticks_remaining: 0, Items: [], components: {}, disabled_slots: [I; ], triggered: 0}
data merge block 28693 -38 28704 {crafting_ticks_remaining: 0, Items: [], components: {}, disabled_slots: [I; ], triggered: 0}
data merge block 28691 26 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28688 -36 28713 {CookingTotalTimes: [I; 0, 0, 0, 0], CookingTimes: [I; 0, 0, 0, 0], Items: [], components: {}}
data merge block 28692 -28 28717 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:stripe_top", color: "light_gray"}, {pattern: "minecraft:stripe_right", color: "light_gray"}, {pattern: "minecraft:stripe_left", color: "light_gray"}, {pattern: "minecraft:stripe_bottom", color: "light_gray"}]}
data merge block 28688 -48 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28689 -48 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28690 -48 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28692 -38 28716 {is_waxed: 0b, front_text: {color: "red", messages: ['"███ ███       "', '"  █     █         "', '"  █     █         "', '"███   █         "'], has_glowing_text: 1b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28691 -48 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28692 -48 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28693 -48 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28688 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28689 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28694 -48 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28695 -48 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28690 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28696 -48 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28697 -48 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28692 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28698 -48 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28693 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28694 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28699 -48 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28695 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28700 -48 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28696 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28701 -48 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28688 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28697 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28689 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28698 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28690 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28699 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28692 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28700 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28693 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28701 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28694 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28702 -50 28710 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28695 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28699 -50 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28700 -50 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28696 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28697 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28701 -50 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28692 -31 28711 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28698 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28692 -29 28716 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:stripe_left", color: "light_gray"}]}
data merge block 28702 -50 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28692 -33 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28694 -33 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28690 -30 28711 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28692 -28 28716 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:stripe_left", color: "light_gray"}, {pattern: "minecraft:diagonal_left", color: "gray"}, {pattern: "minecraft:stripe_downleft", color: "light_gray"}, {pattern: "minecraft:stripe_top", color: "light_gray"}]}
data merge block 28688 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28689 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28692 -38 28715 {is_waxed: 0b, front_text: {color: "red", messages: ['"       ███ █  █"', '"       █▄   \'▜▏▙▟▏▛\'"', '"       █▀   ,▟▏▛▜▏▙,"', '"       ███ █  █"'], has_glowing_text: 1b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28690 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28692 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28696 26 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28693 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28694 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28688 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28695 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28689 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28696 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28690 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28697 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28698 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28691 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28699 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28692 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28700 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28701 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28694 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28702 -50 28705 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28695 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28696 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28697 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28698 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28699 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28700 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28688 35 28714 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28701 -48 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28692 -31 28710 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28689 -37 28711 {last_interacted_slot: -1, Items: [], components: {}}
data merge block 28692 -33 28713 {is_waxed: 0b, front_text: {color: "black", messages: ['">                    <"', '"By Kaizen87"', '"Search on Google"', '">                    <"'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28693 -33 28713 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
setblock 28704 -18 28707 minecraft:dark_oak_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28708 -17 28707 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28704 -15 28708 minecraft:waxed_exposed_copper_door[facing=north,half=lower,hinge=left,open=false,powered=false]
setblock 28712 -15 28708 minecraft:waxed_exposed_copper_door[facing=north,half=lower,hinge=left,open=false,powered=false]
setblock 28705 -15 28708 minecraft:waxed_exposed_copper_door[facing=north,half=lower,hinge=right,open=false,powered=false]
setblock 28713 -15 28708 minecraft:waxed_exposed_copper_door[facing=north,half=lower,hinge=right,open=false,powered=false]
setblock 28707 -15 28716 minecraft:bamboo_pressure_plate[powered=false]
setblock 28708 -14 28717 minecraft:bamboo_pressure_plate[powered=false]
setblock 28707 -15 28717 minecraft:bamboo_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28706 -15 28719 minecraft:bamboo_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28707 -14 28719 minecraft:bamboo_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28708 -15 28716 minecraft:bamboo_trapdoor[facing=north,half=top,open=true,powered=false,waterlogged=false]
setblock 28707 -15 28718 minecraft:bamboo_trapdoor[facing=north,half=top,open=true,powered=false,waterlogged=false]
setblock 28708 -15 28718 minecraft:bamboo_trapdoor[facing=north,half=top,open=true,powered=false,waterlogged=false]
setblock 28708 -14 28718 minecraft:bamboo_trapdoor[facing=north,half=top,open=true,powered=false,waterlogged=false]
setblock 28704 -14 28708 minecraft:waxed_exposed_copper_door[facing=north,half=upper,hinge=left,open=false,powered=false]
setblock 28712 -14 28708 minecraft:waxed_exposed_copper_door[facing=north,half=upper,hinge=left,open=false,powered=false]
setblock 28705 -14 28708 minecraft:waxed_exposed_copper_door[facing=north,half=upper,hinge=right,open=false,powered=false]
setblock 28713 -14 28708 minecraft:waxed_exposed_copper_door[facing=north,half=upper,hinge=right,open=false,powered=false]
setblock 28707 -13 28709 minecraft:exposed_copper_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28708 -13 28709 minecraft:exposed_copper_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28710 -13 28709 minecraft:exposed_copper_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28710 -16 28707 minecraft:dark_oak_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28710 -14 28707 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28712 -13 28707 minecraft:jungle_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28714 -10 28707 minecraft:jungle_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28712 -11 28707 minecraft:jungle_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28713 -12 28711 minecraft:lever[face=ceiling,facing=south,powered=false]
setblock 28714 -12 28711 minecraft:lever[face=ceiling,facing=south,powered=false]
setblock 28719 -12 28707 minecraft:jungle_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28718 -11 28707 minecraft:jungle_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28717 -10 28707 minecraft:jungle_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28716 -9 28707 minecraft:jungle_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28717 -15 28710 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28718 -15 28710 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28719 -15 28710 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28717 -15 28711 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28718 -15 28711 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28719 -15 28711 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28717 -15 28713 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28718 -15 28713 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28719 -15 28713 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28717 -15 28714 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28718 -15 28714 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28719 -15 28714 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28717 -15 28716 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28718 -15 28716 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28719 -15 28716 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28717 -15 28717 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28718 -15 28717 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28719 -15 28717 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28719 6 28706 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28717 7 28706 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28716 8 28706 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28715 9 28706 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28713 10 28706 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28712 11 28706 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28711 12 28706 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28718 12 28717 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28718 12 28718 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28718 12 28719 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28709 13 28706 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28716 13 28717 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28716 13 28718 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28716 13 28719 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28708 14 28706 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28714 14 28717 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28714 14 28718 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28714 14 28719 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28707 15 28706 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28712 15 28717 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28712 15 28718 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28712 15 28719 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28718 12 28709 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28718 12 28710 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28718 12 28711 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28716 13 28709 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28716 13 28710 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28716 13 28711 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28714 14 28709 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28714 14 28710 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28714 14 28711 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28712 15 28709 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28712 15 28710 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28712 15 28711 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28705 16 28706 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28706 16 28706 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28710 16 28717 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28710 16 28718 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28710 16 28719 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28704 17 28706 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28708 17 28717 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28708 17 28718 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28708 17 28719 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28706 18 28717 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28706 18 28718 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28706 18 28719 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28704 19 28717 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28704 19 28718 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28704 19 28719 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28710 16 28709 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28710 16 28710 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28710 16 28711 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28708 17 28709 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28708 17 28710 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28708 17 28711 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28706 18 28709 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28706 18 28710 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28706 18 28711 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28704 19 28709 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28704 19 28710 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28704 19 28711 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
data merge block 28710 -15 28717 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28710 -15 28718 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28712 -13 28719 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28713 -13 28719 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28715 -14 28710 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28716 -14 28709 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28715 -14 28711 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28717 -14 28709 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28718 -14 28709 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28719 -14 28709 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28716 -14 28712 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28715 -14 28713 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28717 -14 28712 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28715 -14 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28718 -14 28712 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28715 -14 28716 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28719 -14 28712 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28716 -14 28715 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28715 -14 28717 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28717 -14 28715 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28718 -14 28715 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28716 -14 28718 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28719 -14 28715 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28717 -14 28718 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28718 -14 28718 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28719 -14 28718 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28704 -13 28709 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28705 -13 28709 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28712 -13 28709 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28713 -13 28709 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28704 -13 28719 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28705 -13 28719 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
setblock 28722 -15 28707 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28721 -14 28707 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28720 -15 28710 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28720 -15 28711 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28720 -15 28713 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28720 -15 28714 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28720 -15 28716 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28720 -15 28717 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28727 -14 28707 minecraft:dark_oak_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28729 -11 28707 minecraft:dark_oak_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28731 -8 28707 minecraft:dark_oak_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28720 -13 28707 minecraft:jungle_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28727 -12 28707 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28729 -9 28707 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28733 -3 28705 minecraft:lever[face=floor,facing=north,powered=false]
setblock 28729 -2 28706 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28728 -1 28706 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28727 0 28706 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28725 1 28706 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28724 2 28706 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28723 3 28706 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28721 4 28706 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28734 4 28717 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28734 4 28718 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28734 4 28719 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28720 5 28706 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28732 5 28717 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28732 5 28718 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28732 5 28719 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28730 6 28717 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28730 6 28718 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28730 6 28719 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28728 7 28717 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28728 7 28718 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28728 7 28719 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28726 8 28717 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28726 8 28718 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28726 8 28719 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28724 9 28717 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28724 9 28718 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28724 9 28719 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28722 10 28717 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28722 10 28718 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28722 10 28719 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28720 11 28709 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28720 11 28710 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28720 11 28711 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28734 4 28709 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28734 4 28710 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28734 4 28711 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28732 5 28709 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28732 5 28710 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28732 5 28711 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28730 6 28709 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28730 6 28710 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28730 6 28711 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28728 7 28709 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28728 7 28710 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28728 7 28711 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28726 8 28709 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28726 8 28710 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28726 8 28711 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28724 9 28709 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28724 9 28710 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28724 9 28711 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28722 10 28709 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28722 10 28710 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28722 10 28711 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28720 11 28717 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28720 11 28718 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28720 11 28719 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
data merge block 28732 -3 28705 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28732 -3 28707 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28720 -14 28709 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28721 -14 28709 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28722 -14 28710 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28720 -14 28712 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28722 -14 28711 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28721 -14 28712 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28720 -14 28715 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28722 -14 28713 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28722 -14 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28721 -14 28715 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28720 -14 28718 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28722 -14 28716 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28721 -14 28718 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28722 -14 28717 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
setblock 28743 -9 28705 minecraft:lever[face=wall,facing=north,powered=true]
setblock 28746 -9 28705 minecraft:lever[face=wall,facing=north,powered=true]
setblock 28749 -9 28705 minecraft:lever[face=wall,facing=north,powered=true]
setblock 28743 -2 28708 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28743 -2 28712 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28743 -2 28716 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28747 -10 28705 minecraft:waxed_weathered_copper_door[facing=north,half=lower,hinge=left,open=false,powered=false]
setblock 28750 -10 28705 minecraft:waxed_weathered_copper_door[facing=north,half=lower,hinge=left,open=false,powered=false]
setblock 28747 -9 28705 minecraft:waxed_weathered_copper_door[facing=north,half=upper,hinge=left,open=false,powered=false]
setblock 28750 -9 28705 minecraft:waxed_weathered_copper_door[facing=north,half=upper,hinge=left,open=false,powered=false]
setblock 28744 -8 28705 minecraft:waxed_weathered_copper_trapdoor[facing=north,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28747 -8 28705 minecraft:waxed_weathered_copper_trapdoor[facing=north,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28750 -8 28705 minecraft:waxed_weathered_copper_trapdoor[facing=north,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28745 -4 28708 minecraft:dark_oak_trapdoor[facing=west,half=top,open=false,powered=false,waterlogged=false]
setblock 28745 -4 28712 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28745 -4 28716 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28747 -2 28708 minecraft:dark_oak_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28747 -2 28712 minecraft:dark_oak_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28747 -2 28716 minecraft:dark_oak_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28744 -10 28705 minecraft:waxed_weathered_copper_door[facing=north,half=lower,hinge=left,open=true,powered=true]
setblock 28744 -9 28705 minecraft:waxed_weathered_copper_door[facing=north,half=upper,hinge=left,open=true,powered=true]
setblock 28745 0 28708 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28742 0 28709 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28742 0 28710 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28742 0 28711 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28740 1 28717 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28740 1 28718 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28740 1 28719 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28738 2 28717 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28738 2 28718 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28738 2 28719 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28736 3 28717 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28736 3 28718 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28736 3 28719 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28745 0 28712 minecraft:dark_oak_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28745 0 28716 minecraft:dark_oak_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28742 0 28717 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28742 0 28718 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28742 0 28719 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28740 1 28709 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28740 1 28710 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28740 1 28711 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28738 2 28709 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28738 2 28710 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28738 2 28711 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28736 3 28709 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28736 3 28710 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28736 3 28711 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28748 3 28712 minecraft:lever[face=wall,facing=west,powered=false]
setblock 28748 3 28716 minecraft:lever[face=wall,facing=west,powered=false]
setblock 28747 4 28712 minecraft:lever[face=wall,facing=west,powered=false]
setblock 28747 4 28716 minecraft:lever[face=wall,facing=west,powered=false]
setblock 28746 5 28712 minecraft:lever[face=wall,facing=west,powered=false]
setblock 28746 5 28716 minecraft:lever[face=wall,facing=west,powered=false]
setblock 28745 6 28712 minecraft:lever[face=wall,facing=west,powered=false]
setblock 28745 6 28716 minecraft:lever[face=wall,facing=west,powered=false]
setblock 28744 7 28713 minecraft:lever[face=wall,facing=west,powered=false]
setblock 28744 7 28715 minecraft:lever[face=wall,facing=west,powered=false]
setblock 28743 8 28713 minecraft:lever[face=wall,facing=west,powered=false]
setblock 28743 8 28715 minecraft:lever[face=wall,facing=west,powered=false]
setblock 28742 9 28713 minecraft:lever[face=wall,facing=west,powered=false]
setblock 28742 9 28715 minecraft:lever[face=wall,facing=west,powered=false]
setblock 28741 10 28713 minecraft:lever[face=wall,facing=west,powered=false]
setblock 28741 10 28715 minecraft:lever[face=wall,facing=west,powered=false]
setblock 28740 11 28714 minecraft:lever[face=wall,facing=west,powered=false]
setblock 28739 12 28714 minecraft:lever[face=wall,facing=west,powered=false]
data merge block 28743 9 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28738 4 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28746 6 28713 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28746 6 28714 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28744 -2 28709 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28745 -2 28708 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28746 6 28715 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28744 -2 28710 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28749 7 28714 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28746 -2 28709 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28744 -2 28711 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28746 -2 28710 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28746 -2 28711 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28745 -2 28712 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28744 -2 28717 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28745 -2 28716 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28744 -2 28718 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28744 -2 28719 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28746 -2 28717 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28746 -2 28718 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28746 -2 28719 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
setblock 28675 -49 28722 minecraft:jungle_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28675 -49 28726 minecraft:jungle_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28675 -49 28728 minecraft:jungle_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28675 -49 28732 minecraft:jungle_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28675 -49 28735 minecraft:jungle_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28682 -49 28722 minecraft:jungle_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28682 -49 28726 minecraft:jungle_fence_gate[facing=west,in_wall=false,open=true,powered=false]
setblock 28675 -35 28729 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28676 -35 28729 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28675 -34 28720 minecraft:dark_oak_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28675 -33 28720 minecraft:dark_oak_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28676 -33 28720 minecraft:dark_oak_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28677 -33 28720 minecraft:dark_oak_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28676 -34 28720 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28677 -34 28720 minecraft:dark_oak_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28677 -35 28729 minecraft:jungle_trapdoor[facing=east,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28677 -34 28733 minecraft:spruce_trapdoor[facing=north,half=top,open=true,powered=false,waterlogged=false]
setblock 28677 -34 28735 minecraft:spruce_trapdoor[facing=south,half=top,open=true,powered=false,waterlogged=false]
setblock 28677 -33 28734 minecraft:spruce_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28678 -35 28730 minecraft:waxed_exposed_copper_door[facing=east,half=lower,hinge=left,open=false,powered=false]
setblock 28678 -35 28731 minecraft:waxed_exposed_copper_door[facing=east,half=lower,hinge=right,open=false,powered=false]
setblock 28678 -34 28730 minecraft:waxed_exposed_copper_door[facing=east,half=upper,hinge=left,open=false,powered=false]
setblock 28678 -34 28731 minecraft:waxed_exposed_copper_door[facing=east,half=upper,hinge=right,open=false,powered=false]
setblock 28680 -35 28727 minecraft:waxed_exposed_copper_door[facing=south,half=lower,hinge=right,open=false,powered=false]
setblock 28680 -34 28727 minecraft:waxed_exposed_copper_door[facing=south,half=upper,hinge=right,open=false,powered=false]
setblock 28681 -35 28727 minecraft:waxed_exposed_copper_door[facing=south,half=lower,hinge=left,open=false,powered=false]
setblock 28681 -34 28727 minecraft:waxed_exposed_copper_door[facing=south,half=upper,hinge=left,open=false,powered=false]
setblock 28685 -34 28720 minecraft:crimson_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28686 -40 28727 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28687 -40 28726 minecraft:dark_oak_trapdoor[facing=north,half=top,open=true,powered=false,waterlogged=false]
setblock 28687 -40 28728 minecraft:dark_oak_trapdoor[facing=south,half=top,open=true,powered=false,waterlogged=false]
setblock 28672 -27 28723 minecraft:lever[face=floor,facing=east,powered=false]
setblock 28672 -27 28724 minecraft:lever[face=floor,facing=east,powered=false]
setblock 28674 -26 28726 minecraft:stone_pressure_plate[powered=false]
setblock 28678 -26 28726 minecraft:stone_pressure_plate[powered=false]
setblock 28673 -26 28727 minecraft:stone_pressure_plate[powered=false]
setblock 28674 -26 28727 minecraft:stone_pressure_plate[powered=false]
setblock 28675 -26 28727 minecraft:stone_pressure_plate[powered=false]
setblock 28677 -26 28727 minecraft:stone_pressure_plate[powered=false]
setblock 28678 -26 28727 minecraft:stone_pressure_plate[powered=false]
setblock 28679 -26 28727 minecraft:stone_pressure_plate[powered=false]
setblock 28674 -26 28728 minecraft:stone_pressure_plate[powered=false]
setblock 28678 -26 28728 minecraft:stone_pressure_plate[powered=false]
setblock 28684 -13 28720 minecraft:lever[face=wall,facing=north,powered=false]
setblock 28682 -11 28723 minecraft:lever[face=wall,facing=west,powered=false]
setblock 28683 -11 28724 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28687 -3 28720 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28687 5 28720 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28687 13 28720 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28685 22 28721 minecraft:lever[face=wall,facing=west,powered=false]
setblock 28685 22 28722 minecraft:spruce_trapdoor[facing=north,half=top,open=true,powered=false,waterlogged=false]
setblock 28672 24 28720 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28673 24 28720 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28672 24 28721 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28673 24 28721 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28672 25 28720 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28673 25 28720 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28672 25 28721 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28673 25 28721 minecraft:dark_oak_trapdoor[facing=south,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28674 25 28720 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28675 25 28720 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28674 25 28721 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28675 25 28721 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28678 26 28720 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28679 26 28720 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28678 26 28721 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28679 26 28721 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28682 27 28720 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28683 27 28720 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28682 27 28721 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28683 27 28721 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false]
setblock 28676 25 28720 minecraft:dark_oak_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28677 25 28720 minecraft:dark_oak_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28676 25 28721 minecraft:dark_oak_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28677 25 28721 minecraft:dark_oak_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28680 26 28720 minecraft:dark_oak_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28681 26 28720 minecraft:dark_oak_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28680 26 28721 minecraft:dark_oak_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28681 26 28721 minecraft:dark_oak_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28676 26 28720 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28677 26 28720 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28676 26 28721 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28677 26 28721 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28680 27 28720 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28681 27 28720 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28680 27 28721 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28681 27 28721 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28684 28 28720 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28685 28 28720 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28684 28 28721 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28685 28 28721 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=false,powered=false,waterlogged=false]
setblock 28684 27 28720 minecraft:dark_oak_trapdoor[facing=west,half=top,open=false,powered=false,waterlogged=false]
setblock 28685 27 28720 minecraft:dark_oak_trapdoor[facing=west,half=top,open=false,powered=false,waterlogged=false]
setblock 28684 27 28721 minecraft:dark_oak_trapdoor[facing=west,half=top,open=false,powered=false,waterlogged=false]
setblock 28685 27 28721 minecraft:dark_oak_trapdoor[facing=west,half=top,open=false,powered=false,waterlogged=false]
setblock 28686 28 28723 minecraft:lever[face=wall,facing=south,powered=false]
data merge block 28677 -35 28732 {last_interacted_slot: -1, Items: [], components: {}}
data merge block 28677 -35 28734 {last_interacted_slot: -1, Items: [], components: {}}
data merge block 28672 -30 28730 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:stripe_top", color: "black"}, {pattern: "minecraft:stripe_bottom", color: "black"}, {pattern: "minecraft:half_vertical_right", color: "gray"}]}
data merge block 28676 -30 28730 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:stripe_top", color: "black"}, {pattern: "minecraft:stripe_bottom", color: "black"}, {pattern: "minecraft:half_vertical_right", color: "gray"}]}
data merge block 28683 -34 28720 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:small_stripes", color: "green"}]}
data merge block 28684 -34 28720 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:small_stripes", color: "green"}]}
data merge block 28680 -30 28730 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:stripe_top", color: "black"}, {pattern: "minecraft:stripe_bottom", color: "black"}, {pattern: "minecraft:half_vertical_right", color: "gray"}]}
data merge block 28672 -48 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28672 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28672 -23 28723 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28674 -23 28723 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28675 -23 28723 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28672 -48 28733 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28676 -23 28723 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28685 -48 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28677 -23 28723 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28686 -48 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28687 -48 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28678 -23 28723 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28679 -23 28723 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28680 -23 28723 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28681 -23 28723 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28682 -23 28723 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28685 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28683 -23 28723 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28686 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28673 -35 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28684 -23 28723 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28687 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28673 -35 28723 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28685 -23 28723 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28672 -29 28730 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:stripe_top", color: "black"}, {pattern: "minecraft:stripe_bottom", color: "black"}, {pattern: "minecraft:half_vertical_right", color: "gray"}, {pattern: "minecraft:half_horizontal", color: "gray"}]}
data merge block 28686 -23 28723 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28676 -29 28730 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:stripe_top", color: "black"}, {pattern: "minecraft:stripe_bottom", color: "black"}, {pattern: "minecraft:half_vertical_right", color: "gray"}, {pattern: "minecraft:half_horizontal", color: "gray"}]}
data merge block 28679 -35 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28679 -35 28723 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28680 -29 28730 {components: {"minecraft:damage": 0}, patterns: [{pattern: "minecraft:stripe_top", color: "black"}, {pattern: "minecraft:stripe_bottom", color: "black"}, {pattern: "minecraft:half_vertical_right", color: "gray"}, {pattern: "minecraft:half_horizontal", color: "gray"}]}
data merge block 28677 -35 28733 {last_interacted_slot: -1, Items: [], components: {}}
data merge block 28677 -35 28735 {last_interacted_slot: -1, Items: [], components: {}}
data merge block 28672 -28 28730 {components: {}}
data merge block 28676 -28 28730 {components: {}}
data merge block 28680 -28 28730 {components: {}}
data merge block 28672 -48 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28672 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28673 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28672 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28674 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28673 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28675 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28674 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28675 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28672 -50 28729 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28673 -50 28729 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28685 -48 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28672 -50 28731 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28674 -50 28729 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28672 -48 28734 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28673 -50 28731 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28686 -48 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28675 -50 28729 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28674 -50 28731 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28682 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28687 -48 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28683 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28675 -50 28731 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28684 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28682 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28683 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28685 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28686 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28684 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28685 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28687 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28673 -35 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28686 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28687 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28673 -35 28722 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28673 -35 28724 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28679 -35 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28679 -35 28722 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28679 -35 28724 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28680 -33 28725 {is_waxed: 0b, front_text: {color: "red", messages: ['"███ ███       "', '"  █     █         "', '"  █     █         "', '"███   █         "'], has_glowing_text: 1b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28681 -33 28725 {is_waxed: 0b, front_text: {color: "red", messages: ['"       ███ █  █"', '"       █▄   \'▜▏▙▟▏▛\'"', '"       █▀   ,▟▏▛▜▏▙,"', '"       ███ █  █"'], has_glowing_text: 1b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
setblock 28689 -51 28733 minecraft:waxed_exposed_copper_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28699 -49 28720 minecraft:lever[face=wall,facing=south,powered=true]
setblock 28701 -49 28720 minecraft:lever[face=wall,facing=south,powered=true]
setblock 28699 -49 28727 minecraft:lever[face=wall,facing=south,powered=true]
setblock 28701 -49 28727 minecraft:lever[face=wall,facing=south,powered=true]
setblock 28699 -49 28721 minecraft:lever[face=wall,facing=north,powered=true]
setblock 28701 -49 28721 minecraft:lever[face=wall,facing=north,powered=true]
setblock 28702 -50 28722 minecraft:iron_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28702 -50 28726 minecraft:iron_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28690 -48 28722 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28692 -48 28722 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28694 -48 28722 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28695 -48 28722 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28696 -48 28722 minecraft:jungle_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28690 -48 28726 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28692 -48 28726 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28694 -48 28726 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28695 -48 28726 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28696 -48 28726 minecraft:jungle_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28688 -40 28727 minecraft:dark_oak_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28692 -36 28724 minecraft:warped_fence_gate[facing=south,in_wall=false,open=true,powered=false]
setblock 28691 -35 28723 minecraft:warped_fence_gate[facing=south,in_wall=false,open=true,powered=false]
setblock 28690 -34 28722 minecraft:warped_fence_gate[facing=south,in_wall=false,open=true,powered=false]
setblock 28689 -33 28721 minecraft:warped_fence_gate[facing=south,in_wall=false,open=true,powered=false]
setblock 28689 -21 28721 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28691 -18 28721 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28691 -20 28721 minecraft:dark_oak_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28702 -17 28721 minecraft:jungle_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28692 -16 28721 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28694 -13 28721 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28694 -15 28721 minecraft:dark_oak_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28696 -12 28721 minecraft:dark_oak_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28688 -10 28723 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28700 -14 28721 minecraft:jungle_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28702 -15 28721 minecraft:jungle_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28700 -12 28721 minecraft:jungle_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28688 20 28723 minecraft:lever[face=wall,facing=south,powered=true]
setblock 28689 22 28721 minecraft:lever[face=wall,facing=east,powered=false]
setblock 28689 22 28722 minecraft:spruce_trapdoor[facing=north,half=top,open=true,powered=false,waterlogged=false]
setblock 28688 28 28723 minecraft:lever[face=wall,facing=south,powered=false]
setblock 28703 18 28722 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28701 19 28722 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28700 20 28722 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28700 21 28720 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28699 21 28722 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28698 22 28720 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28697 22 28722 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28696 23 28720 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28696 23 28722 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28694 24 28720 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28695 24 28722 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28692 25 28720 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28693 25 28722 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28690 26 28720 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
data merge block 28697 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28699 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28701 -50 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28700 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28698 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28701 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28702 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28699 -50 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28700 -50 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['">                    <"', '"Build by Kaizen87"', '"Search on Google"', '">                    <"'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28702 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28701 -50 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28691 26 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28691 26 28723 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28688 -48 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28689 -48 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28690 -48 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28691 -48 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28692 -48 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28693 -48 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28688 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28694 -48 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28695 -48 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28689 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28696 -48 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28690 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28697 -48 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28691 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28698 -48 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28692 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28693 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28699 -48 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28699 -50 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28700 -48 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28694 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28700 -50 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28701 -48 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28695 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28696 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28701 -50 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28697 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28698 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28699 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28700 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28701 -48 28727 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28688 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28689 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28690 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28688 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28689 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28692 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28690 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28693 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28694 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28692 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28699 -48 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28693 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28695 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28700 -48 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28696 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28694 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28701 -48 28720 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28695 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28697 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28699 -50 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28696 -50 28725 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28698 -50 28723 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28700 -50 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
setblock 28704 -18 28721 minecraft:jungle_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28708 -17 28721 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28710 -16 28721 minecraft:dark_oak_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28712 -13 28721 minecraft:dark_oak_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28714 -10 28721 minecraft:dark_oak_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28704 -15 28720 minecraft:waxed_exposed_copper_door[facing=south,half=lower,hinge=right,open=false,powered=false]
setblock 28712 -15 28720 minecraft:waxed_exposed_copper_door[facing=south,half=lower,hinge=right,open=false,powered=false]
setblock 28705 -15 28720 minecraft:waxed_exposed_copper_door[facing=south,half=lower,hinge=left,open=false,powered=false]
setblock 28713 -15 28720 minecraft:waxed_exposed_copper_door[facing=south,half=lower,hinge=left,open=false,powered=false]
setblock 28704 -14 28720 minecraft:waxed_exposed_copper_door[facing=south,half=upper,hinge=right,open=false,powered=false]
setblock 28712 -14 28720 minecraft:waxed_exposed_copper_door[facing=south,half=upper,hinge=right,open=false,powered=false]
setblock 28705 -14 28720 minecraft:waxed_exposed_copper_door[facing=south,half=upper,hinge=left,open=false,powered=false]
setblock 28713 -14 28720 minecraft:waxed_exposed_copper_door[facing=south,half=upper,hinge=left,open=false,powered=false]
setblock 28710 -14 28721 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28712 -11 28721 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28719 -12 28721 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28718 -11 28721 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28717 -10 28721 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28716 -9 28721 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28719 6 28722 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28717 7 28722 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28716 8 28722 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28715 9 28722 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28713 10 28722 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28712 11 28722 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28711 12 28722 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28709 13 28722 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28708 14 28722 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28707 15 28722 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28705 16 28722 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28706 16 28722 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28704 17 28722 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28722 -15 28721 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28721 -14 28721 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28720 -13 28721 minecraft:dark_oak_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28727 -14 28721 minecraft:dark_oak_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28729 -11 28721 minecraft:dark_oak_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28731 -8 28721 minecraft:dark_oak_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28727 -12 28721 minecraft:dark_oak_trapdoor[facing=west,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28729 -2 28722 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28728 -1 28722 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28729 -9 28721 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28733 -3 28723 minecraft:lever[face=floor,facing=south,powered=false]
setblock 28727 0 28722 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28725 1 28722 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28724 2 28722 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28723 3 28722 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28721 4 28722 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
setblock 28720 5 28722 minecraft:dark_oak_fence_gate[facing=south,in_wall=false,open=false,powered=false]
data merge block 28732 -3 28721 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28732 -3 28723 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
setblock 28744 -10 28723 minecraft:waxed_weathered_copper_door[facing=south,half=lower,hinge=right,open=true,powered=true]
setblock 28747 -10 28723 minecraft:waxed_weathered_copper_door[facing=south,half=lower,hinge=right,open=false,powered=false]
setblock 28750 -10 28723 minecraft:waxed_weathered_copper_door[facing=south,half=lower,hinge=right,open=false,powered=false]
setblock 28743 -9 28723 minecraft:lever[face=wall,facing=south,powered=true]
setblock 28746 -9 28723 minecraft:lever[face=wall,facing=south,powered=true]
setblock 28749 -9 28723 minecraft:lever[face=wall,facing=south,powered=true]
setblock 28747 -9 28723 minecraft:waxed_weathered_copper_door[facing=south,half=upper,hinge=right,open=false,powered=false]
setblock 28750 -9 28723 minecraft:waxed_weathered_copper_door[facing=south,half=upper,hinge=right,open=false,powered=false]
setblock 28744 -8 28723 minecraft:waxed_weathered_copper_trapdoor[facing=south,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28747 -8 28723 minecraft:waxed_weathered_copper_trapdoor[facing=south,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28750 -8 28723 minecraft:waxed_weathered_copper_trapdoor[facing=south,half=bottom,open=true,powered=false,waterlogged=false]
setblock 28745 -4 28720 minecraft:dark_oak_trapdoor[facing=east,half=top,open=false,powered=false,waterlogged=false]
setblock 28743 -2 28720 minecraft:dark_oak_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false]
setblock 28747 -2 28720 minecraft:dark_oak_trapdoor[facing=east,half=top,open=true,powered=false,waterlogged=false]
setblock 28744 -9 28723 minecraft:waxed_weathered_copper_door[facing=south,half=upper,hinge=right,open=true,powered=true]
setblock 28745 0 28720 minecraft:dark_oak_trapdoor[facing=east,half=bottom,open=false,powered=false,waterlogged=false]
data merge block 28745 -2 28720 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
setblock 28675 -49 28739 minecraft:jungle_fence_gate[facing=east,in_wall=false,open=true,powered=false]
setblock 28677 -43 28737 minecraft:iron_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28678 -43 28737 minecraft:iron_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]
setblock 28677 -43 28738 minecraft:iron_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28678 -43 28738 minecraft:iron_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28677 -43 28739 minecraft:iron_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
setblock 28678 -43 28739 minecraft:iron_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false]
data merge block 28676 -42 28737 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28676 -42 28738 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28676 -42 28739 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28672 -50 28736 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28679 -42 28737 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28676 -42 28740 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28676 -42 28741 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28673 -50 28736 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
data merge block 28679 -42 28738 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28672 -48 28740 {is_waxed: 0b, front_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}, components: {}, back_text: {color: "black", messages: ['""', '""', '""', '""'], has_glowing_text: 0b}}
data merge block 28674 -50 28736 {cooking_total_time: 0s, lit_time_remaining: 0s, Items: [], components: {}, lit_total_time: 0s, RecipesUsed: {}, cooking_time_spent: 0s}
