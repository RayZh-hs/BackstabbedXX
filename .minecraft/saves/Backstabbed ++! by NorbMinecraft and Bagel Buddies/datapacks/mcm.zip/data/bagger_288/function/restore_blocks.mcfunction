function bagger_288:restore/part_0
function bagger_288:restore/part_1
function bagger_288:restore/part_2
