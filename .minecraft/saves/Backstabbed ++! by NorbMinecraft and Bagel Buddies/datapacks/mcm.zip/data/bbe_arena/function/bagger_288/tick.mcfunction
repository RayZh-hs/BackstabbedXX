execute unless score $selectedMap CmdData matches 18 run return 0
execute if score $gamestate CmdData matches 0 run function bagger_288:waiting_tick
execute if score $gamestate CmdData matches 1 run function bagger_288:functionality
