execute unless predicate bbe_arena:middle_ages/keep_in run function bbe_arena:middle_ages/kill
