execute unless predicate bbe_arena:underwater_base/keep_in run function bbe_arena:underwater_base/kill
