execute unless predicate bbe_arena:klut27/keep_in run function bbe_arena:klut27/kill
