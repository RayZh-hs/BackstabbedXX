execute if score $gamestate CmdData matches 1 run return run function mcm:game/playerdeath
function bbe_arena:underwater_base/tp
