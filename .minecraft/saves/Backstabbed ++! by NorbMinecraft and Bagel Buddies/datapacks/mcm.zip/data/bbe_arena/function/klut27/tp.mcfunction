execute in minecraft:overworld run tp @s 36873.5 16 36879.5 90 0
